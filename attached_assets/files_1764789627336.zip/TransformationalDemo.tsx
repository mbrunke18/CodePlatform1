/**
 * TransformationalDemo - The Complete "New Way of Working" Experience
 * 
 * This page orchestrates the full demo flow:
 * 1. Chaos Simulator (feel current pain)
 * 2. Football Bridge (credibility moment)
 * 3. M-Enabled Response (the 12-minute solution)
 * 4. Interactive Decision Points (participate, don't just watch)
 * 5. Readiness Assessment (personalized urgency)
 * 
 * The goal is not to explain features, but to make the prospect's
 * current reality feel intolerable and M's alternative feel essential.
 */

import { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Play,
  ArrowRight,
  Clock,
  Target,
  Users,
  Zap,
  CheckCircle,
  Trophy,
  Building2,
  BookOpen,
  RotateCcw,
  ChevronRight
} from 'lucide-react';

// Import our new components
import ChaosSimulator from '@/components/demo/ChaosSimulator';
import OrganizationReadinessScore from '@/components/demo/OrganizationReadinessScore';
import InteractiveDecisionPoint, { DECISION_SCENARIOS } from '@/components/demo/InteractiveDecisionPoint';
import { CrisisResolvedCelebration } from '@/components/demo/CrisisResolvedCelebration';
import { useTimelineOrchestrator, useTimelineState } from '@/contexts/DemoTimelineContext';
import PageLayout from '@/components/layout/PageLayout';

type DemoPhase = 
  | 'setup'           // Industry/company selection
  | 'chaos'           // Chaos simulator
  | 'bridge'          // Football methodology bridge
  | 'signal'          // M detects signal
  | 'decision_1'      // First interactive decision
  | 'playbook'        // Playbook activation
  | 'decision_2'      // Second interactive decision
  | 'coordination'    // Team coordination view
  | 'decision_3'      // Third interactive decision
  | 'resolution'      // Crisis resolved celebration
  | 'assessment';     // Readiness score

interface DemoConfig {
  scenario: 'ransomware' | 'competitor' | 'regulatory' | 'supply_chain' | 'pr_crisis';
  industry: string;
  companyName: string;
  companySize: 'small' | 'medium' | 'large' | 'enterprise';
  userRole: string;
}

const SCENARIO_LABELS = {
  ransomware: { label: 'Ransomware Attack', icon: '🔒', decisionKey: 'ransomware_initial' },
  competitor: { label: 'Competitive Threat', icon: '⚔️', decisionKey: 'competitor_response' },
  regulatory: { label: 'Regulatory Crisis', icon: '⚖️', decisionKey: 'regulatory_disclosure' },
  supply_chain: { label: 'Supply Chain Failure', icon: '🚚', decisionKey: 'ransomware_initial' },
  pr_crisis: { label: 'PR Crisis', icon: '📢', decisionKey: 'competitor_response' }
};

const INDUSTRIES = [
  { id: 'financial_services', label: 'Financial Services' },
  { id: 'healthcare', label: 'Healthcare' },
  { id: 'manufacturing', label: 'Manufacturing' },
  { id: 'technology', label: 'Technology' },
  { id: 'retail', label: 'Retail' },
  { id: 'energy', label: 'Energy & Utilities' }
];

export default function TransformationalDemo() {
  const [, setLocation] = useLocation();
  const [phase, setPhase] = useState<DemoPhase>('setup');
  const [config, setConfig] = useState<DemoConfig>({
    scenario: 'ransomware',
    industry: 'technology',
    companyName: 'Your Company',
    companySize: 'large',
    userRole: 'Chief Strategy Officer'
  });
  const [decisionsMade, setDecisionsMade] = useState<{ optionId: string; wasOptimal: boolean }[]>([]);
  const [currentDecision, setCurrentDecision] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);

  const { startOnce, resetAll } = useTimelineOrchestrator();
  const timelineState = useTimelineState();

  const handleConfigUpdate = (field: keyof DemoConfig, value: string) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleStartDemo = () => {
    setPhase('chaos');
  };

  const handleChaosComplete = () => {
    setPhase('bridge');
  };

  const handleBridgeComplete = () => {
    setPhase('signal');
    // Start the 12-minute timer
    startOnce({ duration: 720000, speedMultiplier: 60 }); // 60x speed for demo
  };

  const handleDecisionMade = (optionId: string, wasOptimal: boolean) => {
    setDecisionsMade(prev => [...prev, { optionId, wasOptimal }]);
  };

  const handleDecisionContinue = () => {
    const nextPhase: Record<number, DemoPhase> = {
      0: 'playbook',
      1: 'coordination',
      2: 'resolution'
    };
    
    setCurrentDecision(prev => prev + 1);
    setPhase(nextPhase[currentDecision] || 'resolution');
  };

  const handleResolutionComplete = () => {
    setShowCelebration(true);
    setTimeout(() => {
      setShowCelebration(false);
      setPhase('assessment');
    }, 5000);
  };

  const handleRestartDemo = () => {
    setPhase('setup');
    setDecisionsMade([]);
    setCurrentDecision(0);
    resetAll();
  };

  // Get the appropriate decision scenario based on the demo scenario
  const getDecisionScenario = (index: number) => {
    const scenarios = [
      DECISION_SCENARIOS.ransomware_initial,
      DECISION_SCENARIOS.competitor_response,
      DECISION_SCENARIOS.regulatory_disclosure
    ];
    return scenarios[index] || scenarios[0];
  };

  // SETUP PHASE
  if (phase === 'setup') {
    return (
      <PageLayout title="Experience M">
        <div className="max-w-4xl mx-auto py-12 px-6">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-blue-500/20 text-blue-300 border-blue-500/50 text-lg px-4 py-2">
              Interactive Demo Experience
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Experience the Transformation
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              In the next 15 minutes, you'll experience the difference between reactive scrambling 
              and prepared execution. Let's customize this for your world.
            </p>
          </div>

          <Card className="bg-slate-900/80 border-slate-700 mb-8">
            <CardContent className="p-8 space-y-8">
              {/* Scenario Selection */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Target className="h-5 w-5 text-blue-400" />
                  Select Your Scenario
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {Object.entries(SCENARIO_LABELS).map(([key, { label, icon }]) => (
                    <Card 
                      key={key}
                      className={`cursor-pointer transition-all ${
                        config.scenario === key 
                          ? 'bg-blue-950/50 border-blue-500' 
                          : 'bg-slate-800/50 border-slate-700 hover:border-slate-500'
                      }`}
                      onClick={() => handleConfigUpdate('scenario', key)}
                    >
                      <CardContent className="p-4 text-center">
                        <span className="text-2xl mb-2 block">{icon}</span>
                        <span className="text-sm text-slate-300">{label}</span>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Industry Selection */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-purple-400" />
                  Your Industry
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {INDUSTRIES.map(({ id, label }) => (
                    <Card 
                      key={id}
                      className={`cursor-pointer transition-all ${
                        config.industry === id 
                          ? 'bg-purple-950/50 border-purple-500' 
                          : 'bg-slate-800/50 border-slate-700 hover:border-slate-500'
                      }`}
                      onClick={() => handleConfigUpdate('industry', id)}
                    >
                      <CardContent className="p-3 text-center">
                        <span className="text-sm text-slate-300">{label}</span>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Company Details */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">
                    Company Name (for personalization)
                  </label>
                  <input
                    type="text"
                    value={config.companyName}
                    onChange={(e) => handleConfigUpdate('companyName', e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
                    placeholder="Your Company Name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">
                    Company Size
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {(['small', 'medium', 'large', 'enterprise'] as const).map((size) => (
                      <Card 
                        key={size}
                        className={`cursor-pointer transition-all ${
                          config.companySize === size 
                            ? 'bg-teal-950/50 border-teal-500' 
                            : 'bg-slate-800/50 border-slate-700 hover:border-slate-500'
                        }`}
                        onClick={() => handleConfigUpdate('companySize', size)}
                      >
                        <CardContent className="p-2 text-center">
                          <span className="text-xs text-slate-300 capitalize">{size}</span>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>

              {/* What to Expect */}
              <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                <h4 className="font-medium text-white mb-3">What You'll Experience:</h4>
                <div className="grid md:grid-cols-2 gap-3">
                  <div className="flex items-start gap-2">
                    <div className="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center text-red-400 text-xs font-bold shrink-0">1</div>
                    <div className="text-sm text-slate-400">
                      <span className="text-red-300 font-medium">The Chaos</span> - Experience crisis response without M
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 text-xs font-bold shrink-0">2</div>
                    <div className="text-sm text-slate-400">
                      <span className="text-amber-300 font-medium">The Bridge</span> - Why preparation beats improvisation
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-xs font-bold shrink-0">3</div>
                    <div className="text-sm text-slate-400">
                      <span className="text-blue-300 font-medium">The Solution</span> - M in action with your decisions
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center text-green-400 text-xs font-bold shrink-0">4</div>
                    <div className="text-sm text-slate-400">
                      <span className="text-green-300 font-medium">Your Score</span> - Personalized readiness assessment
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex flex-col items-center gap-4">
            <Button 
              onClick={handleStartDemo}
              className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white px-12 py-6 text-xl"
            >
              <Play className="mr-3 h-6 w-6" />
              Begin Experience
            </Button>
            <div className="flex items-center gap-2 text-slate-400 text-sm">
              <Clock className="h-4 w-4" />
              <span>~15 minutes • Interactive • Personalized</span>
            </div>
          </div>
        </div>
      </PageLayout>
    );
  }

  // CHAOS PHASE
  if (phase === 'chaos') {
    return (
      <ChaosSimulator
        scenario={config.scenario}
        companyName={config.companyName}
        userRole={config.userRole}
        onComplete={handleChaosComplete}
        onSkip={handleChaosComplete}
      />
    );
  }

  // BRIDGE PHASE - The Football Methodology Connection
  if (phase === 'bridge') {
    return (
      <div className="fixed inset-0 z-[10002] bg-slate-950 flex items-center justify-center p-6">
        <div className="max-w-3xl text-center space-y-8">
          <div className="w-20 h-20 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center mx-auto">
            <Trophy className="h-10 w-10 text-white" />
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-white">
            That chaos? It's <span className="text-red-400">avoidable</span>.
          </h1>

          <div className="space-y-6 text-left bg-slate-900/50 rounded-xl p-8 border border-slate-700">
            <p className="text-xl text-slate-300">
              In college football, we had <span className="text-amber-400 font-semibold">40 seconds</span> between plays. 
              80,000 fans watching. National television cameras rolling.
            </p>
            <p className="text-xl text-slate-300">
              And we executed perfectly—not because we were smarter, but because we'd{' '}
              <span className="text-amber-400 font-semibold">prepared</span>.
            </p>
            <p className="text-xl text-slate-300">
              Everyone knew their assignment. The play call was one word. Execution began{' '}
              <span className="text-amber-400 font-semibold">instantly</span>.
            </p>
          </div>

          <div className="bg-blue-950/30 rounded-xl p-6 border border-blue-500/30">
            <p className="text-2xl text-white font-medium mb-4">
              What if your organization could do the same?
            </p>
            <p className="text-slate-400">
              Let me show you what that looks like when {config.companyName} has M.
            </p>
          </div>

          <Button 
            onClick={handleBridgeComplete}
            className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white px-10 py-6 text-lg"
          >
            Show Me the M-Enabled Response
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    );
  }

  // SIGNAL DETECTION PHASE
  if (phase === 'signal') {
    return (
      <div className="fixed inset-0 z-[10002] bg-slate-950 flex items-center justify-center p-6">
        <div className="max-w-3xl w-full space-y-6">
          {/* Timer header */}
          <div className="flex items-center justify-between">
            <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/50 text-lg px-4 py-2">
              M Response Timeline
            </Badge>
            <div className="flex items-center gap-2 bg-slate-800 rounded-lg px-4 py-2">
              <Clock className="h-5 w-5 text-blue-400" />
              <span className="font-mono text-xl text-white">{timelineState.formattedTime}</span>
              <span className="text-slate-400 text-sm">/ 12:00</span>
            </div>
          </div>

          <Card className="bg-slate-900/80 border-blue-500/50 border-2">
            <CardContent className="p-8">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-teal-500 rounded-xl flex items-center justify-center shrink-0">
                  <Zap className="h-7 w-7 text-white" />
                </div>
                <div>
                  <Badge className="bg-green-500/20 text-green-300 border-green-500/50 mb-2">
                    Signal Detected: 47 minutes before your team noticed
                  </Badge>
                  <h2 className="text-2xl font-bold text-white mb-2">
                    M's AI Radar Detected This Threat
                  </h2>
                  <p className="text-slate-400">
                    While the traditional organization was still unaware, M had already:
                  </p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                {[
                  'Identified the threat pattern from intelligence feeds',
                  'Matched it to Playbook #89: Ransomware Attack Response',
                  'Pre-staged communication templates',
                  'Notified the on-call response team',
                  'Prepared the board briefing structure'
                ].map((action, i) => (
                  <div key={i} className="flex items-center gap-3 text-slate-300">
                    <CheckCircle className="h-5 w-5 text-green-400 shrink-0" />
                    <span>{action}</span>
                  </div>
                ))}
              </div>

              <div className="bg-blue-950/30 rounded-lg p-4 border border-blue-500/30">
                <p className="text-blue-200">
                  <span className="font-semibold">Key difference:</span> Instead of scrambling to figure out "what do we do?", 
                  your team sees "here's the playbook, here's your assignment, here's the clock."
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button 
              onClick={() => setPhase('decision_1')}
              className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white px-8 py-6 text-lg"
            >
              Continue: Make Your First Decision
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // DECISION PHASES
  if (phase === 'decision_1' || phase === 'decision_2' || phase === 'decision_3') {
    const decisionIndex = phase === 'decision_1' ? 0 : phase === 'decision_2' ? 1 : 2;
    return (
      <InteractiveDecisionPoint
        scenario={getDecisionScenario(decisionIndex)}
        onDecisionMade={handleDecisionMade}
        onContinue={handleDecisionContinue}
        showMGuidance={true}
      />
    );
  }

  // PLAYBOOK ACTIVATION PHASE
  if (phase === 'playbook') {
    return (
      <div className="fixed inset-0 z-[10002] bg-slate-950 flex items-center justify-center p-6">
        <div className="max-w-4xl w-full space-y-6">
          <div className="flex items-center justify-between">
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/50 text-lg px-4 py-2">
              Playbook Activated
            </Badge>
            <div className="flex items-center gap-2 bg-slate-800 rounded-lg px-4 py-2">
              <Clock className="h-5 w-5 text-blue-400" />
              <span className="font-mono text-xl text-white">{timelineState.formattedTime}</span>
            </div>
          </div>

          <Card className="bg-slate-900/80 border-purple-500/50 border-2">
            <CardContent className="p-8">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center shrink-0">
                  <BookOpen className="h-7 w-7 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">
                    Playbook #89: Ransomware Attack Response
                  </h2>
                  <p className="text-slate-400">
                    Pre-built, pre-approved, ready to execute in under 12 minutes
                  </p>
                </div>
              </div>

              {/* Three-phase execution */}
              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <Card className="bg-red-950/30 border-red-500/30">
                  <CardContent className="p-4">
                    <div className="text-xs text-red-300 font-medium mb-1">IMMEDIATE (0-2 min)</div>
                    <div className="text-lg font-bold text-white mb-2">Containment</div>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Isolate affected systems</li>
                      <li>• Activate incident commander</li>
                      <li>• Notify legal hold</li>
                    </ul>
                  </CardContent>
                </Card>
                <Card className="bg-amber-950/30 border-amber-500/30">
                  <CardContent className="p-4">
                    <div className="text-xs text-amber-300 font-medium mb-1">SECONDARY (2-5 min)</div>
                    <div className="text-lg font-bold text-white mb-2">Communication</div>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Board briefing sent</li>
                      <li>• Employee notice staged</li>
                      <li>• Customer comms prepared</li>
                    </ul>
                  </CardContent>
                </Card>
                <Card className="bg-green-950/30 border-green-500/30">
                  <CardContent className="p-4">
                    <div className="text-xs text-green-300 font-medium mb-1">FOLLOW-UP (5-12 min)</div>
                    <div className="text-lg font-bold text-white mb-2">Resolution</div>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Recovery initiated</li>
                      <li>• Insurance notified</li>
                      <li>• Post-incident review scheduled</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-blue-950/30 rounded-lg p-4 border border-blue-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="h-5 w-5 text-blue-400" />
                  <span className="font-semibold text-white">Stakeholder Coordination</span>
                </div>
                <p className="text-slate-300 text-sm">
                  12 stakeholders across 6 departments have received their assignments. 
                  No meetings needed—everyone knows exactly what to do.
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button 
              onClick={() => setPhase('decision_2')}
              className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white px-8 py-6 text-lg"
            >
              Continue: Second Decision Point
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // COORDINATION PHASE
  if (phase === 'coordination') {
    return (
      <div className="fixed inset-0 z-[10002] bg-slate-950 flex items-center justify-center p-6">
        <div className="max-w-4xl w-full space-y-6">
          <div className="flex items-center justify-between">
            <Badge className="bg-teal-500/20 text-teal-300 border-teal-500/50 text-lg px-4 py-2">
              Team Coordination Active
            </Badge>
            <div className="flex items-center gap-2 bg-slate-800 rounded-lg px-4 py-2">
              <Clock className="h-5 w-5 text-blue-400" />
              <span className="font-mono text-xl text-white">{timelineState.formattedTime}</span>
            </div>
          </div>

          <Card className="bg-slate-900/80 border-teal-500/50 border-2">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-white mb-6">Command Center: Live Status</h2>
              
              <div className="space-y-4">
                {[
                  { role: 'CISO', name: 'Marcus Chen', task: 'Containment verified', status: 'complete' },
                  { role: 'General Counsel', name: 'Sarah Williams', task: 'Notification requirements confirmed', status: 'complete' },
                  { role: 'CFO', name: 'James Morrison', task: 'Board briefing sent', status: 'complete' },
                  { role: 'VP Comms', name: 'Lisa Park', task: 'Press statement approved', status: 'in_progress' },
                  { role: 'VP Customer Success', name: 'David Kim', task: 'Customer outreach initiated', status: 'in_progress' },
                  { role: 'CEO', name: 'Executive Office', task: 'Oversight and approval', status: 'monitoring' }
                ].map((person, i) => (
                  <div key={i} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center text-white font-bold">
                        {person.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <div className="font-medium text-white">{person.name}</div>
                        <div className="text-sm text-slate-400">{person.role}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-slate-300">{person.task}</span>
                      {person.status === 'complete' && (
                        <Badge className="bg-green-500/20 text-green-300">Complete</Badge>
                      )}
                      {person.status === 'in_progress' && (
                        <Badge className="bg-blue-500/20 text-blue-300">In Progress</Badge>
                      )}
                      {person.status === 'monitoring' && (
                        <Badge className="bg-purple-500/20 text-purple-300">Monitoring</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 bg-green-950/30 rounded-lg p-4 border border-green-500/30">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-green-300 font-medium">Overall Progress</div>
                    <div className="text-2xl font-bold text-white">83% Complete</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-green-300 font-medium">Estimated Resolution</div>
                    <div className="text-2xl font-bold text-white">2 minutes</div>
                  </div>
                </div>
                <Progress value={83} className="mt-3 h-2" />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button 
              onClick={() => setPhase('decision_3')}
              className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white px-8 py-6 text-lg"
            >
              Continue: Final Decision
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // RESOLUTION PHASE
  if (phase === 'resolution') {
    return (
      <div className="fixed inset-0 z-[10002] bg-slate-950 flex items-center justify-center p-6">
        <div className="max-w-3xl w-full text-center space-y-8">
          <Badge className="bg-green-500/20 text-green-300 border-green-500/50 text-lg px-6 py-2">
            Crisis Resolved
          </Badge>

          <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto">
            <CheckCircle className="h-12 w-12 text-white" />
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-white">
            12 Minutes. Crisis Contained.
          </h1>

          <div className="grid md:grid-cols-3 gap-4">
            <Card className="bg-slate-900/80 border-slate-700">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-green-400 mb-1">12:00</div>
                <div className="text-sm text-slate-400">Total Response Time</div>
              </CardContent>
            </Card>
            <Card className="bg-slate-900/80 border-slate-700">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-blue-400 mb-1">12</div>
                <div className="text-sm text-slate-400">Stakeholders Coordinated</div>
              </CardContent>
            </Card>
            <Card className="bg-slate-900/80 border-slate-700">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-purple-400 mb-1">$2.5M</div>
                <div className="text-sm text-slate-400">Revenue Protected</div>
              </CardContent>
            </Card>
          </div>

          <div className="bg-blue-950/30 rounded-xl p-6 border border-blue-500/30">
            <p className="text-xl text-slate-300 mb-4">
              Remember the chaos simulator? That same crisis took the traditional organization{' '}
              <span className="text-red-400 font-bold">72+ hours</span> and cost{' '}
              <span className="text-red-400 font-bold">$2.5M in lost revenue</span>.
            </p>
            <p className="text-slate-400">
              With M, {config.companyName} resolved it in <span className="text-green-400 font-bold">12 minutes</span> with{' '}
              <span className="text-green-400 font-bold">revenue protected</span>.
            </p>
          </div>

          <Button 
            onClick={handleResolutionComplete}
            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-10 py-6 text-lg"
          >
            See Your Readiness Assessment
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>

        {showCelebration && <CrisisResolvedCelebration />}
      </div>
    );
  }

  // ASSESSMENT PHASE
  if (phase === 'assessment') {
    return (
      <OrganizationReadinessScore
        companyName={config.companyName}
        industry={config.industry}
        companySize={config.companySize}
        scenarioCompleted={config.scenario}
        onScheduleDemo={() => setLocation('/contact')}
        onExplorePlaybooks={() => setLocation('/playbook-library')}
        onClose={handleRestartDemo}
      />
    );
  }

  return null;
}
