/**
 * OrganizationReadinessScore - Personalized Assessment Generator
 * 
 * Generates a "readiness score" based on the prospect's industry,
 * size, and responses during the demo. Creates urgency by showing
 * the gap between their current state and M-enabled future.
 * 
 * Psychology: Specific, personalized gaps are more compelling than generic benefits.
 */

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Target,
  Clock,
  Users,
  BookOpen,
  Shield,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  ChevronRight,
  Building2,
  DollarSign,
  Zap,
  BarChart3,
  Brain,
  Calendar
} from 'lucide-react';

interface ReadinessMetric {
  category: string;
  currentScore: number;
  mEnabledScore: number;
  icon: React.ElementType;
  currentLabel: string;
  mLabel: string;
  impact: string;
}

interface OrganizationReadinessScoreProps {
  companyName?: string;
  industry?: string;
  companySize?: 'small' | 'medium' | 'large' | 'enterprise';
  scenarioCompleted?: string;
  onScheduleDemo?: () => void;
  onExplorePlaybooks?: () => void;
  onClose?: () => void;
}

const INDUSTRY_BENCHMARKS: Record<string, { avgResponseTime: number; playbookCoverage: number; annualCrises: number }> = {
  'financial_services': { avgResponseTime: 68, playbookCoverage: 18, annualCrises: 12 },
  'healthcare': { avgResponseTime: 72, playbookCoverage: 15, annualCrises: 8 },
  'manufacturing': { avgResponseTime: 84, playbookCoverage: 12, annualCrises: 6 },
  'technology': { avgResponseTime: 48, playbookCoverage: 25, annualCrises: 10 },
  'retail': { avgResponseTime: 56, playbookCoverage: 14, annualCrises: 9 },
  'energy': { avgResponseTime: 96, playbookCoverage: 20, annualCrises: 5 },
  'default': { avgResponseTime: 72, playbookCoverage: 15, annualCrises: 8 }
};

const SIZE_MULTIPLIERS: Record<string, { revenue: number; executiveTime: number; riskExposure: number }> = {
  'small': { revenue: 50000000, executiveTime: 120, riskExposure: 2500000 },
  'medium': { revenue: 500000000, executiveTime: 200, riskExposure: 15000000 },
  'large': { revenue: 2000000000, executiveTime: 350, riskExposure: 45000000 },
  'enterprise': { revenue: 10000000000, executiveTime: 500, riskExposure: 150000000 }
};

export default function OrganizationReadinessScore({
  companyName = 'Your Organization',
  industry = 'default',
  companySize = 'large',
  scenarioCompleted = 'ransomware',
  onScheduleDemo,
  onExplorePlaybooks,
  onClose
}: OrganizationReadinessScoreProps) {
  const [animatedScores, setAnimatedScores] = useState<Record<string, number>>({});
  const [showProjection, setShowProjection] = useState(false);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'30' | '90' | '180'>('90');

  const benchmark = INDUSTRY_BENCHMARKS[industry] || INDUSTRY_BENCHMARKS.default;
  const sizeMultiplier = SIZE_MULTIPLIERS[companySize];

  // Calculate readiness metrics based on industry and company profile
  const readinessMetrics: ReadinessMetric[] = [
    {
      category: 'Playbook Coverage',
      currentScore: benchmark.playbookCoverage,
      mEnabledScore: 85,
      icon: BookOpen,
      currentLabel: `~${benchmark.playbookCoverage} scenarios documented`,
      mLabel: '110+ strategic playbooks',
      impact: `${148 - benchmark.playbookCoverage} gaps in crisis coverage`
    },
    {
      category: 'Coordination Speed',
      currentScore: Math.round((12 / benchmark.avgResponseTime) * 100),
      mEnabledScore: 100,
      icon: Clock,
      currentLabel: `${benchmark.avgResponseTime}+ hours average`,
      mLabel: '12 minutes coordinated',
      impact: `${Math.round(benchmark.avgResponseTime / 12)}x faster response`
    },
    {
      category: 'Stakeholder Alignment',
      currentScore: 25,
      mEnabledScore: 94,
      icon: Users,
      currentLabel: 'Ad-hoc coordination',
      mLabel: 'Pre-assigned roles & workflows',
      impact: 'Eliminate alignment meetings'
    },
    {
      category: 'Institutional Memory',
      currentScore: 15,
      mEnabledScore: 88,
      icon: Brain,
      currentLabel: 'Lessons rarely captured',
      mLabel: 'AI-powered learning loops',
      impact: 'Every response improves the next'
    },
    {
      category: 'Pre-Approved Authority',
      currentScore: 10,
      mEnabledScore: 82,
      icon: Shield,
      currentLabel: 'Approvals during crisis',
      mLabel: 'Budgets & decisions pre-staged',
      impact: 'Remove bottlenecks in execution'
    },
    {
      category: 'Trigger Monitoring',
      currentScore: 20,
      mEnabledScore: 95,
      icon: Zap,
      currentLabel: 'Reactive detection',
      mLabel: '24/7 AI signal monitoring',
      impact: 'Hours of early warning'
    }
  ];

  // Calculate overall scores
  const currentOverallScore = Math.round(
    readinessMetrics.reduce((sum, m) => sum + m.currentScore, 0) / readinessMetrics.length
  );
  const mEnabledOverallScore = Math.round(
    readinessMetrics.reduce((sum, m) => sum + m.mEnabledScore, 0) / readinessMetrics.length
  );

  // Calculate financial impact
  const annualRiskExposure = sizeMultiplier.riskExposure;
  const executiveHoursWasted = sizeMultiplier.executiveTime * benchmark.annualCrises;
  const executiveHourCost = 500; // Conservative estimate for C-suite time
  const potentialSavings = Math.round(annualRiskExposure * 0.7); // 70% risk mitigation

  // Animate scores on mount
  useEffect(() => {
    const animateScores = () => {
      readinessMetrics.forEach((metric, index) => {
        setTimeout(() => {
          setAnimatedScores(prev => ({
            ...prev,
            [metric.category]: metric.currentScore
          }));
        }, index * 200);
      });
    };

    animateScores();
    setTimeout(() => setShowProjection(true), 1500);
  }, []);

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000000) {
      return `$${(amount / 1000000000).toFixed(1)}B`;
    }
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`;
    }
    return `$${(amount / 1000).toFixed(0)}K`;
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getProgressColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 50) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="fixed inset-0 z-[10003] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <Card className="bg-slate-900 border-slate-700 max-w-5xl w-full my-8">
        <CardHeader className="border-b border-slate-700 pb-6">
          <div className="flex items-center justify-between">
            <div>
              <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/50 mb-3">
                Strategic Readiness Assessment
              </Badge>
              <CardTitle className="text-2xl text-white flex items-center gap-3">
                <Building2 className="h-7 w-7 text-blue-400" />
                {companyName} Readiness Profile
              </CardTitle>
              <p className="text-slate-400 mt-2">
                Based on {industry.replace('_', ' ')} industry benchmarks and your demonstration responses
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-slate-400 mb-1">Overall Readiness</div>
              <div className="flex items-baseline gap-2">
                <span className={`text-5xl font-bold ${getScoreColor(currentOverallScore)}`}>
                  {currentOverallScore}
                </span>
                <span className="text-slate-500 text-2xl">/100</span>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-8">
          {/* Readiness Metrics Grid */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Target className="h-5 w-5 text-blue-400" />
              Capability Assessment
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              {readinessMetrics.map((metric) => (
                <Card key={metric.category} className="bg-slate-800/50 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <metric.icon className="h-5 w-5 text-slate-400" />
                        <span className="font-medium text-white">{metric.category}</span>
                      </div>
                      <div className="text-right">
                        <span className={`text-lg font-bold ${getScoreColor(metric.currentScore)}`}>
                          {animatedScores[metric.category] || 0}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="relative mb-3">
                      <Progress 
                        value={animatedScores[metric.category] || 0} 
                        className="h-2 bg-slate-700"
                      />
                      {showProjection && (
                        <div 
                          className="absolute top-0 h-2 border-r-2 border-dashed border-green-400 transition-all duration-1000"
                          style={{ left: `${metric.mEnabledScore}%` }}
                        />
                      )}
                    </div>

                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1 text-red-300">
                        <AlertTriangle className="h-3 w-3" />
                        <span>{metric.currentLabel}</span>
                      </div>
                      {showProjection && (
                        <div className="flex items-center gap-1 text-green-300">
                          <CheckCircle className="h-3 w-3" />
                          <span>{metric.mLabel}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Financial Impact */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-green-400" />
              Financial Impact Analysis
            </h3>
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="bg-red-950/30 border-red-500/30">
                <CardContent className="p-4 text-center">
                  <div className="text-3xl font-bold text-red-400 mb-1">
                    {formatCurrency(annualRiskExposure)}
                  </div>
                  <div className="text-sm text-red-300 mb-2">Annual Risk Exposure</div>
                  <div className="text-xs text-slate-400">
                    Based on ~{benchmark.annualCrises} strategic events/year
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-950/30 border-amber-500/30">
                <CardContent className="p-4 text-center">
                  <div className="text-3xl font-bold text-amber-400 mb-1">
                    {executiveHoursWasted.toLocaleString()}
                  </div>
                  <div className="text-sm text-amber-300 mb-2">Executive Hours/Year</div>
                  <div className="text-xs text-slate-400">
                    Worth {formatCurrency(executiveHoursWasted * executiveHourCost)} in leadership time
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-green-950/30 border-green-500/30">
                <CardContent className="p-4 text-center">
                  <div className="text-3xl font-bold text-green-400 mb-1">
                    {formatCurrency(potentialSavings)}
                  </div>
                  <div className="text-sm text-green-300 mb-2">Potential Annual Savings</div>
                  <div className="text-xs text-slate-400">
                    With M-enabled strategic execution
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Transformation Timeline */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Calendar className="h-5 w-5 text-purple-400" />
              Transformation Timeline
            </h3>
            <div className="flex gap-2 mb-4">
              {(['30', '90', '180'] as const).map((days) => (
                <Button
                  key={days}
                  variant={selectedTimeframe === days ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedTimeframe(days)}
                  className={selectedTimeframe === days 
                    ? 'bg-blue-600 text-white' 
                    : 'border-slate-600 text-slate-300'
                  }
                >
                  {days} Days
                </Button>
              ))}
            </div>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-4">
                <div className="grid md:grid-cols-4 gap-4">
                  {selectedTimeframe === '30' && (
                    <>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">15</div>
                        <div className="text-xs text-slate-400">Playbooks Activated</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">48 hrs</div>
                        <div className="text-xs text-slate-400">Avg Response Time</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">40%</div>
                        <div className="text-xs text-slate-400">Risk Reduction</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-400">45</div>
                        <div className="text-xs text-slate-400">Readiness Score</div>
                      </div>
                    </>
                  )}
                  {selectedTimeframe === '90' && (
                    <>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">65</div>
                        <div className="text-xs text-slate-400">Playbooks Activated</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">4 hrs</div>
                        <div className="text-xs text-slate-400">Avg Response Time</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">70%</div>
                        <div className="text-xs text-slate-400">Risk Reduction</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-400">72</div>
                        <div className="text-xs text-slate-400">Readiness Score</div>
                      </div>
                    </>
                  )}
                  {selectedTimeframe === '180' && (
                    <>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">110+</div>
                        <div className="text-xs text-slate-400">Playbooks Activated</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">12 min</div>
                        <div className="text-xs text-slate-400">Avg Response Time</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">85%</div>
                        <div className="text-xs text-slate-400">Risk Reduction</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-400">89</div>
                        <div className="text-xs text-slate-400">Readiness Score</div>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Key Insight */}
          <Card className="bg-gradient-to-r from-blue-950/50 to-purple-950/50 border-blue-500/30">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center shrink-0">
                  <BarChart3 className="h-6 w-6 text-blue-400" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">Key Insight</h4>
                  <p className="text-slate-300">
                    With a current readiness score of <span className="text-red-400 font-semibold">{currentOverallScore}%</span>, 
                    {companyName} faces an estimated <span className="text-red-400 font-semibold">{formatCurrency(annualRiskExposure)}</span> in 
                    annual risk exposure from strategic execution gaps. M can elevate your readiness to{' '}
                    <span className="text-green-400 font-semibold">{mEnabledOverallScore}%</span> within 180 days, 
                    transforming {benchmark.avgResponseTime}+ hour response cycles into 12-minute coordinated execution.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* CTA Section */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Button 
              onClick={onScheduleDemo}
              className="flex-1 bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white py-6 text-lg"
            >
              Schedule Strategy Session
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              onClick={onExplorePlaybooks}
              variant="outline"
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-800 py-6 text-lg"
            >
              Explore 148 Playbooks
              <BookOpen className="ml-2 h-5 w-5" />
            </Button>
          </div>

          {onClose && (
            <div className="text-center">
              <Button 
                variant="ghost" 
                onClick={onClose}
                className="text-slate-500 hover:text-slate-300"
              >
                Close Assessment
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
