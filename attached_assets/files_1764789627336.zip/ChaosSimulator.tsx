/**
 * ChaosSimulator - The "Before M" Experience
 * 
 * This component simulates the chaos of traditional crisis response,
 * making prospects viscerally feel the pain of their current state
 * before showing them the M-enabled future.
 * 
 * Psychology: You can't sell relief until they feel the pain.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AlertTriangle,
  Mail,
  MessageSquare,
  Phone,
  Clock,
  Users,
  TrendingDown,
  Calendar,
  FileText,
  Video,
  Bell,
  X,
  ChevronRight,
  Loader2,
  DollarSign,
  Building2,
  Newspaper,
  Shield
} from 'lucide-react';

interface ChaosMessage {
  id: string;
  type: 'slack' | 'email' | 'text' | 'call' | 'calendar' | 'news';
  from: string;
  role: string;
  subject: string;
  preview: string;
  urgency: 'critical' | 'high' | 'medium';
  timestamp: string;
  unread: boolean;
}

interface ChaosSimulatorProps {
  scenario: 'ransomware' | 'competitor' | 'regulatory' | 'supply_chain' | 'pr_crisis';
  onComplete: () => void;
  onSkip?: () => void;
  companyName?: string;
  userRole?: string;
}

const SCENARIO_CONFIGS = {
  ransomware: {
    title: 'Ransomware Attack Detected',
    initialAlert: 'CISO has sent you an urgent message...',
    tickerMessages: [
      'Systems going offline across 3 regions...',
      'Customer data potentially compromised...',
      'Ransom demand: $15M in Bitcoin...',
      'Board members requesting emergency briefing...',
      'Media outlet has obtained internal documents...'
    ],
    revenueAtRisk: 2500000,
    revenueBleedRate: 847, // dollars per second
  },
  competitor: {
    title: 'Major Competitor Announcement',
    initialAlert: 'VP Strategy has flagged an urgent competitive threat...',
    tickerMessages: [
      'Competitor announced 40% price cut...',
      'Three enterprise clients requesting meetings...',
      'Sales team reporting deal delays...',
      'Analyst downgrade expected tomorrow...',
      'Board wants competitive response plan...'
    ],
    revenueAtRisk: 4200000,
    revenueBleedRate: 1200,
  },
  regulatory: {
    title: 'Regulatory Investigation Notice',
    initialAlert: 'General Counsel needs you immediately...',
    tickerMessages: [
      'SEC requesting documents within 48 hours...',
      'Potential $50M fine exposure...',
      'Whistleblower complaint surfaced...',
      'Investor relations fielding calls...',
      'Stock price down 4% pre-market...'
    ],
    revenueAtRisk: 50000000,
    revenueBleedRate: 2500,
  },
  supply_chain: {
    title: 'Critical Supplier Failure',
    initialAlert: 'VP Operations: Production halted...',
    tickerMessages: [
      'Primary supplier filed for bankruptcy...',
      'No backup supplier qualified...',
      '3 weeks of inventory remaining...',
      'Customer delivery commitments at risk...',
      'Procurement scrambling for alternatives...'
    ],
    revenueAtRisk: 8500000,
    revenueBleedRate: 1800,
  },
  pr_crisis: {
    title: 'Viral PR Crisis',
    initialAlert: 'CMO: We have a situation...',
    tickerMessages: [
      'Video going viral on social media...',
      '#BoycottYourBrand trending...',
      'Major news outlet requesting comment by 5pm...',
      'Employee posts making it worse...',
      'Influencers amplifying the story...'
    ],
    revenueAtRisk: 12000000,
    revenueBleedRate: 3500,
  }
};

const generateChaosMessages = (scenario: keyof typeof SCENARIO_CONFIGS, companyName: string): ChaosMessage[] => {
  const baseMessages: Record<string, ChaosMessage[]> = {
    ransomware: [
      { id: '1', type: 'slack', from: 'Marcus Chen', role: 'CISO', subject: '🚨 CRITICAL: Security Incident', preview: 'We have confirmed ransomware in the EU datacenter. Systems are being encrypted. Need you in war room NOW.', urgency: 'critical', timestamp: '2:47 PM', unread: true },
      { id: '2', type: 'email', from: 'Sarah Williams', role: 'General Counsel', subject: 'RE: Security Incident - Legal Implications', preview: 'What are our notification obligations? GDPR requires 72-hour disclosure. Do we have a communication plan?', urgency: 'critical', timestamp: '2:49 PM', unread: true },
      { id: '3', type: 'text', from: 'James Morrison', role: 'CFO', subject: '', preview: 'Board is asking about financial exposure. What do I tell them? Can you join the 3pm call?', urgency: 'critical', timestamp: '2:51 PM', unread: true },
      { id: '4', type: 'slack', from: 'Operations Team', role: 'Channel', subject: '#incident-response', preview: '[47 unread messages] "What systems are affected?" "Should we shut down?" "Who is leading this?"', urgency: 'high', timestamp: '2:52 PM', unread: true },
      { id: '5', type: 'calendar', from: 'Board Secretary', role: 'Executive Office', subject: 'URGENT: Emergency Board Call', preview: 'Emergency board meeting scheduled for 4:30 PM. Please prepare status update and remediation plan.', urgency: 'critical', timestamp: '2:54 PM', unread: true },
      { id: '6', type: 'email', from: 'David Park', role: 'VP Customer Success', subject: 'Customer Inquiries Flooding In', preview: 'Enterprise clients asking if their data is safe. What should we tell them? Need talking points ASAP.', urgency: 'high', timestamp: '2:56 PM', unread: true },
      { id: '7', type: 'call', from: 'Unknown Number', role: '', subject: 'Missed Call', preview: 'Reuters reporter trying to reach you for comment on "major security incident"', urgency: 'critical', timestamp: '2:58 PM', unread: true },
      { id: '8', type: 'slack', from: 'HR Team', role: 'Channel', subject: '#people-ops', preview: 'Employees are panicking. Social media posts emerging. What is our internal communication plan?', urgency: 'high', timestamp: '3:01 PM', unread: true },
      { id: '9', type: 'email', from: 'External: FBI Cyber Division', role: 'Federal Agency', subject: 'Request for Information', preview: 'We have been notified of a potential cyber incident at your organization. Please contact Special Agent...', urgency: 'critical', timestamp: '3:03 PM', unread: true },
      { id: '10', type: 'text', from: 'CEO', role: 'Executive', subject: '', preview: 'I need a full brief before the board call. What happened, what are we doing, what is the exposure?', urgency: 'critical', timestamp: '3:05 PM', unread: true },
    ],
    competitor: [
      { id: '1', type: 'slack', from: 'Alex Rivera', role: 'VP Strategy', subject: '🔥 Competitor Alert', preview: 'TechGiant just announced 40% price cut on their enterprise tier. This is going to hit us hard.', urgency: 'critical', timestamp: '9:15 AM', unread: true },
      { id: '2', type: 'email', from: 'Sales Leadership', role: 'Revenue Team', subject: 'URGENT: Deal Pipeline Impact', preview: '3 major deals just went "on hold" pending competitive review. $4.2M at risk this quarter.', urgency: 'critical', timestamp: '9:22 AM', unread: true },
      { id: '3', type: 'text', from: 'Board Member', role: 'Governance', subject: '', preview: 'Just saw the TechGiant news. What is our response? Analyst call in 2 hours.', urgency: 'critical', timestamp: '9:28 AM', unread: true },
      { id: '4', type: 'slack', from: 'Product Team', role: 'Channel', subject: '#product-strategy', preview: '[32 messages] "Should we accelerate the roadmap?" "What features do we prioritize?" "Need direction!"', urgency: 'high', timestamp: '9:35 AM', unread: true },
      { id: '5', type: 'email', from: 'CMO', role: 'Marketing', subject: 'Positioning Response Needed', preview: 'Press asking for our response to TechGiant pricing. What is our message? Need to brief PR team.', urgency: 'high', timestamp: '9:42 AM', unread: true },
    ],
    regulatory: [
      { id: '1', type: 'email', from: 'Jennifer Walsh', role: 'General Counsel', subject: '⚠️ SEC Investigation Notice', preview: 'Just received formal notice. SEC requesting all documents related to Q3 revenue recognition. 48-hour deadline.', urgency: 'critical', timestamp: '8:02 AM', unread: true },
      { id: '2', type: 'call', from: 'CFO Direct Line', role: 'Finance', subject: 'Missed Call (3)', preview: 'Three missed calls from CFO in the last 10 minutes', urgency: 'critical', timestamp: '8:15 AM', unread: true },
      { id: '3', type: 'slack', from: 'Investor Relations', role: 'Channel', subject: '#ir-urgent', preview: 'Major shareholders asking about the investigation. Stock down 4% pre-market. What do we disclose?', urgency: 'critical', timestamp: '8:22 AM', unread: true },
    ],
    supply_chain: [
      { id: '1', type: 'slack', from: 'Tom Bradley', role: 'VP Operations', subject: '🛑 PRODUCTION HALT', preview: 'Apex Components just filed Chapter 11. They supply 60% of our critical components. Lines are stopping.', urgency: 'critical', timestamp: '6:45 AM', unread: true },
      { id: '2', type: 'email', from: 'Procurement Lead', role: 'Supply Chain', subject: 'No Qualified Backup Suppliers', preview: 'We never qualified an alternative supplier. Qualification process takes 8-12 weeks minimum.', urgency: 'critical', timestamp: '7:02 AM', unread: true },
      { id: '3', type: 'text', from: 'CEO', role: 'Executive', subject: '', preview: 'Customer commitments at risk? Get me options by 10am.', urgency: 'critical', timestamp: '7:15 AM', unread: true },
    ],
    pr_crisis: [
      { id: '1', type: 'slack', from: 'Maria Santos', role: 'CMO', subject: '🔴 PR EMERGENCY', preview: 'Video of our warehouse incident is going viral. 2M views and climbing. #BoycottOurBrand is trending.', urgency: 'critical', timestamp: '11:30 AM', unread: true },
      { id: '2', type: 'email', from: 'Social Media Team', role: 'Marketing', subject: 'Social Media Metrics - URGENT', preview: 'Negative sentiment up 340%. Influencers with 10M+ followers are sharing. This is accelerating.', urgency: 'critical', timestamp: '11:45 AM', unread: true },
      { id: '3', type: 'news', from: 'Media Alert', role: 'External', subject: 'NYT Requesting Comment', preview: 'New York Times reporter deadline: 5pm today. Story running tomorrow regardless of our response.', urgency: 'critical', timestamp: '12:02 PM', unread: true },
    ]
  };

  return baseMessages[scenario] || baseMessages.ransomware;
};

export default function ChaosSimulator({ 
  scenario, 
  onComplete, 
  onSkip,
  companyName = 'Meridian Industries',
  userRole = 'Chief Strategy Officer'
}: ChaosSimulatorProps) {
  const config = SCENARIO_CONFIGS[scenario];
  const [phase, setPhase] = useState<'intro' | 'chaos' | 'overwhelm' | 'transition'>('intro');
  const [messages, setMessages] = useState<ChaosMessage[]>([]);
  const [visibleMessages, setVisibleMessages] = useState<ChaosMessage[]>([]);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [revenueLost, setRevenueLost] = useState(0);
  const [tickerIndex, setTickerIndex] = useState(0);
  const [showOverwhelmPrompt, setShowOverwhelmPrompt] = useState(false);
  const [stressLevel, setStressLevel] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize messages
  useEffect(() => {
    setMessages(generateChaosMessages(scenario, companyName));
  }, [scenario, companyName]);

  // Phase progression
  useEffect(() => {
    if (phase === 'intro') {
      const timer = setTimeout(() => setPhase('chaos'), 3000);
      return () => clearTimeout(timer);
    }
  }, [phase]);

  // Message reveal during chaos phase
  useEffect(() => {
    if (phase !== 'chaos') return;

    const revealInterval = setInterval(() => {
      setVisibleMessages(prev => {
        if (prev.length < messages.length) {
          const nextMessage = messages[prev.length];
          // Play notification sound effect (visual pulse instead)
          setStressLevel(s => Math.min(s + 15, 100));
          return [...prev, nextMessage];
        }
        return prev;
      });
    }, 2500);

    return () => clearInterval(revealInterval);
  }, [phase, messages]);

  // Timer and revenue bleeding
  useEffect(() => {
    if (phase !== 'chaos' && phase !== 'overwhelm') return;

    const timer = setInterval(() => {
      setElapsedTime(prev => prev + 1);
      setRevenueLost(prev => prev + config.revenueBleedRate);
    }, 1000);

    return () => clearInterval(timer);
  }, [phase, config.revenueBleedRate]);

  // Ticker rotation
  useEffect(() => {
    if (phase !== 'chaos' && phase !== 'overwhelm') return;

    const ticker = setInterval(() => {
      setTickerIndex(prev => (prev + 1) % config.tickerMessages.length);
    }, 4000);

    return () => clearInterval(ticker);
  }, [phase, config.tickerMessages]);

  // Check for overwhelm state
  useEffect(() => {
    if (visibleMessages.length >= 6 && phase === 'chaos') {
      setPhase('overwhelm');
      setTimeout(() => setShowOverwhelmPrompt(true), 2000);
    }
  }, [visibleMessages.length, phase]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getMessageIcon = (type: string) => {
    switch (type) {
      case 'slack': return <MessageSquare className="h-4 w-4" />;
      case 'email': return <Mail className="h-4 w-4" />;
      case 'text': return <Phone className="h-4 w-4" />;
      case 'call': return <Phone className="h-4 w-4" />;
      case 'calendar': return <Calendar className="h-4 w-4" />;
      case 'news': return <Newspaper className="h-4 w-4" />;
      default: return <Bell className="h-4 w-4" />;
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'bg-red-500/20 text-red-300 border-red-500/50';
      case 'high': return 'bg-orange-500/20 text-orange-300 border-orange-500/50';
      default: return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
    }
  };

  const handleTransitionToM = () => {
    setPhase('transition');
    setTimeout(onComplete, 2000);
  };

  // INTRO PHASE
  if (phase === 'intro') {
    return (
      <div className="fixed inset-0 z-[10002] bg-slate-950 flex items-center justify-center">
        <div className="text-center space-y-6 max-w-2xl px-6">
          <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/50 text-lg px-4 py-2">
            Simulation Starting
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            It's 2:47 PM on a Tuesday.
          </h1>
          <p className="text-xl text-slate-300">
            You're the <span className="text-amber-400 font-semibold">{userRole}</span> at{' '}
            <span className="text-amber-400 font-semibold">{companyName}</span>.
          </p>
          <p className="text-2xl text-white font-medium">
            {config.initialAlert}
          </p>
          <div className="flex items-center justify-center gap-2 text-slate-400">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Loading your inbox...</span>
          </div>
        </div>
      </div>
    );
  }

  // TRANSITION PHASE
  if (phase === 'transition') {
    return (
      <div className="fixed inset-0 z-[10002] bg-slate-950 flex items-center justify-center">
        <div className="text-center space-y-6 max-w-2xl px-6">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-teal-500 rounded-2xl flex items-center justify-center mx-auto">
            <span className="text-white font-bold text-4xl">M</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            Now, let's show you a different way.
          </h1>
          <p className="text-xl text-slate-300">
            What if your team was <span className="text-blue-400 font-semibold">prepared</span>?
          </p>
          <Loader2 className="h-8 w-8 animate-spin text-blue-400 mx-auto" />
        </div>
      </div>
    );
  }

  // CHAOS & OVERWHELM PHASES
  return (
    <div className="fixed inset-0 z-[10002] bg-slate-950">
      {/* Stress indicator background pulse */}
      <div 
        className="absolute inset-0 bg-red-900/20 transition-opacity duration-1000"
        style={{ opacity: stressLevel / 200 }}
      />

      {/* Header with crisis ticker */}
      <div className="bg-red-900/80 border-b border-red-500/50 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-6 w-6 text-red-400 animate-pulse" />
            <span className="text-red-100 font-bold text-lg">{config.title}</span>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-red-200">
              <Clock className="h-4 w-4" />
              <span className="font-mono">{formatTime(elapsedTime)} elapsed</span>
            </div>
            <div className="flex items-center gap-2 text-red-200">
              <TrendingDown className="h-4 w-4" />
              <span className="font-mono">{formatCurrency(revenueLost)} at risk</span>
            </div>
          </div>
        </div>
      </div>

      {/* Breaking news ticker */}
      <div className="bg-red-950/60 border-b border-red-900/50 px-4 py-2 overflow-hidden">
        <div className="flex items-center gap-4 animate-pulse">
          <Badge className="bg-red-600 text-white shrink-0">DEVELOPING</Badge>
          <span className="text-red-200 whitespace-nowrap">
            {config.tickerMessages[tickerIndex]}
          </span>
        </div>
      </div>

      {/* Main content */}
      <div className="flex h-[calc(100vh-120px)]">
        {/* Message inbox */}
        <div className="flex-1 p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white font-semibold flex items-center gap-2">
              <Bell className="h-5 w-5 text-red-400" />
              Incoming ({visibleMessages.filter(m => m.unread).length} unread)
            </h2>
            {onSkip && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onSkip}
                className="text-slate-400 hover:text-white"
              >
                Skip simulation
              </Button>
            )}
          </div>

          <ScrollArea className="h-[calc(100%-60px)]">
            <div className="space-y-3 pr-4">
              {visibleMessages.map((message, index) => (
                <Card 
                  key={message.id}
                  className={`bg-slate-900/80 border-slate-700 transition-all duration-500 ${
                    index === visibleMessages.length - 1 ? 'animate-in slide-in-from-top-4' : ''
                  } ${message.unread ? 'border-l-4 border-l-red-500' : ''}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${getUrgencyColor(message.urgency)}`}>
                        {getMessageIcon(message.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white">{message.from}</span>
                            {message.role && (
                              <Badge variant="outline" className="text-xs text-slate-400 border-slate-600">
                                {message.role}
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-slate-500">{message.timestamp}</span>
                        </div>
                        {message.subject && (
                          <p className="text-sm font-medium text-slate-200 mb-1">{message.subject}</p>
                        )}
                        <p className="text-sm text-slate-400 line-clamp-2">{message.preview}</p>
                      </div>
                      {message.urgency === 'critical' && (
                        <Badge className="bg-red-500/20 text-red-300 border-red-500/50 shrink-0">
                          URGENT
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}

              {visibleMessages.length > 0 && visibleMessages.length < messages.length && (
                <div className="flex items-center justify-center py-4 text-slate-500">
                  <Loader2 className="h-5 w-5 animate-spin mr-2" />
                  More messages incoming...
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Status panel */}
        <div className="w-80 bg-slate-900/50 border-l border-slate-700 p-4">
          <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Shield className="h-5 w-5 text-red-400" />
            Current Status
          </h3>

          <div className="space-y-4">
            {/* Stress meter */}
            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-slate-400">Organizational Stress</span>
                <span className="text-red-400 font-medium">{stressLevel}%</span>
              </div>
              <Progress value={stressLevel} className="h-2 bg-slate-700" />
            </div>

            {/* Key metrics */}
            <Card className="bg-red-950/30 border-red-500/30">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Response Plan</span>
                  <Badge className="bg-red-500/20 text-red-300">None</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Team Alignment</span>
                  <Badge className="bg-red-500/20 text-red-300">Scattered</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Stakeholders Briefed</span>
                  <Badge className="bg-red-500/20 text-red-300">0 / 12</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Clear Owner</span>
                  <Badge className="bg-red-500/20 text-red-300">Undefined</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Reality check */}
            <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
              <p className="text-slate-300 text-sm mb-2 font-medium">The Reality:</p>
              <p className="text-slate-400 text-sm">
                This is how <span className="text-white">94% of Fortune 500 companies</span> coordinate crisis response today.
              </p>
            </div>

            {/* Question prompt */}
            <div className="text-center text-slate-400 text-sm">
              How long would it take <span className="text-white">your team</span> to get aligned?
            </div>
          </div>
        </div>
      </div>

      {/* Overwhelm prompt overlay */}
      {showOverwhelmPrompt && (
        <div className="absolute inset-0 bg-black/60 flex items-center justify-center z-10">
          <Card className="bg-slate-900 border-slate-700 max-w-lg mx-4">
            <CardContent className="p-8 text-center space-y-6">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto">
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
              
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">Feeling Overwhelmed?</h2>
                <p className="text-slate-300">
                  In just <span className="text-red-400 font-semibold">{formatTime(elapsedTime)}</span>, you've received{' '}
                  <span className="text-red-400 font-semibold">{visibleMessages.length}</span> urgent messages with no clear path forward.
                </p>
              </div>

              <div className="bg-red-950/30 rounded-lg p-4 border border-red-500/30">
                <div className="flex items-center justify-center gap-4 text-red-200">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{formatCurrency(revenueLost)}</div>
                    <div className="text-xs text-red-300">Value at risk</div>
                  </div>
                  <div className="w-px h-12 bg-red-500/30" />
                  <div className="text-center">
                    <div className="text-2xl font-bold">0%</div>
                    <div className="text-xs text-red-300">Response progress</div>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-slate-400 text-sm">
                  What if there was a better way?
                </p>
                <Button 
                  onClick={handleTransitionToM}
                  className="w-full bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white py-6 text-lg"
                >
                  Show Me How M Changes This
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
