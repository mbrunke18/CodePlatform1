/**
 * InteractiveDecisionPoint - Choice Moments in the Demo
 * 
 * Creates decision points where prospects must choose how to respond,
 * then reveals how M would have guided them. This makes the demo
 * participatory rather than passive, and demonstrates M's value
 * through contrast with their instincts.
 * 
 * Psychology: People remember choices they made, not slides they watched.
 */

import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  ChevronRight,
  Lightbulb,
  Target,
  Users,
  TrendingUp,
  TrendingDown,
  Zap,
  Brain,
  ArrowRight
} from 'lucide-react';

interface DecisionOption {
  id: string;
  label: string;
  description: string;
  isOptimal: boolean;
  consequence: {
    timeImpact: string;
    riskImpact: 'positive' | 'negative' | 'neutral';
    stakeholderImpact: string;
    explanation: string;
  };
}

interface DecisionScenario {
  id: string;
  context: string;
  question: string;
  urgencyLevel: 'critical' | 'high' | 'medium';
  timeRemaining: string;
  stakeholdersWaiting: string[];
  options: DecisionOption[];
  mRecommendation: {
    optionId: string;
    reasoning: string;
    playbookReference: string;
    automatedActions: string[];
  };
}

interface InteractiveDecisionPointProps {
  scenario: DecisionScenario;
  onDecisionMade: (optionId: string, wasOptimal: boolean) => void;
  onContinue: () => void;
  showMGuidance?: boolean;
}

// Pre-built decision scenarios for different demo contexts
export const DECISION_SCENARIOS: Record<string, DecisionScenario> = {
  ransomware_initial: {
    id: 'ransomware_initial',
    context: 'Ransomware has been detected in your EU datacenter. Systems are being encrypted. The attacker is demanding $15M in Bitcoin within 48 hours.',
    question: 'The board wants an update in 30 minutes. What is your first action?',
    urgencyLevel: 'critical',
    timeRemaining: '30 minutes until board call',
    stakeholdersWaiting: ['CEO', 'Board Chair', 'General Counsel', 'CISO'],
    options: [
      {
        id: 'wait_for_info',
        label: 'Wait for more information',
        description: 'Ask IT to complete their assessment before briefing the board',
        isOptimal: false,
        consequence: {
          timeImpact: '+4 hours delay',
          riskImpact: 'negative',
          stakeholderImpact: 'Board loses confidence in leadership decisiveness',
          explanation: 'In a ransomware scenario, speed is critical. Waiting for perfect information while systems are being encrypted increases exposure exponentially.'
        }
      },
      {
        id: 'activate_playbook',
        label: 'Activate the Cyber Incident playbook',
        description: 'Launch pre-built response protocol with staged communications',
        isOptimal: true,
        consequence: {
          timeImpact: 'Immediate coordination',
          riskImpact: 'positive',
          stakeholderImpact: 'Board sees decisive, prepared leadership',
          explanation: 'The playbook provides immediate structure: containment actions begin, legal is notified, communications are staged, and the board receives a structured brief within minutes.'
        }
      },
      {
        id: 'call_meeting',
        label: 'Schedule an emergency meeting',
        description: 'Get all stakeholders together to discuss options',
        isOptimal: false,
        consequence: {
          timeImpact: '+2-6 hours to align',
          riskImpact: 'negative',
          stakeholderImpact: 'Confusion about who owns what',
          explanation: 'Meetings without pre-defined roles and actions create chaos. By the time everyone aligns, the situation has evolved and the meeting conclusions are outdated.'
        }
      }
    ],
    mRecommendation: {
      optionId: 'activate_playbook',
      reasoning: 'M detected this threat 47 minutes before your CISO\'s alert and had already staged the response. The Cyber Incident playbook was pre-selected based on threat indicators.',
      playbookReference: 'Playbook #89: Ransomware Attack Response',
      automatedActions: [
        'Legal team notified with disclosure requirements',
        'Board communication template prepared',
        'Containment checklist activated for IT',
        'Customer communication drafted and staged',
        'Insurance carrier notification queued'
      ]
    }
  },
  
  competitor_response: {
    id: 'competitor_response',
    context: 'Your largest competitor just announced a 40% price cut on their enterprise tier. Sales is reporting that 3 major deals ($4.2M total) have gone "on hold" pending review.',
    question: 'Your CMO wants to issue a press response. What approach do you take?',
    urgencyLevel: 'high',
    timeRemaining: '2 hours until analyst call',
    stakeholdersWaiting: ['CMO', 'VP Sales', 'CFO', 'Product Lead'],
    options: [
      {
        id: 'match_pricing',
        label: 'Match their pricing',
        description: 'Announce equivalent price cuts to neutralize their advantage',
        isOptimal: false,
        consequence: {
          timeImpact: 'Immediate but costly',
          riskImpact: 'negative',
          stakeholderImpact: 'CFO concerned about margin erosion',
          explanation: 'Price matching signals that you\'re playing their game. It erodes margins across your entire customer base, not just competitive deals, and trains the market to expect discounts.'
        }
      },
      {
        id: 'differentiate_value',
        label: 'Activate value differentiation playbook',
        description: 'Launch coordinated response emphasizing TCO and unique capabilities',
        isOptimal: true,
        consequence: {
          timeImpact: 'Same-day coordinated response',
          riskImpact: 'positive',
          stakeholderImpact: 'Sales armed with battle cards, analysts briefed on value story',
          explanation: 'The playbook coordinates: Sales gets competitive battle cards, Marketing launches TCO calculator campaign, Customer Success reaches out to at-risk accounts with ROI evidence.'
        }
      },
      {
        id: 'ignore_it',
        label: 'Stay the course',
        description: 'Don\'t respond publicly, let the market decide',
        isOptimal: false,
        consequence: {
          timeImpact: 'No immediate action',
          riskImpact: 'negative',
          stakeholderImpact: 'Sales team demoralized, deals continue to slip',
          explanation: 'Silence is interpreted as weakness. Your sales team needs ammunition, your customers need reassurance, and the market needs to hear your value story.'
        }
      }
    ],
    mRecommendation: {
      optionId: 'differentiate_value',
      reasoning: 'M\'s competitive intelligence module detected pricing signals 3 days ago and had already prepared response assets. The playbook preserves margins while protecting deals.',
      playbookReference: 'Playbook #5: Aggressive Pricing Disruption Response',
      automatedActions: [
        'Competitive battle cards distributed to sales',
        'TCO calculator updated with competitor data',
        'At-risk account list generated for CS outreach',
        'Analyst talking points prepared for CFO',
        'Customer success stories queued for marketing'
      ]
    }
  },

  regulatory_disclosure: {
    id: 'regulatory_disclosure',
    context: 'You\'ve received an SEC investigation notice requesting documents within 48 hours. A whistleblower complaint has surfaced. Stock is down 4% pre-market.',
    question: 'Investor Relations is getting calls. How do you handle external communications?',
    urgencyLevel: 'critical',
    timeRemaining: '48 hours until SEC deadline',
    stakeholdersWaiting: ['General Counsel', 'CFO', 'IR Lead', 'Board Audit Committee'],
    options: [
      {
        id: 'full_disclosure',
        label: 'Issue comprehensive press release',
        description: 'Get ahead of the story with full transparency',
        isOptimal: false,
        consequence: {
          timeImpact: 'Immediate but risky',
          riskImpact: 'negative',
          stakeholderImpact: 'Legal concerned about premature disclosure',
          explanation: 'Comprehensive disclosure before legal review can create additional liability. You may disclose more than required or frame issues in ways that harm your position.'
        }
      },
      {
        id: 'no_comment',
        label: 'Standard "no comment" response',
        description: 'Decline to comment on ongoing regulatory matters',
        isOptimal: false,
        consequence: {
          timeImpact: 'Buys time but damages trust',
          riskImpact: 'negative',
          stakeholderImpact: 'Investors assume the worst, analysts downgrade',
          explanation: '"No comment" in the modern era is interpreted as "we\'re guilty." It creates a vacuum that speculation fills, usually with worst-case narratives.'
        }
      },
      {
        id: 'coordinated_response',
        label: 'Activate regulatory response playbook',
        description: 'Launch legally-approved, staged communication protocol',
        isOptimal: true,
        consequence: {
          timeImpact: 'Immediate, legally-sound response',
          riskImpact: 'positive',
          stakeholderImpact: 'Investors see professional crisis management',
          explanation: 'The playbook provides pre-approved language that acknowledges the situation, commits to cooperation, and protects legal position while maintaining stakeholder confidence.'
        }
      }
    ],
    mRecommendation: {
      optionId: 'coordinated_response',
      reasoning: 'M\'s regulatory monitoring detected early indicators 2 weeks ago. The playbook includes pre-approved holding statements reviewed by outside counsel.',
      playbookReference: 'Playbook #46: SEC Investigation Response',
      automatedActions: [
        'Document preservation notice issued company-wide',
        'Outside counsel engagement initiated',
        'IR holding statement approved and ready',
        'Board audit committee briefing scheduled',
        'Employee communication drafted'
      ]
    }
  }
};

export default function InteractiveDecisionPoint({
  scenario,
  onDecisionMade,
  onContinue,
  showMGuidance = true
}: InteractiveDecisionPointProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showConsequence, setShowConsequence] = useState(false);
  const [showMRecommendation, setShowMRecommendation] = useState(false);
  const [decisionTimer, setDecisionTimer] = useState(30);

  // Countdown timer to create urgency
  useEffect(() => {
    if (selectedOption || decisionTimer <= 0) return;

    const timer = setInterval(() => {
      setDecisionTimer(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [selectedOption, decisionTimer]);

  const handleOptionSelect = (optionId: string) => {
    setSelectedOption(optionId);
    setShowConsequence(true);
    
    const option = scenario.options.find(o => o.id === optionId);
    if (option) {
      onDecisionMade(optionId, option.isOptimal);
    }

    // Show M's recommendation after a delay
    if (showMGuidance) {
      setTimeout(() => setShowMRecommendation(true), 2000);
    }
  };

  const selectedOptionData = scenario.options.find(o => o.id === selectedOption);
  const optimalOption = scenario.options.find(o => o.isOptimal);

  const getUrgencyColor = (level: string) => {
    switch (level) {
      case 'critical': return 'bg-red-500/20 text-red-300 border-red-500/50';
      case 'high': return 'bg-orange-500/20 text-orange-300 border-orange-500/50';
      default: return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
    }
  };

  return (
    <div className="fixed inset-0 z-[10002] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="bg-slate-900 border-slate-700 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <CardContent className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div>
              <Badge className={getUrgencyColor(scenario.urgencyLevel)}>
                {scenario.urgencyLevel.toUpperCase()} PRIORITY
              </Badge>
              <h2 className="text-2xl font-bold text-white mt-2">Decision Required</h2>
            </div>
            {!selectedOption && (
              <div className="text-right">
                <div className="text-sm text-slate-400">Time pressure</div>
                <div className={`text-2xl font-mono font-bold ${decisionTimer <= 10 ? 'text-red-400' : 'text-amber-400'}`}>
                  0:{decisionTimer.toString().padStart(2, '0')}
                </div>
              </div>
            )}
          </div>

          {/* Context */}
          <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
            <p className="text-slate-300">{scenario.context}</p>
          </div>

          {/* Stakeholders waiting */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm text-slate-400">Waiting for your decision:</span>
            {scenario.stakeholdersWaiting.map((stakeholder, i) => (
              <Badge key={i} variant="outline" className="border-slate-600 text-slate-300">
                {stakeholder}
              </Badge>
            ))}
          </div>

          {/* The Question */}
          <div className="bg-blue-950/30 rounded-lg p-4 border border-blue-500/30">
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-5 w-5 text-blue-400" />
              <span className="text-sm text-blue-300 font-medium">{scenario.timeRemaining}</span>
            </div>
            <h3 className="text-xl font-semibold text-white">{scenario.question}</h3>
          </div>

          {/* Options */}
          {!showConsequence && (
            <div className="space-y-3">
              {scenario.options.map((option) => (
                <Card 
                  key={option.id}
                  className={`bg-slate-800/50 border-slate-700 cursor-pointer transition-all hover:border-blue-500/50 hover:bg-slate-800`}
                  onClick={() => handleOptionSelect(option.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-slate-300 font-bold shrink-0">
                        {String.fromCharCode(65 + scenario.options.indexOf(option))}
                      </div>
                      <div>
                        <h4 className="font-semibold text-white mb-1">{option.label}</h4>
                        <p className="text-sm text-slate-400">{option.description}</p>
                      </div>
                      <ChevronRight className="h-5 w-5 text-slate-500 shrink-0 ml-auto" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Consequence reveal */}
          {showConsequence && selectedOptionData && (
            <div className="space-y-4">
              {/* Your choice */}
              <Card className={`border-2 ${selectedOptionData.isOptimal ? 'border-green-500/50 bg-green-950/20' : 'border-red-500/50 bg-red-950/20'}`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${selectedOptionData.isOptimal ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                      {selectedOptionData.isOptimal ? (
                        <CheckCircle className="h-6 w-6 text-green-400" />
                      ) : (
                        <XCircle className="h-6 w-6 text-red-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={selectedOptionData.isOptimal ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}>
                          Your Choice
                        </Badge>
                        <span className="font-semibold text-white">{selectedOptionData.label}</span>
                      </div>
                      
                      <div className="grid md:grid-cols-3 gap-3 mb-3">
                        <div className="bg-black/20 rounded p-2">
                          <div className="text-xs text-slate-400 mb-1">Time Impact</div>
                          <div className={`font-medium ${selectedOptionData.consequence.riskImpact === 'positive' ? 'text-green-400' : 'text-red-400'}`}>
                            {selectedOptionData.consequence.timeImpact}
                          </div>
                        </div>
                        <div className="bg-black/20 rounded p-2">
                          <div className="text-xs text-slate-400 mb-1">Risk Level</div>
                          <div className="flex items-center gap-1">
                            {selectedOptionData.consequence.riskImpact === 'positive' ? (
                              <TrendingUp className="h-4 w-4 text-green-400" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-400" />
                            )}
                            <span className={selectedOptionData.consequence.riskImpact === 'positive' ? 'text-green-400' : 'text-red-400'}>
                              {selectedOptionData.consequence.riskImpact === 'positive' ? 'Reduced' : 'Increased'}
                            </span>
                          </div>
                        </div>
                        <div className="bg-black/20 rounded p-2">
                          <div className="text-xs text-slate-400 mb-1">Stakeholder Impact</div>
                          <div className="text-sm text-slate-300">{selectedOptionData.consequence.stakeholderImpact}</div>
                        </div>
                      </div>

                      <p className="text-sm text-slate-400">{selectedOptionData.consequence.explanation}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* M's Recommendation */}
              {showMRecommendation && (
                <Card className="border-2 border-blue-500/50 bg-blue-950/20">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center shrink-0">
                        <span className="text-white font-bold">M</span>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className="bg-blue-500/20 text-blue-300">M Recommendation</Badge>
                          <span className="font-semibold text-white">{optimalOption?.label}</span>
                        </div>

                        <p className="text-sm text-slate-300 mb-4">{scenario.mRecommendation.reasoning}</p>

                        <div className="bg-black/20 rounded-lg p-3 mb-3">
                          <div className="flex items-center gap-2 mb-2">
                            <Lightbulb className="h-4 w-4 text-amber-400" />
                            <span className="text-sm font-medium text-slate-300">{scenario.mRecommendation.playbookReference}</span>
                          </div>
                          <div className="text-xs text-slate-400">Actions automatically triggered:</div>
                          <ul className="mt-2 space-y-1">
                            {scenario.mRecommendation.automatedActions.map((action, i) => (
                              <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
                                <CheckCircle className="h-3 w-3 text-green-400 shrink-0" />
                                {action}
                              </li>
                            ))}
                          </ul>
                        </div>

                        {!selectedOptionData.isOptimal && (
                          <div className="bg-amber-950/30 border border-amber-500/30 rounded-lg p-3">
                            <div className="flex items-start gap-2">
                              <Brain className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                              <p className="text-sm text-amber-200">
                                <span className="font-semibold">Learning moment:</span> M's playbook would have guided you to the optimal response, 
                                saving time and reducing risk. This is why prepared organizations outperform reactive ones.
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Continue button */}
              {showMRecommendation && (
                <div className="flex justify-center pt-4">
                  <Button 
                    onClick={onContinue}
                    className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white px-8 py-6 text-lg"
                  >
                    Continue Demo
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
