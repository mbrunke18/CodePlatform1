# M - Strategic Execution Operating System

## Overview
M is the Strategic Execution Operating System for Fortune 1000 companies, designed to eliminate the 20-50 hours organizations spend getting organized after a strategic event hits. Unlike crisis tools or project management platforms, M is the bridge between strategic preparation and operational execution that neither category provides.

When M triggers, it auto-creates your Jira project, assigns every task, stages every document, and unlocks pre-approved budgets—all within 12 minutes. Teams don't learn M—M comes to them in tools they already use. This is the difference between "please adopt our platform" and "your existing workflow just got supercharged."

M operates through four phases: PREPARE, MONITOR, EXECUTE, and LEARN, acting as the execution layer for strategic velocity. It leverages AI-driven trigger monitoring and an extensive library of 148 strategic playbooks across 8 domains. The platform fosters a human-AI partnership, where AI monitors and recommends, while human executives define playbooks, approve activations, and make final decisions. Its core tagline is "Success Favors the Prepared."

## Value Proposition & ROI

**Core Value:** Eliminate post-trigger planning phase entirely.

| Value Category | Metric | Typical Savings |
|----------------|--------|-----------------|
| Planning elimination | Hours saved | 20-50 hrs × $500/hr = $10K-25K per event |
| Faster execution | Revenue protected | $500K-2M per major event |
| Executive time | C-suite hours recovered | 50+ hrs/event × $1,000/hr = $50K+ |
| Tool consolidation | Reduced platform sprawl | $50-100K annually |

**Total value per major event: $60K-$2M+** — M pays for itself on the first significant event.

## Competitive Differentiation

| Capability | Crisis Tools (Everbridge, etc.) | PM Tools (Jira, Asana) | M |
|------------|--------------------------------|------------------------|---|
| Alert/notify stakeholders | Yes | No | Yes |
| Pre-built response playbooks | No | No | Yes |
| Auto-create project structure | No | No | Yes |
| Assign tasks with acceptance criteria | No | Manual | Auto |
| Stage documents and templates | No | No | Yes |
| Unlock pre-approved budgets | No | No | Yes |
| Sync to existing PM tools | No | N/A | Yes |
| Institutional learning loop | No | No | Yes |

**M isn't competing with crisis tools OR project tools. M owns the category between strategic preparation and operational execution.**

## Enterprise Moat Strategy
Once a Fortune 1000 company has 50 playbooks syncing to Jira with bi-directional updates:
- M becomes embedded in their PM workflow
- Historical execution data lives in M
- Playbook library represents months of organizational knowledge
- Sync configurations are non-trivial to recreate

The integration layer IS the moat.

## User Preferences
- Preferred communication style: Simple, everyday language
- Valued prioritization approach with phase-by-phase implementation
- Maintain core product vision of human-AI partnership for strategic velocity
- Executive professional language required across UI/UX

## System Architecture
M operates on a 4-phase methodology (PREPARE, MONITOR, EXECUTE, LEARN) facilitating a human-AI partnership. AI handles monitoring, pattern detection, recommendations, and learning, while executives maintain decision-making control, ensuring augmentation over full automation.

**UI/UX Decisions:**
- **Design:** Modern, enterprise-grade interface focused on decision velocity and human-AI collaboration.
- **Theme:** Full dark/light mode support with localStorage persistence and WCAG AAA contrast compliance.
- **Navigation:** Sidebar with collapsible 4-phase sections for platform pages and a light topbar for marketing pages.
- **Branding:** Consistent "M - Strategic Execution Operating System" branding.
- **Design System:** Established with 60+ utility classes.

**Technical Implementations & Feature Specifications:**
- **Phases:**
    - **PREPARE:** Users build and customize playbooks from 148 templates.
    - **MONITOR:** AI monitors 12 intelligence signals for trigger conditions, recommending playbook activation. Includes a Signal Control Center UI (16 categories, 92 data points), Visual Trigger Builder, and Alert Command Center.
    - **EXECUTE:** Orchestrates 12-minute coordinated responses upon activation, using pre-approved budgets and enterprise integrations. Features a Command Center for real-time coordination.
    - **LEARN:** Captures outcomes, conducts AI-powered analysis, and suggests playbook refinements. Includes a Signal-to-Playbook Mapper.
- **Execution Plan Sync & Integration Architecture:**
    - **ExecutionPlanSyncService:** Bi-directional sync engine with platform adapters for Jira, Asana, Monday.com, MS Project, and ServiceNow. Supports idempotent task mapping, conflict resolution, and real-time sync status via WebSocket.
    - **DocumentTemplateEngine:** Auto-generates execution documents from playbook data with variable interpolation.
    - **FileExportService:** Exports to DOCX, PDF, Markdown, XLSX, CSV, and MS Project XML formats.
    - **CredentialEncryptionService:** AES-256-GCM encryption for OAuth credentials at rest. Handles nested objects and arrays. Requires `CREDENTIAL_ENCRYPTION_KEY` env var (32+ char hex string) in production.
    - **UI Components:** SyncManagerPanel, DocumentTemplateDesigner, PreApprovedResourcesAdmin.
- **Authentication:** Replit OIDC integration with session management via PostgreSQL.
- **Dashboard Metrics:** Live metrics for active scenarios, teams, on-track percentage, weak signals, and Oracle patterns.
- **Scenario Library:** Real-time search/filtering, instant playbook search, category browsing.
- **Portal Homepage:** Clean entry portal with hero section, stats bar, 4-Phase Navigation Grid, Quick Access cards, and consistent footer.
- **Intelligence Signals Framework:** Backend service for CRUD on data sources, triggers, alerts, weak signals, with a playbook recommendation engine.
- **Demos:** Four complementary experiences including a Transformational Demo (`/transformational-demo`) with a ChaosSimulator, InteractiveDecisionPoint, and OrganizationReadinessScore across 11 phases.
- **New User Journey:** A 7-step guided onboarding experience covering welcome, organization profile, strategic priorities, playbook selection, signal configuration, success metrics, and a Command Center preview.
- **Investor Presentation:** Full-featured presenter mode with a 5-act structure at `/investor-presentation`.

**System Design Choices:**
- **Frontend**: React 18, TypeScript, Vite, Radix UI, shadcn/ui, Tailwind CSS, TanStack Query v5, Wouter, React Hook Form, Zod.
- **Backend**: Node.js, Express.js, TypeScript.
- **Database**: PostgreSQL (Neon serverless) with Drizzle ORM.
- **Authentication**: Replit OIDC with Passport.js and Express sessions.
- **Real-time**: Socket.IO WebSocket server.
- **AI Services**: Primarily OpenAI GPT-4o.

## External Dependencies
- **AI Services**: OpenAI GPT-4o
- **Database Services**: Neon PostgreSQL (development) / AWS RDS PostgreSQL (production)
- **Authentication**: Replit OIDC (development) / AWS Cognito (production)
- **Enterprise Integrations**: Salesforce, HubSpot, ServiceNow, Jira, Slack, Microsoft Teams, Google Workspace, Outlook/Exchange, AWS CloudWatch, Workday, Okta, Microsoft Active Directory

## Integration Notes
- **Jira Integration**: User dismissed native Replit Jira connector setup. The ExecutionPlanSyncService includes a fully-implemented JiraAdapter that works with manual OAuth credentials. If Jira integration is needed later, user can either:
  1. Re-enable the Replit Jira connector through settings
  2. Provide Jira OAuth credentials (JIRA_CLIENT_ID, JIRA_CLIENT_SECRET, JIRA_CLOUD_ID) as secrets
  
  Current implementation uses mock/demo mode for Jira when credentials are not available.