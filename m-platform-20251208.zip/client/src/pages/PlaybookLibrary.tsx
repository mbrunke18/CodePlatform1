import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  BookOpen, 
  Search, 
  Filter,
  Shield, 
  TrendingDown, 
  Users, 
  Briefcase, 
  AlertTriangle,
  Building2,
  Flame,
  Scale,
  ChevronRight,
  Target,
  Clock,
  Star,
  Play,
  Edit,
  Zap
} from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import PageLayout from '@/components/layout/PageLayout';
import PlaybookCustomizationWizard from '@/components/playbook/PlaybookCustomizationWizard';
import { PhaseProgressBar } from '@/components/playbook/PhaseProgressBar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// Domain icon mapping
const DOMAIN_ICONS: Record<string, any> = {
  'Market Dynamics': Target,
  'Financial Strategy': TrendingDown,
  'Operational Excellence': Flame,
  'Regulatory & Compliance': Scale,
  'Technology & Innovation': AlertTriangle,
  'Talent & Leadership': Users,
  'Brand & Reputation': Building2,
  'Market Opportunities': Star
};

const DOMAIN_COLORS: Record<string, string> = {
  'Market Dynamics': 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300',
  'Financial Strategy': 'bg-green-100 dark:bg-green-950 text-green-700 dark:text-green-300',
  'Operational Excellence': 'bg-orange-100 dark:bg-orange-950 text-orange-700 dark:text-orange-300',
  'Regulatory & Compliance': 'bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300',
  'Technology & Innovation': 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300',
  'Talent & Leadership': 'bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300',
  'Brand & Reputation': 'bg-yellow-100 dark:bg-yellow-950 text-yellow-700 dark:text-yellow-300',
  'Market Opportunities': 'bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300'
};

export default function PlaybookLibrary() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPlaybook, setSelectedPlaybook] = useState<any>(null);
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Fetch organizations for context first (needed for playbook query)
  const { data: organizations = [] } = useQuery<any[]>({ 
    queryKey: ['/api/organizations'] 
  });
  const organizationId = organizations[0]?.id;

  // Fetch all playbook library data with readiness scores for the organization
  const { data: libraryData = { domains: [], categories: [], playbooks: [] }, isLoading } = useQuery<any>({
    queryKey: ['/api/playbook-library', { organizationId }],
    queryFn: async () => {
      const url = organizationId 
        ? `/api/playbook-library?organizationId=${organizationId}`
        : '/api/playbook-library';
      const response = await fetch(url);
      if (!response.ok) throw new Error('Failed to fetch playbook library');
      return response.json();
    },
  });

  // Fetch users to get a valid createdBy ID
  const { data: users = [] } = useQuery<any[]>({ 
    queryKey: ['/api/users'],
    enabled: !!organizationId
  });

  // Fetch playbook insights for selected playbook
  const { data: playbookInsights, isLoading: insightsLoading } = useQuery<any>({
    queryKey: ['/api/playbook-library', selectedPlaybook?.id, 'insights'],
    enabled: !!selectedPlaybook?.id,
  });

  // Playbook activation mutation (Path B)
  const activatePlaybookMutation = useMutation({
    mutationFn: async (playbookId: string) => {
      const response = await apiRequest('POST', `/api/playbook-library/${playbookId}/activate`, {
        scenarioId: `scenario-${Date.now()}`,
      });
      return response.json();
    },
    onSuccess: (result) => {
      toast({
        title: 'Playbook Activated',
        description: `12-minute execution window initiated. ${result.stakeholders} stakeholders notified.`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/dynamic-strategy/status'] });
    },
    onError: (error) => {
      toast({
        title: 'Activation Failed',
        description: error instanceof Error ? error.message : 'Unable to activate playbook',
        variant: 'destructive',
      });
    },
  });

  // Quick-start drill mutation
  const quickStartDrillMutation = useMutation({
    mutationFn: async (playbookId: string) => {
      if (!organizationId) {
        throw new Error('No organization found');
      }
      
      const playbook = libraryData.playbooks.find((p: any) => p.id === playbookId);
      const now = new Date();
      
      // Use first available user (required for createdBy foreign key)
      const validUsers = users && Array.isArray(users) ? users : [];
      const createdById = validUsers[0]?.id;
      
      if (!createdById) {
        throw new Error('No user available to create drill. Please refresh the page.');
      }
      
      const drillData = {
        organizationId,
        playbookId,
        drillName: `Quick Drill: ${playbook?.name || 'Practice Drill'}`,
        drillType: 'simulation',
        scenarioDescription: playbook?.description || 'Practice drill simulation',
        scheduledDate: now, // Date object for Drizzle validation
        scheduledTime: now.toTimeString().slice(0, 5), // HH:MM format
        estimatedDuration: 30,
        invitedParticipants: [],
        actualParticipants: [],
        status: 'scheduled',
        complications: null,
        createdBy: createdById,
      };
      
      const drillResponse = await apiRequest('POST', '/api/practice-drills', drillData);
      const drill = await drillResponse.json();
      
      // Immediately start the drill
      await apiRequest('POST', `/api/practice-drills/${drill.id}/start`, {});
      
      return drill;
    },
    onSuccess: (drill) => {
      toast({
        title: 'Practice Drill Started',
        description: 'Live execution is now running',
      });
      // Navigate to live execution page
      setLocation(`/practice-drills/${drill.id}/live`);
    },
    onError: (error: any) => {
      console.error('Quick start drill error:', error);
      toast({
        title: 'Error',
        description: `Failed to start practice drill: ${error.message || 'Unknown error'}`,
        variant: 'destructive',
      });
    },
  });

  // Filter playbooks based on search and selections
  const filteredPlaybooks = (libraryData?.playbooks || []).filter((playbook: any) => {
    const matchesSearch = searchQuery === '' || 
      playbook.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      playbook.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDomain = selectedDomain === 'all' || playbook.domainId === selectedDomain;
    const matchesCategory = selectedCategory === 'all' || playbook.categoryId === selectedCategory;
    
    return matchesSearch && matchesDomain && matchesCategory;
  });

  // Get categories for selected domain
  const availableCategories = selectedDomain === 'all' 
    ? (libraryData?.categories || [])
    : (libraryData?.categories || []).filter((cat: any) => cat.domainId === selectedDomain);

  if (isLoading) {
    return (
      <PageLayout>
        <div className="p-6">
          <div className="animate-pulse">Loading Strategic Playbook Library...</div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <div className="px-4 sm:px-6 py-4 sm:py-6 space-y-4 sm:space-y-6" data-testid="playbook-library-page">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold" data-testid="page-title">
              Strategic Playbook Library
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground mt-1">
              <span className="hidden sm:inline">148 decision frameworks for growth, defense, and transformation across 8 operational domains</span>
              <span className="sm:hidden">148 strategic playbooks across 8 domains</span>
            </p>
          </div>
          <div className="flex items-center gap-3 sm:gap-4">
            <Badge variant="outline" className="text-sm sm:text-lg px-3 sm:px-4 py-1.5 sm:py-2" data-testid="badge-total-playbooks">
              {libraryData?.playbooks?.length || 0} Playbooks
            </Badge>
            <BookOpen className="h-8 w-8 sm:h-12 sm:w-12 text-[#0A1F44] dark:text-[#D4AF37]" />
          </div>
        </div>

        {/* Prominent Domain Selection - NEW */}
        <Card className="bg-gradient-to-br .section-background dark:from-blue-950/30 dark:to-purple-950/30">
          <CardHeader className="pb-2 sm:pb-4">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
              <Filter className="h-4 w-4 sm:h-5 sm:w-5" />
              Browse by Strategic Domain
            </CardTitle>
            <CardDescription className="text-xs sm:text-sm">
              <span className="hidden sm:inline">Select a domain to explore playbooks, or view all 148 playbooks across all domains</span>
              <span className="sm:hidden">Select a domain to explore playbooks</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-2 sm:gap-3">
              {/* All Domains Option */}
              <button
                onClick={() => {
                  setSelectedDomain('all');
                  setSelectedCategory('all');
                }}
                className={`p-2 sm:p-4 rounded-lg border-2 transition-all ${
                  selectedDomain === 'all'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 shadow-md sm:scale-105'
                    : 'border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700 hover:shadow'
                }`}
                data-testid="domain-card-all"
              >
                <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center justify-center mx-auto mb-1 sm:mb-2">
                  <BookOpen className="h-4 w-4 sm:h-6 sm:w-6" />
                </div>
                <div className="text-[10px] sm:text-sm font-semibold text-center mb-0.5 sm:mb-1">All</div>
                <div className="text-[9px] sm:text-xs text-muted-foreground text-center hidden sm:block">
                  {libraryData?.playbooks?.length || 0} playbooks
                </div>
              </button>

              {/* Domain Cards */}
              {(libraryData?.domains || []).map((domain: any) => {
                const DomainIcon = DOMAIN_ICONS[domain.name] || BookOpen;
                const domainPlaybookCount = (libraryData?.playbooks || []).filter(
                  (p: any) => p.domainId === domain.id
                ).length;
                const isSelected = selectedDomain === domain.id;
                const shortName = domain.name.split(' ')[0];

                return (
                  <button
                    key={domain.id}
                    onClick={() => {
                      setSelectedDomain(domain.id);
                      setSelectedCategory('all');
                    }}
                    className={`p-2 sm:p-4 rounded-lg border-2 transition-all ${
                      isSelected
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 shadow-md sm:scale-105'
                        : 'border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700 hover:shadow'
                    }`}
                    data-testid={`domain-card-${domain.code}`}
                  >
                    <div className={`w-8 h-8 sm:w-12 sm:h-12 rounded-lg ${DOMAIN_COLORS[domain.name] || 'bg-gray-100'} flex items-center justify-center mx-auto mb-1 sm:mb-2`}>
                      <DomainIcon className="h-4 w-4 sm:h-6 sm:w-6" />
                    </div>
                    <div className="text-[10px] sm:text-sm font-semibold text-center mb-0.5 sm:mb-1">
                      <span className="hidden sm:inline">{domain.name}</span>
                      <span className="sm:hidden">{shortName}</span>
                    </div>
                    <div className="text-[9px] sm:text-xs text-muted-foreground text-center hidden sm:block">
                      {domainPlaybookCount} playbooks
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Search and Filters */}
        <Card>
          <CardContent className="pt-4 sm:pt-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <div className="sm:col-span-2 lg:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 sm:top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search playbooks..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-9 sm:h-10 text-sm sm:text-base"
                    data-testid="input-search"
                  />
                </div>
              </div>

              <Select value={selectedDomain} onValueChange={setSelectedDomain}>
                <SelectTrigger data-testid="select-domain" className="h-9 sm:h-10 text-sm">
                  <SelectValue placeholder="All Domains" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all" data-testid="option-domain-all">All Domains</SelectItem>
                  {(libraryData?.domains || []).map((domain: any) => (
                    <SelectItem key={domain.id} value={domain.id} data-testid={`option-domain-${domain.code}`}>
                      {domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger data-testid="select-category" className="h-9 sm:h-10 text-sm">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {availableCategories.map((category: any) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Playbook List */}
          <div className="lg:col-span-2 space-y-3 sm:space-y-4">
            <div className="text-xs sm:text-sm text-muted-foreground" data-testid="text-results-count">
              Showing {filteredPlaybooks.length} playbook{filteredPlaybooks.length !== 1 ? 's' : ''}
            </div>

            <div className="space-y-3">
              {filteredPlaybooks.map((playbook: any) => {
                const domain = libraryData.domains.find((d: any) => d.id === playbook.domainId);
                const category = libraryData.categories.find((c: any) => c.id === playbook.categoryId);
                const DomainIcon = domain ? DOMAIN_ICONS[domain.name] || BookOpen : BookOpen;
                const domainColor = domain ? DOMAIN_COLORS[domain.name] || '' : '';

                return (
                  <Card
                    key={playbook.id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedPlaybook?.id === playbook.id ? 'ring-2 ring-[#0A1F44] dark:ring-[#D4AF37]' : ''
                    }`}
                    onClick={() => setSelectedPlaybook(playbook)}
                    data-testid={`card-playbook-${playbook.id}`}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 page-background">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={domainColor} data-testid={`badge-domain-${playbook.id}`}>
                              <DomainIcon className="h-3 w-3 mr-1" />
                              {domain?.name}
                            </Badge>
                            {playbook.preparednessLevel && (
                              <Badge variant="outline" data-testid={`badge-level-${playbook.id}`}>
                                {playbook.preparednessLevel}
                              </Badge>
                            )}
                          </div>
                          <div className="my-2">
                            <PhaseProgressBar
                              prepareScore={playbook.prepareScore || 0}
                              monitorScore={playbook.monitorScore || 0}
                              executeScore={playbook.executeScore || 0}
                              learnScore={playbook.learnScore || 0}
                              compact={true}
                            />
                          </div>
                          <CardTitle className="text-lg" data-testid={`text-title-${playbook.id}`}>
                            {playbook.name}
                          </CardTitle>
                          <CardDescription className="mt-1">
                            {category?.name}
                          </CardDescription>
                        </div>
                        <ChevronRight className="h-5 w-5 text-muted-foreground" />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {playbook.description}
                      </p>
                      <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {playbook.targetResponseTime || '12 mins'}
                        </div>
                        {playbook.stakeholderCount && (
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {playbook.stakeholderCount} stakeholders
                          </div>
                        )}
                        {playbook.taskCount && (
                          <div className="flex items-center gap-1">
                            <Target className="h-3 w-3" />
                            {playbook.taskCount} tasks
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

              {filteredPlaybooks.length === 0 && (
                <div className="text-center py-12 text-muted-foreground" data-testid="text-no-results">
                  <BookOpen className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p className="font-medium">No playbooks found</p>
                  <p className="text-sm mt-1">Try adjusting your search or filters</p>
                </div>
              )}
            </div>
          </div>

          {/* Playbook Detail Panel */}
          <div className="lg:col-span-1">
            {selectedPlaybook ? (
              <Card className="sticky top-6 max-h-[calc(100vh-3rem)]">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex-1 page-background">
                      <CardTitle data-testid="text-detail-title">{selectedPlaybook.name}</CardTitle>
                      <CardDescription>Playbook #{selectedPlaybook.playbookNumber}</CardDescription>
                    </div>
                    {selectedPlaybook.primaryExecutiveRole && (
                      <Badge variant="outline" className="ml-2" data-testid="badge-exec-role">
                        {selectedPlaybook.primaryExecutiveRole}
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 overflow-y-auto max-h-[calc(100vh-12rem)]">
                  {/* Preparedness Score - NEW DATA-DRIVEN SECTION */}
                  {!insightsLoading && playbookInsights && (
                    <div className="space-y-3 pb-4 border-b bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 -mx-6 -mt-4 px-6 pt-4 rounded-t-lg">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-sm">Playbook Readiness</h4>
                        <Badge 
                          variant={
                            playbookInsights.readinessStatus === 'ready' ? 'default' :
                            playbookInsights.readinessStatus === 'in_progress' ? 'secondary' :
                            'outline'
                          }
                          data-testid="badge-readiness-status"
                        >
                          {playbookInsights.readinessStatus === 'ready' ? '✓ Ready' :
                           playbookInsights.readinessStatus === 'in_progress' ? '◐ In Progress' :
                           '○ Not Started'}
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Preparedness Score</span>
                          <span className="font-bold text-lg" data-testid="text-preparedness-score">
                            {playbookInsights.preparednessScore}%
                          </span>
                        </div>
                        <Progress value={playbookInsights.preparednessScore} className="h-2" data-testid="progress-preparedness" />
                        <p className="text-xs text-muted-foreground">
                          {playbookInsights.preparednessScore >= 95 
                            ? 'All sections complete - ready for activation'
                            : playbookInsights.preparednessScore >= 80
                            ? 'Core template loaded - customize remaining 20%'
                            : 'Complete remaining sections to increase readiness'}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Situation Definition Section - ENHANCED WITH METRICS */}
                  <div className="space-y-3 pb-3 border-b">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-sm">1. Situation Definition</h4>
                      {playbookInsights?.sectionCompletion?.situation && (
                        <Badge variant="outline" className="text-xs" data-testid="badge-section-1">✓</Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <div className="text-xs text-muted-foreground">Severity Score</div>
                        <div className="text-sm font-medium" data-testid="text-severity">
                          {playbookInsights?.severityScore || selectedPlaybook.severityScore || 0}/100
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground">Time Window</div>
                        <div className="text-sm font-medium" data-testid="text-time-sensitivity">
                          {playbookInsights?.timeSensitivity || selectedPlaybook.timeSensitivity || 24}h
                        </div>
                      </div>
                      <div className="col-span-2">
                        <div className="text-xs text-muted-foreground">Activation Frequency</div>
                        <Badge 
                          variant={
                            (playbookInsights?.activationFrequencyTier || selectedPlaybook.activationFrequencyTier) === 'HIGH' ? 'default' :
                            (playbookInsights?.activationFrequencyTier || selectedPlaybook.activationFrequencyTier) === 'MEDIUM' ? 'secondary' :
                            'outline'
                          }
                          className="mt-1"
                          data-testid="badge-frequency"
                        >
                          {playbookInsights?.activationFrequencyTier || selectedPlaybook.activationFrequencyTier || 'MEDIUM'}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Stakeholder Matrix Section - ENHANCED WITH METRICS */}
                  <div className="space-y-2 pb-3 border-b">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-sm">2. Stakeholder Matrix</h4>
                      {playbookInsights?.sectionCompletion?.stakeholders && (
                        <Badge variant="outline" className="text-xs" data-testid="badge-section-2">✓</Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-muted/50 p-2 rounded">
                        <div className="text-xs text-muted-foreground">Tier 1</div>
                        <div className="text-lg font-bold" data-testid="text-tier1">
                          {playbookInsights?.stakeholderReadiness?.tier1Count || selectedPlaybook.tier1Count || '8-12'}
                        </div>
                      </div>
                      <div className="bg-muted/50 p-2 rounded">
                        <div className="text-xs text-muted-foreground">Tier 2</div>
                        <div className="text-lg font-bold" data-testid="text-tier2">
                          {playbookInsights?.stakeholderReadiness?.tier2Count || selectedPlaybook.tier2Count || '30-50'}
                        </div>
                      </div>
                      <div className="bg-muted/50 p-2 rounded">
                        <div className="text-xs text-muted-foreground">Tier 3</div>
                        <div className="text-lg font-bold" data-testid="text-tier3">
                          {playbookInsights?.stakeholderReadiness?.tier3Count || selectedPlaybook.tier3Count || '100-200'}
                        </div>
                      </div>
                    </div>
                    {playbookInsights?.stakeholderReadiness && (
                      <div className="text-xs text-muted-foreground mt-2">
                        Total: {playbookInsights.stakeholderReadiness.totalStakeholders} stakeholders + {playbookInsights.stakeholderReadiness.externalPartners} external partners
                      </div>
                    )}
                  </div>

                  {/* Decision Trees Section */}
                  <div className="space-y-2 pb-3 border-b">
                    <h4 className="font-semibold text-sm">3. Decision Trees (85% Pre-filled)</h4>
                    <p className="text-xs text-muted-foreground">
                      {selectedPlaybook.playbookNumber === 4 
                        ? '2 decision checkpoints with 5 pre-mapped options'
                        : 'Pre-mapped decision checkpoints and response pathways'}
                    </p>
                    {selectedPlaybook.playbookNumber === 4 && (
                      <div className="text-xs space-y-1 mt-2">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-primary rounded-full" />
                          <span>Checkpoint 1: Severity Assessment (T+3:00)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-primary rounded-full" />
                          <span>Checkpoint 2: Response Strategy (T+4:30)</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Communication Templates Section */}
                  <div className="space-y-2 pb-3 border-b">
                    <h4 className="font-semibold text-sm">4. Communication Templates (80% Pre-filled)</h4>
                    <p className="text-xs text-muted-foreground">
                      {selectedPlaybook.playbookNumber === 4 
                        ? '4 pre-drafted templates ready to customize'
                        : 'Pre-drafted templates for stakeholder communication'}
                    </p>
                    {selectedPlaybook.playbookNumber === 4 && (
                      <div className="text-xs space-y-1 mt-2">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-primary rounded-full" />
                          <span>Media Statement</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-primary rounded-full" />
                          <span>Customer Email (CEO)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-primary rounded-full" />
                          <span>Sales Talking Points</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-primary rounded-full" />
                          <span>Board Memo</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Task Sequences Section */}
                  <div className="space-y-2 pb-3 border-b">
                    <h4 className="font-semibold text-sm">5. Task Sequences (75% Pre-filled)</h4>
                    <p className="text-xs text-muted-foreground">
                      {selectedPlaybook.playbookNumber === 4 
                        ? '13 pre-assigned tasks from T+0:00 to T+12:00'
                        : 'Minute-by-minute execution timeline with pre-assigned owners'}
                    </p>
                    {selectedPlaybook.playbookNumber === 4 && (
                      <div className="flex items-center justify-between mt-2 text-xs">
                        <span className="text-muted-foreground">Execution Timeline:</span>
                        <span className="font-medium">T+0:00 → T+12:00</span>
                      </div>
                    )}
                  </div>

                  {/* Budget Authority Section - ENHANCED WITH METRICS */}
                  <div className="space-y-2 pb-3 border-b">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-sm">6. Budget Authority</h4>
                      {playbookInsights?.sectionCompletion?.budget && (
                        <Badge variant="outline" className="text-xs" data-testid="badge-section-6">✓</Badge>
                      )}
                    </div>
                    {playbookInsights?.budgetReadiness && (
                      <>
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-muted-foreground">Pre-Approved Budget</span>
                          <span className="text-sm font-medium" data-testid="text-budget">
                            ${(playbookInsights.budgetReadiness.preApprovedBudget / 1000000).toFixed(1)}M
                          </span>
                        </div>
                        {playbookInsights.budgetReadiness.budgetApprovalRequired && (
                          <div className="text-xs text-muted-foreground">
                            * Board approval required above this threshold
                          </div>
                        )}
                        <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
                          <div className="bg-muted/50 p-2 rounded text-center">
                            <div className="text-muted-foreground">Vendor Contracts</div>
                            <div className="font-bold text-sm" data-testid="text-vendor-contracts">
                              {playbookInsights.budgetReadiness.vendorContractsCount}
                            </div>
                          </div>
                          <div className="bg-muted/50 p-2 rounded text-center">
                            <div className="text-muted-foreground">External Resources</div>
                            <div className="font-bold text-sm" data-testid="text-external-resources">
                              {playbookInsights.budgetReadiness.externalResourcesCount}
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                  {/* Trigger Monitoring Status - NEW DATA-DRIVEN SECTION */}
                  {playbookInsights?.triggerStatus && (
                    <div className="space-y-2 pb-3 border-b bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 -mx-6 px-6 py-3 rounded">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-sm">AI Trigger Monitoring</h4>
                        <Badge variant={playbookInsights.triggerStatus.monitoringActive ? 'default' : 'outline'} className="text-xs" data-testid="badge-monitoring-status">
                          {playbookInsights.triggerStatus.monitoringActive ? '● Live' : '○ Inactive'}
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-muted-foreground">AI Confidence</span>
                          <span className="text-sm font-medium" data-testid="text-ai-confidence">
                            {playbookInsights.triggerStatus.aiConfidence}%
                          </span>
                        </div>
                        <Progress value={playbookInsights.triggerStatus.aiConfidence} className="h-1.5" data-testid="progress-ai-confidence" />
                        <p className="text-xs text-muted-foreground">
                          Last monitored: {new Date(playbookInsights.triggerStatus.lastMonitoredAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Success Metrics Section */}
                  <div className="space-y-2 pb-3 border-b">
                    <h4 className="font-semibold text-sm">7. Success Metrics (80% Pre-filled)</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-muted-foreground">Response Speed Target</span>
                        <span className="text-sm font-medium" data-testid="text-response-target">
                          {selectedPlaybook.targetResponseSpeed || selectedPlaybook.targetExecutionTime || 12} min
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-muted-foreground">Stakeholder Reach</span>
                        <span className="text-sm font-medium" data-testid="text-stakeholder-reach">
                          {((selectedPlaybook.targetStakeholderReach || 1.0) * 100).toFixed(0)}%
                        </span>
                      </div>
                      {selectedPlaybook.outcomeMetrics && selectedPlaybook.outcomeMetrics.length > 0 && (
                        <div className="text-xs text-muted-foreground mt-2">
                          + {selectedPlaybook.outcomeMetrics.length} domain-specific outcome metrics
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Lessons Learned Section */}
                  <div className="space-y-2 pb-3 border-b">
                    <h4 className="font-semibold text-sm">8. Lessons Learned (Post-Execution)</h4>
                    <p className="text-xs text-muted-foreground">
                      {selectedPlaybook.historicalSuccessRate > 0 
                        ? `Historical success rate: ${(selectedPlaybook.historicalSuccessRate * 100).toFixed(0)}% across ${selectedPlaybook.averageActivationFrequency || 'multiple'} activations`
                        : 'Not yet executed - lessons will be captured after first activation'}
                    </p>
                  </div>

                  <div className="pt-2 space-y-2">
                    <Link href={`/playbook-library/${selectedPlaybook.id}`}>
                      <Button
                        className="w-full bg-[#0A1F44] hover:bg-[#0A1F44]/90 dark:bg-[#D4AF37] dark:hover:bg-[#D4AF37]/90"
                        data-testid="button-view-details"
                      >
                        <BookOpen className="h-4 w-4 mr-2" />
                        View Full Details
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                      onClick={() => setIsCustomizing(true)}
                      data-testid="button-customize-playbook"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Customize This Playbook
                    </Button>
                    <Button 
                      className="w-full bg-blue-600 hover:bg-blue-700" 
                      onClick={() => activatePlaybookMutation.mutate(selectedPlaybook.id)}
                      disabled={activatePlaybookMutation.isPending}
                      data-testid="button-activate-playbook"
                    >
                      <Zap className="h-4 w-4 mr-2" />
                      {activatePlaybookMutation.isPending ? 'Activating...' : 'Activate This Playbook'}
                    </Button>
                    <Button 
                      variant="default"
                      className="w-full bg-green-600 hover:bg-green-700"
                      onClick={() => quickStartDrillMutation.mutate(selectedPlaybook.id)}
                      disabled={quickStartDrillMutation.isPending || !organizationId}
                      data-testid="button-quick-start-drill"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      {quickStartDrillMutation.isPending ? 'Starting Drill...' : 'Quick Start Practice Drill'}
                    </Button>
                    <Link href={`/practice-drills?playbookId=${selectedPlaybook.id}`}>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        data-testid="button-schedule-drill"
                      >
                        <Target className="h-4 w-4 mr-2" />
                        Schedule Practice Drill
                      </Button>
                    </Link>
                  </div>

                  <div className="pt-4 border-t">
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div className="flex justify-between">
                        <span>Template Completion:</span>
                        <span className="font-medium">80% Pre-filled</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Last Executed:</span>
                        <span>{selectedPlaybook.historicalSuccessRate ? 
                          `${(selectedPlaybook.historicalSuccessRate * 100).toFixed(0)}% success rate` : 
                          'Not yet executed'}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="sticky top-6">
                <CardContent className="pt-6">
                  <div className="text-center py-12 text-muted-foreground">
                    <BookOpen className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p className="font-medium">Select a playbook</p>
                    <p className="text-sm mt-1">Click any playbook to view details</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Domain Overview */}
        <Card>
          <CardHeader>
            <CardTitle>Strategic Domain Coverage</CardTitle>
            <CardDescription>Strategic decision frameworks across all operational domains</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {libraryData.domains.map((domain: any) => {
                const playbooksInDomain = libraryData.playbooks.filter(
                  (p: any) => p.domainId === domain.id
                ).length;
                const DomainIcon = DOMAIN_ICONS[domain.name] || BookOpen;
                const domainColor = DOMAIN_COLORS[domain.name] || '';

                return (
                  <div
                    key={domain.id}
                    className={`p-4 rounded-lg cursor-pointer transition-all hover:shadow-md ${domainColor}`}
                    onClick={() => {
                      setSelectedDomain(domain.id);
                      setSelectedCategory('all');
                    }}
                    data-testid={`card-domain-${domain.id}`}
                  >
                    <DomainIcon className="h-6 w-6 mb-2" />
                    <div className="font-medium text-sm mb-1">{domain.name}</div>
                    <div className="text-xs opacity-75" data-testid={`text-domain-count-${domain.id}`}>
                      {playbooksInDomain} playbooks
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Playbook Customization Wizard */}
      {selectedPlaybook && organizationId && (
        <PlaybookCustomizationWizard
          playbook={selectedPlaybook}
          organizationId={organizationId}
          isOpen={isCustomizing}
          onClose={() => setIsCustomizing(false)}
        />
      )}
    </PageLayout>
  );
}
