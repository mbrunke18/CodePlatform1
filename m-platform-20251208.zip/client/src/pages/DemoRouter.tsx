import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Zap, Briefcase, ArrowRight, Play, Presentation, FileText } from "lucide-react";
import { useLocation } from "wouter";
import StandardNav from "@/components/layout/StandardNav";
import Footer from "@/components/layout/Footer";

export default function DemoRouter() {
  const [, setLocation] = useLocation();

  const demoOptions = [
    {
      id: 'quick',
      title: 'Quick Demo',
      duration: '3 minutes',
      description: 'See a playbook activate and tasks deploy in real-time.',
      icon: Zap,
      color: 'from-emerald-500 to-teal-500',
      borderColor: 'border-emerald-500/30 hover:border-emerald-500',
      path: '/demo/live-activation',
      badge: 'Most Popular',
      badgeColor: 'bg-emerald-500'
    },
    {
      id: 'simulation',
      title: 'Executive Simulation',
      duration: '12 minutes',
      description: 'Step into the role of a Fortune 500 CSO. Experience the full 4-phase cycle.',
      icon: Briefcase,
      color: 'from-purple-500 to-violet-500',
      borderColor: 'border-purple-500/30 hover:border-purple-500',
      path: '/executive-simulation',
      badge: 'Full Experience',
      badgeColor: 'bg-purple-500'
    },
    {
      id: 'industry',
      title: 'Industry Demos',
      duration: '10-15 minutes',
      description: 'See M in action for your specific industry: Financial, Healthcare, Manufacturing, and more.',
      icon: Play,
      color: 'from-blue-500 to-cyan-500',
      borderColor: 'border-blue-500/30 hover:border-blue-500',
      path: '/industry-demos',
      badge: '6 Industries',
      badgeColor: 'bg-blue-500'
    },
    {
      id: 'investor',
      title: 'Investor Demo',
      duration: '3 minutes',
      description: 'Locked, predictable demo for investor presentations. Same experience every time.',
      icon: Presentation,
      color: 'from-amber-500 to-orange-500',
      borderColor: 'border-amber-500/30 hover:border-amber-500',
      path: '/investor-demo',
      badge: 'Roadshow Ready',
      badgeColor: 'bg-amber-500'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <StandardNav />
      
      <div className="max-w-4xl mx-auto px-6 py-20">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4" data-testid="heading-demo-router">
            Experience M
          </h1>
          <p className="text-xl text-slate-400">
            Choose the demo that fits your schedule
          </p>
        </div>

        <div className="space-y-4">
          {demoOptions.map((demo) => {
            const IconComponent = demo.icon;
            return (
              <Card 
                key={demo.id}
                className={`bg-slate-900/50 border-2 ${demo.borderColor} cursor-pointer transition-all hover:shadow-xl group`}
                onClick={() => setLocation(demo.path)}
                data-testid={`card-demo-${demo.id}`}
              >
                <CardContent className="p-6 flex items-center gap-6">
                  <div className={`p-4 rounded-2xl bg-gradient-to-br ${demo.color}`}>
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="text-xl font-bold text-white group-hover:text-emerald-400 transition-colors">
                        {demo.title}
                      </h3>
                      <Badge className={`${demo.badgeColor} text-white text-xs`}>
                        {demo.badge}
                      </Badge>
                    </div>
                    <p className="text-slate-400 mb-2">{demo.description}</p>
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <Clock className="h-4 w-4" />
                      <span>{demo.duration}</span>
                    </div>
                  </div>
                  
                  <ArrowRight className="h-6 w-6 text-slate-500 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-8 p-4 bg-purple-950/30 border border-purple-500/30 rounded-xl">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <FileText className="h-5 w-5 text-purple-400" />
              <div>
                <p className="text-white font-medium">Roadshow Preparation</p>
                <p className="text-sm text-slate-400">FAQ, demo scripts, investor talking points</p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => setLocation('/roadshow-resources')}
              className="border-purple-500/50 text-purple-300 hover:bg-purple-950"
              data-testid="button-roadshow-resources"
            >
              Access Resources →
            </Button>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-slate-500 mb-4">
            Not sure which to choose? Start with the Quick Demo.
          </p>
          <Button
            variant="outline"
            onClick={() => setLocation('/playbook-library')}
            className="text-slate-300 border-slate-700 hover:bg-slate-800"
            data-testid="button-explore-playbooks"
          >
            Or explore the 148 playbooks directly →
          </Button>
        </div>
      </div>

      <Footer />
    </div>
  );
}
