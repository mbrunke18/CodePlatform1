import { useState, useCallback } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Play, 
  ArrowRight, 
  ArrowLeft,
  CheckCircle2, 
  Clock, 
  Users, 
  Zap,
  Shield,
  Target,
  Trophy,
  AlertTriangle,
  Radio,
  BookOpen,
  Brain,
  Rocket,
  Star,
  Building2
} from 'lucide-react';
import ChaosSimulator, { type ChaosScenario } from '@/components/demo/ChaosSimulator';
import InteractiveDecisionPoint, { type DecisionScenario } from '@/components/demo/InteractiveDecisionPoint';
import OrganizationReadinessScore from '@/components/demo/OrganizationReadinessScore';
import Confetti from 'react-confetti';

type Industry = 
  | 'technology' 
  | 'financial_services' 
  | 'healthcare' 
  | 'manufacturing' 
  | 'retail' 
  | 'energy'
  | 'pharmaceuticals'
  | 'telecommunications';

type DemoPhase = 
  | 'setup'
  | 'chaos'
  | 'bridge'
  | 'signal'
  | 'decision1'
  | 'playbook'
  | 'decision2'
  | 'coordination'
  | 'decision3'
  | 'resolution'
  | 'assessment';

interface DemoConfig {
  companyName: string;
  industry: Industry;
  scenario: ChaosScenario;
  employeeCount: number;
  annualRevenue: number;
}

const INDUSTRY_OPTIONS: { value: Industry; label: string }[] = [
  { value: 'technology', label: 'Technology' },
  { value: 'financial_services', label: 'Financial Services' },
  { value: 'healthcare', label: 'Healthcare' },
  { value: 'manufacturing', label: 'Manufacturing' },
  { value: 'retail', label: 'Retail' },
  { value: 'energy', label: 'Energy' },
  { value: 'pharmaceuticals', label: 'Pharmaceuticals' },
  { value: 'telecommunications', label: 'Telecommunications' },
];

const SCENARIO_OPTIONS: { value: ChaosScenario; label: string; description: string }[] = [
  { value: 'ransomware', label: 'Ransomware Attack', description: 'Cyber attack with data encryption' },
  { value: 'competitor', label: 'Competitive Threat', description: 'Major competitor price disruption' },
  { value: 'regulatory', label: 'Regulatory Notice', description: 'SEC investigation notice' },
  { value: 'supply_chain', label: 'Supply Chain Crisis', description: 'Critical supplier bankruptcy' },
  { value: 'pr_crisis', label: 'PR Crisis', description: 'Viral social media incident' },
];

const SCENARIO_TO_DECISIONS: Record<ChaosScenario, DecisionScenario[]> = {
  ransomware: ['ransomware_initial', 'crisis_communication', 'regulatory_disclosure'],
  competitor: ['competitor_response', 'crisis_communication', 'supply_chain_action'],
  regulatory: ['regulatory_disclosure', 'ransomware_initial', 'crisis_communication'],
  supply_chain: ['supply_chain_action', 'crisis_communication', 'competitor_response'],
  pr_crisis: ['crisis_communication', 'ransomware_initial', 'regulatory_disclosure'],
};

const PHASES: { id: DemoPhase; label: string; icon: typeof Play }[] = [
  { id: 'setup', label: 'Setup', icon: Building2 },
  { id: 'chaos', label: 'Chaos', icon: AlertTriangle },
  { id: 'bridge', label: 'Bridge', icon: Target },
  { id: 'signal', label: 'Signal Detection', icon: Radio },
  { id: 'decision1', label: 'Decision 1', icon: Brain },
  { id: 'playbook', label: 'Playbook', icon: BookOpen },
  { id: 'decision2', label: 'Decision 2', icon: Brain },
  { id: 'coordination', label: 'Coordination', icon: Users },
  { id: 'decision3', label: 'Decision 3', icon: Brain },
  { id: 'resolution', label: 'Resolution', icon: Trophy },
  { id: 'assessment', label: 'Assessment', icon: Shield },
];

export default function TransformationalDemo() {
  const [, setLocation] = useLocation();
  const [currentPhase, setCurrentPhase] = useState<DemoPhase>('setup');
  const [config, setConfig] = useState<DemoConfig>({
    companyName: '',
    industry: 'technology',
    scenario: 'ransomware',
    employeeCount: 5000,
    annualRevenue: 2000000000,
  });
  const [decisionResults, setDecisionResults] = useState<boolean[]>([]);
  const [elapsedMinutes, setElapsedMinutes] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  
  const currentPhaseIndex = PHASES.findIndex(p => p.id === currentPhase);
  const progress = ((currentPhaseIndex + 1) / PHASES.length) * 100;
  
  const advancePhase = useCallback(() => {
    const nextIndex = currentPhaseIndex + 1;
    if (nextIndex < PHASES.length) {
      setCurrentPhase(PHASES[nextIndex].id);
    }
  }, [currentPhaseIndex]);
  
  const goBack = useCallback(() => {
    if (currentPhaseIndex > 0) {
      setCurrentPhase(PHASES[currentPhaseIndex - 1].id);
    }
  }, [currentPhaseIndex]);
  
  const handleChaosComplete = () => {
    advancePhase();
  };
  
  const handleDecisionComplete = (optionId: string, wasOptimal: boolean) => {
    setDecisionResults(prev => [...prev, wasOptimal]);
    advancePhase();
  };
  
  const handleScheduleCall = () => {
    setLocation('/contact');
  };
  
  const handleStartTrial = () => {
    setLocation('/start');
  };
  
  const startDemo = () => {
    if (!config.companyName) {
      setConfig(prev => ({ ...prev, companyName: 'Meridian Industries' }));
    }
    advancePhase();
  };
  
  const decisions = SCENARIO_TO_DECISIONS[config.scenario];
  
  const renderPhase = () => {
    switch (currentPhase) {
      case 'setup':
        return (
          <div className="max-w-2xl mx-auto" data-testid="demo-phase-setup">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Building2 className="w-8 h-8 text-blue-400" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">
                Personalize Your Experience
              </h2>
              <p className="text-slate-400">
                We'll customize the demo to reflect your organization's reality
              </p>
            </div>
            
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-6 space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="companyName" className="text-white">Company Name</Label>
                  <Input
                    id="companyName"
                    placeholder="Your Company (or leave blank for Meridian Industries)"
                    value={config.companyName}
                    onChange={(e) => setConfig(prev => ({ ...prev, companyName: e.target.value }))}
                    className="bg-slate-900 border-slate-600 text-white"
                    data-testid="input-company-name"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-white">Industry</Label>
                  <Select
                    value={config.industry}
                    onValueChange={(value: Industry) => setConfig(prev => ({ ...prev, industry: value }))}
                  >
                    <SelectTrigger className="bg-slate-900 border-slate-600 text-white" data-testid="select-industry">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {INDUSTRY_OPTIONS.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-white">Crisis Scenario</Label>
                  <div className="grid grid-cols-1 gap-3">
                    {SCENARIO_OPTIONS.map(option => (
                      <div
                        key={option.value}
                        onClick={() => setConfig(prev => ({ ...prev, scenario: option.value }))}
                        className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                          config.scenario === option.value
                            ? 'border-blue-500 bg-blue-500/10'
                            : 'border-slate-600 hover:border-slate-500 bg-slate-900/50'
                        }`}
                        data-testid={`scenario-option-${option.value}`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium text-white">{option.label}</h4>
                            <p className="text-sm text-slate-400">{option.description}</p>
                          </div>
                          {config.scenario === option.value && (
                            <CheckCircle2 className="w-5 h-5 text-blue-400" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <Button 
                  onClick={startDemo}
                  size="lg"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  data-testid="button-start-demo"
                >
                  Begin Experience
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </div>
        );
        
      case 'chaos':
        return (
          <ChaosSimulator
            scenario={config.scenario}
            companyName={config.companyName || 'Meridian Industries'}
            onComplete={handleChaosComplete}
            autoAdvanceDelay={8000}
          />
        );
        
      case 'bridge':
        return (
          <div className="max-w-3xl mx-auto text-center" data-testid="demo-phase-bridge">
            <div className="mb-8">
              <Badge className="bg-blue-600 text-white mb-6 px-4 py-1">
                The M Methodology
              </Badge>
              <h2 className="text-4xl font-bold text-white mb-6">
                That chaos is completely avoidable.
              </h2>
            </div>
            
            <Card className="bg-slate-800/50 border-slate-700 mb-8">
              <CardContent className="p-8">
                <div className="flex items-start gap-6">
                  <div className="w-16 h-16 bg-orange-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Trophy className="w-8 h-8 text-orange-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-lg text-slate-300 mb-4">
                      Here's what I learned from 5 years as a college football coach:
                    </p>
                    <p className="text-white text-xl font-medium mb-4">
                      In football, we had 40 seconds between plays. 80,000 fans watching. National television cameras rolling.
                    </p>
                    <p className="text-white text-xl font-medium mb-4">
                      And we executed perfectly—not because we were smarter, but because we'd <span className="text-blue-400">prepared</span>.
                    </p>
                    <p className="text-slate-300">
                      Everyone knew their assignment. The play call was one word. Execution began instantly.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="bg-gradient-to-r from-blue-900/30 to-blue-800/20 rounded-xl p-8 border border-blue-500/30 mb-8">
              <h3 className="text-2xl font-bold text-white mb-4">
                What if your organization could do the same?
              </h3>
              <p className="text-slate-300 text-lg">
                M brings championship-level preparation to strategic execution.
                <br />
                Let us show you how.
              </p>
            </div>
            
            <Button 
              onClick={advancePhase}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8"
              data-testid="button-continue-bridge"
            >
              See M in Action
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        );
        
      case 'signal':
        return (
          <div className="max-w-3xl mx-auto" data-testid="demo-phase-signal">
            <div className="text-center mb-8">
              <Badge className="bg-green-600 text-white mb-4 px-4 py-1">
                M Signal Detection
              </Badge>
              <h2 className="text-3xl font-bold text-white mb-4">
                We Saw It Coming
              </h2>
              <p className="text-slate-400">
                M's AI detected the warning signs 47 minutes before the crisis broke
              </p>
            </div>
            
            <Card className="bg-slate-800/50 border-green-500/30 mb-6">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white flex items-center gap-2">
                    <Radio className="w-5 h-5 text-green-400" />
                    Early Warning Detected
                  </CardTitle>
                  <Badge className="bg-green-600 text-white">47 min early</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <Zap className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Signal Strength: 94%</p>
                      <p className="text-sm text-slate-400">High confidence detection</p>
                    </div>
                  </div>
                  <Progress value={94} className="h-2 bg-slate-700" />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
                    <p className="text-sm text-slate-400 mb-1">Pattern Match</p>
                    <p className="text-xl font-bold text-white">3 of 4</p>
                    <p className="text-xs text-green-400">trigger conditions met</p>
                  </div>
                  <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
                    <p className="text-sm text-slate-400 mb-1">Historical Precedent</p>
                    <p className="text-xl font-bold text-white">87%</p>
                    <p className="text-xs text-green-400">similar pattern accuracy</p>
                  </div>
                </div>
                
                <div className="bg-blue-500/10 rounded-lg p-4 border border-blue-500/30">
                  <p className="text-blue-400 font-medium mb-2">M Recommendation:</p>
                  <p className="text-white">
                    Activate Playbook #
                    {config.scenario === 'ransomware' ? '12: Cyber Incident Response' :
                     config.scenario === 'competitor' ? '47: Price War Defense' :
                     config.scenario === 'regulatory' ? '31: Regulatory Response' :
                     config.scenario === 'supply_chain' ? '23: Supply Chain Disruption' :
                     '56: Reputation Crisis Management'}
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <div className="text-center">
              <p className="text-slate-400 mb-6">
                While competitors are still figuring out what happened,
                <br />
                <span className="text-white font-medium">you're already executing.</span>
              </p>
              <Button 
                onClick={advancePhase}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white"
                data-testid="button-continue-signal"
              >
                Make Your First Decision
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        );
        
      case 'decision1':
        return (
          <InteractiveDecisionPoint
            scenario={decisions[0]}
            onComplete={handleDecisionComplete}
            decisionNumber={1}
            totalDecisions={3}
          />
        );
        
      case 'playbook':
        return (
          <div className="max-w-4xl mx-auto" data-testid="demo-phase-playbook">
            <div className="text-center mb-8">
              <Badge className="bg-blue-600 text-white mb-4 px-4 py-1">
                Playbook Activated
              </Badge>
              <h2 className="text-3xl font-bold text-white mb-4">
                Three-Phase Execution Model
              </h2>
              <p className="text-slate-400">
                Pre-defined actions executing across your organization
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {[
                { phase: 'CONTAIN', time: '0-4 min', color: 'red', actions: ['Activate response team', 'Secure critical systems', 'Initial assessment'] },
                { phase: 'COORDINATE', time: '4-8 min', color: 'yellow', actions: ['Brief stakeholders', 'Assign action items', 'Establish command'] },
                { phase: 'COMMUNICATE', time: '8-12 min', color: 'green', actions: ['Board notification', 'Customer messaging', 'Media holding statement'] },
              ].map((phase, index) => (
                <Card key={phase.phase} className={`bg-slate-800/50 border-${phase.color}-500/30`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge className={`bg-${phase.color}-600 text-white`}>
                        Phase {index + 1}
                      </Badge>
                      <span className="text-slate-400 text-sm">{phase.time}</span>
                    </div>
                    <CardTitle className="text-white">{phase.phase}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {phase.actions.map((action, i) => (
                        <li key={i} className="flex items-center gap-2 text-slate-300">
                          <CheckCircle2 className={`w-4 h-4 text-${phase.color}-400`} />
                          {action}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Execution Progress</h3>
                <span className="text-green-400 font-mono">4:32 elapsed</span>
              </div>
              <Progress value={38} className="h-3 bg-slate-700 mb-2" />
              <div className="flex justify-between text-sm text-slate-400">
                <span>12 actions initiated</span>
                <span>8 stakeholders engaged</span>
                <span>$0 at risk</span>
              </div>
            </div>
            
            <div className="text-center">
              <Button 
                onClick={advancePhase}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white"
                data-testid="button-continue-playbook"
              >
                Next Decision Point
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        );
        
      case 'decision2':
        return (
          <InteractiveDecisionPoint
            scenario={decisions[1]}
            onComplete={handleDecisionComplete}
            decisionNumber={2}
            totalDecisions={3}
          />
        );
        
      case 'coordination':
        return (
          <div className="max-w-4xl mx-auto" data-testid="demo-phase-coordination">
            <div className="text-center mb-8">
              <Badge className="bg-purple-600 text-white mb-4 px-4 py-1">
                Live Coordination
              </Badge>
              <h2 className="text-3xl font-bold text-white mb-4">
                Stakeholder Status Board
              </h2>
              <p className="text-slate-400">
                Real-time visibility into every response action
              </p>
            </div>
            
            <Card className="bg-slate-800/50 border-slate-700 mb-8">
              <CardContent className="p-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  {[
                    { label: 'Stakeholders', value: '12', status: 'active', icon: Users },
                    { label: 'Actions', value: '24/28', status: 'progress', icon: CheckCircle2 },
                    { label: 'Elapsed', value: '8:47', status: 'time', icon: Clock },
                    { label: 'On Track', value: '96%', status: 'success', icon: Target },
                  ].map((stat, i) => {
                    const Icon = stat.icon;
                    return (
                      <div key={i} className="bg-slate-900/50 rounded-lg p-4 text-center">
                        <Icon className={`w-6 h-6 mx-auto mb-2 ${
                          stat.status === 'success' ? 'text-green-400' :
                          stat.status === 'active' ? 'text-blue-400' :
                          stat.status === 'progress' ? 'text-yellow-400' :
                          'text-slate-400'
                        }`} />
                        <p className="text-2xl font-bold text-white">{stat.value}</p>
                        <p className="text-xs text-slate-400">{stat.label}</p>
                      </div>
                    );
                  })}
                </div>
                
                <Separator className="my-6 bg-slate-700" />
                
                <div className="space-y-3">
                  {[
                    { name: 'CFO - Michael Torres', task: 'Board briefing prepared', status: 'complete' },
                    { name: 'CISO - Marcus Chen', task: 'Technical assessment', status: 'complete' },
                    { name: 'General Counsel', task: 'Regulatory filing review', status: 'in_progress' },
                    { name: 'VP Communications', task: 'Media statement draft', status: 'complete' },
                    { name: 'VP Operations', task: 'Business continuity check', status: 'in_progress' },
                  ].map((stakeholder, i) => (
                    <div key={i} className="flex items-center justify-between bg-slate-900/30 rounded-lg p-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium ${
                          stakeholder.status === 'complete' ? 'bg-green-600' : 'bg-yellow-600'
                        }`}>
                          {stakeholder.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                        </div>
                        <div>
                          <p className="text-white text-sm font-medium">{stakeholder.name}</p>
                          <p className="text-slate-400 text-xs">{stakeholder.task}</p>
                        </div>
                      </div>
                      <Badge className={stakeholder.status === 'complete' ? 'bg-green-600' : 'bg-yellow-600'}>
                        {stakeholder.status === 'complete' ? 'Done' : 'In Progress'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <div className="text-center">
              <Button 
                onClick={advancePhase}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white"
                data-testid="button-continue-coordination"
              >
                Final Decision
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        );
        
      case 'decision3':
        return (
          <InteractiveDecisionPoint
            scenario={decisions[2]}
            onComplete={(optionId, wasOptimal) => {
              handleDecisionComplete(optionId, wasOptimal);
              setShowConfetti(true);
              setTimeout(() => setShowConfetti(false), 5000);
            }}
            decisionNumber={3}
            totalDecisions={3}
          />
        );
        
      case 'resolution':
        return (
          <div className="max-w-3xl mx-auto text-center" data-testid="demo-phase-resolution">
            {showConfetti && <Confetti recycle={false} numberOfPieces={200} />}
            
            <div className="mb-8">
              <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
                <Trophy className="w-12 h-12 text-green-400" />
              </div>
              <Badge className="bg-green-600 text-white mb-4 px-6 py-2 text-lg">
                Crisis Contained
              </Badge>
              <h2 className="text-4xl font-bold text-white mb-4">
                12 Minutes. Coordinated Response Complete.
              </h2>
              <p className="text-xl text-slate-300">
                While others scramble for hours, you've already moved on.
              </p>
            </div>
            
            <div className="grid grid-cols-3 gap-6 mb-8">
              <Card className="bg-slate-800/50 border-green-500/30">
                <CardContent className="p-6 text-center">
                  <Clock className="w-8 h-8 text-green-400 mx-auto mb-3" />
                  <p className="text-3xl font-bold text-white mb-1">12 min</p>
                  <p className="text-slate-400 text-sm">Total response time</p>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardContent className="p-6 text-center">
                  <Users className="w-8 h-8 text-blue-400 mx-auto mb-3" />
                  <p className="text-3xl font-bold text-white mb-1">12</p>
                  <p className="text-slate-400 text-sm">Stakeholders aligned</p>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/50 border-purple-500/30">
                <CardContent className="p-6 text-center">
                  <Zap className="w-8 h-8 text-purple-400 mx-auto mb-3" />
                  <p className="text-3xl font-bold text-white mb-1">28</p>
                  <p className="text-slate-400 text-sm">Actions executed</p>
                </CardContent>
              </Card>
            </div>
            
            <div className="bg-slate-800/50 rounded-xl p-8 border border-slate-700 mb-8">
              <h3 className="text-xl font-semibold text-white mb-4">Your Decision Performance</h3>
              <div className="flex justify-center gap-8">
                {decisionResults.map((wasOptimal, i) => (
                  <div key={i} className="text-center">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2 ${
                      wasOptimal ? 'bg-green-500/20' : 'bg-yellow-500/20'
                    }`}>
                      {wasOptimal ? (
                        <CheckCircle2 className="w-6 h-6 text-green-400" />
                      ) : (
                        <Star className="w-6 h-6 text-yellow-400" />
                      )}
                    </div>
                    <p className="text-sm text-slate-400">Decision {i + 1}</p>
                    <p className={`text-sm font-medium ${wasOptimal ? 'text-green-400' : 'text-yellow-400'}`}>
                      {wasOptimal ? 'Optimal' : 'Learning'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            
            <p className="text-slate-400 mb-8">
              <span className="text-white font-semibold">
                {decisionResults.filter(r => r).length} of 3 optimal decisions
              </span>
              {' '}— With M's guidance, your team would achieve optimal outcomes consistently.
            </p>
            
            <Button 
              onClick={advancePhase}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8"
              data-testid="button-continue-resolution"
            >
              See Your Readiness Score
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        );
        
      case 'assessment':
        return (
          <OrganizationReadinessScore
            companyName={config.companyName || 'Meridian Industries'}
            industry={config.industry}
            employeeCount={config.employeeCount}
            annualRevenue={config.annualRevenue}
            onScheduleCall={handleScheduleCall}
            onStartTrial={handleStartTrial}
          />
        );
        
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        {currentPhase !== 'setup' && (
          <div className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur border-b border-slate-700 py-4 px-6">
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-4">
                  {currentPhaseIndex > 1 && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={goBack}
                      className="text-slate-400 hover:text-white"
                      data-testid="button-go-back"
                    >
                      <ArrowLeft className="w-4 h-4 mr-1" />
                      Back
                    </Button>
                  )}
                  <span className="text-white font-medium">
                    {PHASES.find(p => p.id === currentPhase)?.label}
                  </span>
                </div>
                <span className="text-slate-400 text-sm">
                  {currentPhaseIndex + 1} of {PHASES.length}
                </span>
              </div>
              <Progress value={progress} className="h-1.5 bg-slate-700" />
            </div>
          </div>
        )}
        
      <div className="py-12 px-6">
        <div className="max-w-6xl mx-auto">
          {renderPhase()}
        </div>
      </div>
    </div>
  );
}
