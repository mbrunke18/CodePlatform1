import { useLocation } from 'wouter';
import PageLayout from '@/components/layout/PageLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Target, 
  Zap, 
  Radio, 
  Clock, 
  BookOpen, 
  Brain, 
  ArrowRight,
  CheckCircle,
  XCircle,
  Minus,
  TrendingUp,
  Shield,
  Users,
  BarChart3,
  Layers,
  AlertTriangle,
  Play
} from 'lucide-react';

const competitors = [
  {
    name: 'Dataminr',
    category: 'Signal Detection',
    focus: 'Real-time event detection from public data',
    strengths: ['Fast signal detection', 'Global coverage', 'AI-powered alerts'],
    gaps: ['No execution capabilities', 'No playbook library', 'No coordination tools'],
    color: 'bg-orange-500',
    position: { x: 15, y: 25 }
  },
  {
    name: 'Salesforce',
    category: 'CRM Platform',
    focus: 'Customer relationship management and sales automation',
    strengths: ['Customer 360 view', 'Sales pipeline', 'Ecosystem integrations'],
    gaps: ['No external signal detection', 'No strategic playbooks', 'Reactive to opportunities'],
    color: 'bg-sky-500',
    position: { x: 65, y: 72 }
  },
  {
    name: 'Smartsheet',
    category: 'PPM / Work Management',
    focus: 'Project portfolio management and collaboration',
    strengths: ['Project tracking', 'Resource management', 'Workflow automation'],
    gaps: ['No external intelligence', 'Project-level not strategic', 'Reactive not proactive'],
    color: 'bg-indigo-500',
    position: { x: 55, y: 78 }
  },
  {
    name: 'Monday.com',
    category: 'Work OS',
    focus: 'Team collaboration and project management',
    strengths: ['Visual workflows', 'Team collaboration', 'Customizable boards'],
    gaps: ['Task-level focus', 'No signal monitoring', 'No coordinated response'],
    color: 'bg-red-400',
    position: { x: 45, y: 82 }
  },
  {
    name: 'SAP',
    category: 'ERP Platform',
    focus: 'Enterprise resource planning and business operations',
    strengths: ['Financial systems', 'Supply chain', 'Enterprise scale'],
    gaps: ['Quarterly planning cycles', 'No agile response', 'No external signals'],
    color: 'bg-blue-600',
    position: { x: 80, y: 80 }
  },
  {
    name: 'ServiceNow',
    category: 'Workflow Automation',
    focus: 'IT service management and workflows',
    strengths: ['Process automation', 'Ticketing', 'Enterprise scale'],
    gaps: ['IT-focused', 'No strategic intelligence', 'Reactive not proactive'],
    color: 'bg-green-500',
    position: { x: 25, y: 75 }
  },
  {
    name: 'Workday',
    category: 'HCM / Finance',
    focus: 'Human capital and financial management',
    strengths: ['HR analytics', 'Financial planning', 'Talent management'],
    gaps: ['Internal focus only', 'No market signals', 'No rapid response'],
    color: 'bg-amber-500',
    position: { x: 70, y: 85 }
  }
];

const mCapabilities = [
  { capability: 'Real-time Signal Detection', m: true, dataminr: true, salesforce: false, smartsheet: false, monday: false, sap: false, servicenow: false, workday: false },
  { capability: 'Pre-built Strategic Playbooks', m: true, dataminr: false, salesforce: false, smartsheet: false, monday: false, sap: false, servicenow: false, workday: false },
  { capability: '12-Minute Coordination', m: true, dataminr: false, salesforce: false, smartsheet: false, monday: false, sap: false, servicenow: false, workday: false },
  { capability: 'Cross-Functional Orchestration', m: true, dataminr: false, salesforce: 'partial', smartsheet: 'partial', monday: 'partial', sap: 'partial', servicenow: true, workday: 'partial' },
  { capability: 'AI-Powered Learning', m: true, dataminr: true, salesforce: 'partial', smartsheet: false, monday: false, sap: false, servicenow: false, workday: false },
  { capability: 'Executive Decision Support', m: true, dataminr: false, salesforce: 'partial', smartsheet: false, monday: false, sap: 'partial', servicenow: false, workday: 'partial' },
  { capability: 'Crisis Response Ready', m: true, dataminr: 'partial', salesforce: false, smartsheet: false, monday: false, sap: false, servicenow: 'partial', workday: false },
  { capability: 'Institutional Memory', m: true, dataminr: false, salesforce: true, smartsheet: false, monday: false, sap: true, servicenow: false, workday: true },
];

const differentiators = [
  {
    title: 'Complete Signal-to-Execution Loop',
    description: 'The only platform that connects external signal detection directly to coordinated organizational response.',
    icon: Zap,
    color: 'text-amber-500'
  },
  {
    title: '148 Pre-Built Strategic Playbooks',
    description: 'Battle-tested response templates across 8 strategic domains, ready to customize and deploy.',
    icon: BookOpen,
    color: 'text-blue-500'
  },
  {
    title: '12-Minute Coordination Velocity',
    description: 'From trigger detection to full stakeholder alignment in under 12 minutes vs. industry average of 6+ hours.',
    icon: Clock,
    color: 'text-emerald-500'
  },
  {
    title: 'Self-Learning Playbooks',
    description: 'AI analyzes every execution to continuously improve response effectiveness and speed.',
    icon: Brain,
    color: 'text-purple-500'
  }
];

const strategicDomains = [
  { name: 'Market Dynamics', count: 24, icon: TrendingUp },
  { name: 'Competitive Intelligence', count: 18, icon: Target },
  { name: 'Crisis Management', count: 22, icon: AlertTriangle },
  { name: 'M&A Integration', count: 16, icon: Layers },
  { name: 'Supply Chain', count: 20, icon: BarChart3 },
  { name: 'Regulatory Response', count: 18, icon: Shield },
  { name: 'Talent & Culture', count: 14, icon: Users },
  { name: 'Technology Disruption', count: 16, icon: Zap },
];

export default function CompetitivePositioning() {
  const [, setLocation] = useLocation();

  return (
    <PageLayout>
      <div className="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-950 dark:via-slate-900 dark:to-blue-950">
        
        {/* Hero Section */}
        <section className="py-16 px-6 bg-gradient-to-br from-slate-900 via-slate-800 to-blue-900">
          <div className="max-w-6xl mx-auto text-center">
            <Badge className="mb-6 bg-blue-600/20 text-blue-300 border-blue-500/30">
              Market Position
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              The Strategic Execution OS
              <span className="block text-blue-400 mt-2">Category of One</span>
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-8">
              M occupies unique white space at the intersection of signal detection, strategic planning, and workflow execution—a space no other platform addresses end-to-end.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => setLocation('/demo/live-activation')}
                data-testid="button-see-demo"
              >
                <Play className="w-5 h-5 mr-2" />
                See It In Action
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10"
                onClick={() => setLocation('/playbook-library')}
                data-testid="button-explore-playbooks"
              >
                Explore 148 Playbooks
              </Button>
            </div>
          </div>
        </section>

        {/* Market Map Visualization */}
        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
                Competitive Landscape
              </h2>
              <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
                Existing solutions address fragments of the strategic execution challenge. M is the only complete solution.
              </p>
            </div>

            {/* Visual Market Map */}
            <Card className="mb-12 overflow-hidden">
              <CardContent className="p-0">
                <div className="relative bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900 h-[500px]">
                  {/* Axis Labels */}
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 -rotate-90 text-sm font-semibold text-slate-500 dark:text-slate-400">
                    SIGNAL DETECTION →
                  </div>
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-sm font-semibold text-slate-500 dark:text-slate-400">
                    EXECUTION CAPABILITY →
                  </div>

                  {/* Quadrant Labels */}
                  <div className="absolute top-8 left-16 text-xs text-slate-400 uppercase tracking-wide">
                    Detects but can't execute
                  </div>
                  <div className="absolute top-8 right-16 text-xs text-slate-400 uppercase tracking-wide">
                    Complete Loop
                  </div>
                  <div className="absolute bottom-16 left-16 text-xs text-slate-400 uppercase tracking-wide">
                    Neither
                  </div>
                  <div className="absolute bottom-16 right-16 text-xs text-slate-400 uppercase tracking-wide">
                    Executes without signals
                  </div>

                  {/* Grid Lines */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-[1px] h-full bg-slate-300 dark:bg-slate-700"></div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-full h-[1px] bg-slate-300 dark:bg-slate-700"></div>
                  </div>

                  {/* M - Center of upper right quadrant */}
                  <div 
                    className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20"
                    style={{ left: '75%', top: '25%' }}
                  >
                    <div className="relative group cursor-pointer" data-testid="marker-m">
                      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-xl ring-4 ring-white dark:ring-slate-900 animate-pulse">
                        <span className="text-white font-bold text-2xl">M</span>
                      </div>
                      <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap text-sm font-semibold text-slate-900 dark:text-white">
                        Strategic Execution OS
                      </div>
                    </div>
                  </div>

                  {/* Competitor Markers */}
                  {competitors.map((competitor) => (
                    <div 
                      key={competitor.name}
                      className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10"
                      style={{ left: `${competitor.position.x}%`, top: `${competitor.position.y}%` }}
                      data-testid={`marker-${competitor.name.toLowerCase().replace(/\./g, '')}`}
                    >
                      <div className="relative group cursor-pointer">
                        <div className={`w-12 h-12 rounded-full ${competitor.color} flex items-center justify-center shadow-lg opacity-70`}>
                          <span className="text-white font-bold text-xs">{competitor.name.charAt(0)}</span>
                        </div>
                        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap text-xs text-slate-600 dark:text-slate-400">
                          {competitor.name}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Competitor Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {competitors.map((competitor) => (
                <Card key={competitor.name} className="border-l-4" style={{ borderLeftColor: competitor.color.replace('bg-', '#').replace('-500', '') }} data-testid={`card-competitor-${competitor.name.toLowerCase().replace(/\./g, '')}`}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full ${competitor.color} flex items-center justify-center`}>
                        <span className="text-white font-bold text-sm">{competitor.name.charAt(0)}</span>
                      </div>
                      <div>
                        <CardTitle className="text-lg">{competitor.name}</CardTitle>
                        <Badge variant="outline" className="text-xs">{competitor.category}</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">{competitor.focus}</p>
                    <div className="space-y-3">
                      <div>
                        <div className="text-xs font-semibold text-emerald-600 mb-1">Strengths</div>
                        <ul className="space-y-1">
                          {competitor.strengths.map((s, i) => (
                            <li key={i} className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                              <CheckCircle className="w-3 h-3 text-emerald-500" /> {s}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-red-600 mb-1">Gaps M Fills</div>
                        <ul className="space-y-1">
                          {competitor.gaps.map((g, i) => (
                            <li key={i} className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                              <XCircle className="w-3 h-3 text-red-500" /> {g}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Capability Comparison Table */}
        <section className="py-16 px-6 bg-slate-100 dark:bg-slate-900/50">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
                Capability Comparison
              </h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                M is the only platform with end-to-end strategic execution capabilities
              </p>
            </div>

            <Card>
              <CardContent className="p-0 overflow-x-auto">
                <table className="w-full min-w-[1000px]">
                  <thead>
                    <tr className="border-b bg-slate-50 dark:bg-slate-800/50">
                      <th className="text-left p-4 font-semibold text-slate-900 dark:text-white">Capability</th>
                      <th className="text-center p-3 font-semibold text-blue-600">
                        <div className="flex flex-col items-center">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mb-1">
                            <span className="text-white font-bold text-sm">M</span>
                          </div>
                          M
                        </div>
                      </th>
                      <th className="text-center p-3 font-semibold text-slate-600 text-xs">Dataminr</th>
                      <th className="text-center p-3 font-semibold text-slate-600 text-xs">Salesforce</th>
                      <th className="text-center p-3 font-semibold text-slate-600 text-xs">Smartsheet</th>
                      <th className="text-center p-3 font-semibold text-slate-600 text-xs">Monday</th>
                      <th className="text-center p-3 font-semibold text-slate-600 text-xs">SAP</th>
                      <th className="text-center p-3 font-semibold text-slate-600 text-xs">ServiceNow</th>
                      <th className="text-center p-3 font-semibold text-slate-600 text-xs">Workday</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mCapabilities.map((row, i) => (
                      <tr key={i} className="border-b last:border-0 hover:bg-slate-50 dark:hover:bg-slate-800/30">
                        <td className="p-3 text-sm text-slate-700 dark:text-slate-300">{row.capability}</td>
                        <td className="p-3 text-center">
                          {row.m === true && <CheckCircle className="w-5 h-5 text-emerald-500 mx-auto" />}
                        </td>
                        <td className="p-3 text-center">
                          {row.dataminr === true && <CheckCircle className="w-4 h-4 text-emerald-500 mx-auto" />}
                          {row.dataminr === false && <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                          {row.dataminr === 'partial' && <Minus className="w-4 h-4 text-amber-500 mx-auto" />}
                        </td>
                        <td className="p-3 text-center">
                          {row.salesforce === true && <CheckCircle className="w-4 h-4 text-emerald-500 mx-auto" />}
                          {row.salesforce === false && <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                          {row.salesforce === 'partial' && <Minus className="w-4 h-4 text-amber-500 mx-auto" />}
                        </td>
                        <td className="p-3 text-center">
                          {row.smartsheet === true && <CheckCircle className="w-4 h-4 text-emerald-500 mx-auto" />}
                          {row.smartsheet === false && <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                          {row.smartsheet === 'partial' && <Minus className="w-4 h-4 text-amber-500 mx-auto" />}
                        </td>
                        <td className="p-3 text-center">
                          {row.monday === true && <CheckCircle className="w-4 h-4 text-emerald-500 mx-auto" />}
                          {row.monday === false && <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                          {row.monday === 'partial' && <Minus className="w-4 h-4 text-amber-500 mx-auto" />}
                        </td>
                        <td className="p-3 text-center">
                          {row.sap === true && <CheckCircle className="w-4 h-4 text-emerald-500 mx-auto" />}
                          {row.sap === false && <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                          {row.sap === 'partial' && <Minus className="w-4 h-4 text-amber-500 mx-auto" />}
                        </td>
                        <td className="p-3 text-center">
                          {row.servicenow === true && <CheckCircle className="w-4 h-4 text-emerald-500 mx-auto" />}
                          {row.servicenow === false && <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                          {row.servicenow === 'partial' && <Minus className="w-4 h-4 text-amber-500 mx-auto" />}
                        </td>
                        <td className="p-3 text-center">
                          {row.workday === true && <CheckCircle className="w-4 h-4 text-emerald-500 mx-auto" />}
                          {row.workday === false && <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                          {row.workday === 'partial' && <Minus className="w-4 h-4 text-amber-500 mx-auto" />}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Key Differentiators */}
        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
                What Makes M Different
              </h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                Four capabilities that define the Strategic Execution OS category
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {differentiators.map((diff, i) => (
                <Card key={i} className="bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 border-2 hover:border-blue-300 dark:hover:border-blue-700 transition-colors" data-testid={`card-differentiator-${i}`}>
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-xl bg-slate-100 dark:bg-slate-800 ${diff.color}`}>
                        <diff.icon className="w-8 h-8" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                          {diff.title}
                        </h3>
                        <p className="text-slate-600 dark:text-slate-400">
                          {diff.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Strategic Domains */}
        <section className="py-16 px-6 bg-gradient-to-br from-blue-900 to-purple-900">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-white mb-4">
                148 Playbooks Across 8 Strategic Domains
              </h2>
              <p className="text-lg text-blue-200">
                Pre-built, battle-tested response templates ready to customize
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {strategicDomains.map((domain) => (
                <div 
                  key={domain.name} 
                  className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center hover:bg-white/20 transition-colors cursor-pointer"
                  onClick={() => setLocation('/playbook-library')}
                  data-testid={`card-domain-${domain.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <domain.icon className="w-8 h-8 text-blue-300 mx-auto mb-3" />
                  <div className="text-2xl font-bold text-white mb-1">{domain.count}</div>
                  <div className="text-sm text-blue-200">{domain.name}</div>
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Button 
                size="lg" 
                className="bg-white text-blue-900 hover:bg-blue-50"
                onClick={() => setLocation('/playbook-library')}
                data-testid="button-browse-all-playbooks"
              >
                Browse All 148 Playbooks
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
              Ready to Transform Strategic Execution?
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 mb-8">
              See how M can reduce your response time from 6+ hours to 12 minutes
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => setLocation('/demo/live-activation')}
                data-testid="button-cta-demo"
              >
                <Play className="w-5 h-5 mr-2" />
                Watch Live Demo
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => setLocation('/contact')}
                data-testid="button-cta-contact"
              >
                Request Access
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        </section>

      </div>
    </PageLayout>
  );
}
