import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Clock, 
  Users, 
  CheckCircle2, 
  AlertTriangle,
  Zap,
  ArrowRight,
  Target,
  Shield,
  TrendingUp,
  DollarSign,
  Calendar
} from 'lucide-react';
import { useLocation } from 'wouter';
import StandardNav from '@/components/layout/StandardNav';
import { motion, AnimatePresence } from 'framer-motion';
import Confetti from 'react-confetti';

const DEMO_DURATION = 180;

const DEMO_STAGES = [
  {
    id: 1,
    time: 0,
    title: "Signal Detection",
    subtitle: "AI identifies ransomware attack pattern",
    icon: AlertTriangle,
    color: "text-red-400",
    bgColor: "bg-red-500/20",
    description: "M's AI monitoring detects anomalous network traffic matching known ransomware signatures across 3 data centers."
  },
  {
    id: 2,
    time: 30,
    title: "Playbook Recommended",
    subtitle: "Cybersecurity Incident Response #012",
    icon: Target,
    color: "text-amber-400",
    bgColor: "bg-amber-500/20",
    description: "Based on signal analysis, M recommends Playbook #012 with 94% confidence match. Executive approval requested."
  },
  {
    id: 3,
    time: 60,
    title: "Playbook Activated",
    subtitle: "CISO approves with one click",
    icon: Zap,
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/20",
    description: "CISO reviews AI recommendation and activates playbook. 47 stakeholders receive immediate, role-specific notifications."
  },
  {
    id: 4,
    time: 90,
    title: "Tasks Deployed",
    subtitle: "127 coordinated actions in progress",
    icon: Users,
    color: "text-blue-400",
    bgColor: "bg-blue-500/20",
    description: "Tasks auto-assigned to IT, Legal, Communications, and Executive teams. Each stakeholder sees only their responsibilities."
  },
  {
    id: 5,
    time: 120,
    title: "Stakeholder Acknowledgments",
    subtitle: "Teams confirm and execute",
    icon: CheckCircle2,
    color: "text-purple-400",
    bgColor: "bg-purple-500/20",
    description: "Real-time dashboard shows 89% stakeholder acknowledgment. Budget pre-approvals unlock automatically."
  },
  {
    id: 6,
    time: 160,
    title: "Execution Complete",
    subtitle: "Full response in 12 minutes",
    icon: Shield,
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/20",
    description: "Ransomware contained. All stakeholders aligned. Communications deployed. Traditional response: 72 hours. With M: 12 minutes."
  }
];

const STAKEHOLDER_ACKNOWLEDGMENTS = [
  { name: "Sarah Chen", role: "Chief Information Security Officer", time: 65 },
  { name: "Michael Rodriguez", role: "VP Infrastructure", time: 75 },
  { name: "Jennifer Park", role: "General Counsel", time: 85 },
  { name: "David Thompson", role: "Chief Communications Officer", time: 95 },
  { name: "Lisa Wang", role: "VP Human Resources", time: 105 },
  { name: "Robert Kim", role: "Chief Financial Officer", time: 115 },
  { name: "Amanda Foster", role: "VP Customer Success", time: 125 },
  { name: "James Mitchell", role: "Chief Operating Officer", time: 135 },
];

export default function InvestorDemo() {
  const [, setLocation] = useLocation();
  const [isPlaying, setIsPlaying] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const [acknowledgedStakeholders, setAcknowledgedStakeholders] = useState<typeof STAKEHOLDER_ACKNOWLEDGMENTS>([]);
  const [showConfetti, setShowConfetti] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setElapsedTime(prev => {
        const next = prev + 1;
        
        const nextStageIndex = DEMO_STAGES.findIndex(s => s.time > next);
        if (nextStageIndex > 0) {
          setCurrentStageIndex(nextStageIndex - 1);
        } else if (nextStageIndex === -1) {
          setCurrentStageIndex(DEMO_STAGES.length - 1);
        }
        
        const newAcks = STAKEHOLDER_ACKNOWLEDGMENTS.filter(s => s.time <= next && s.time > prev);
        if (newAcks.length > 0) {
          setAcknowledgedStakeholders(current => [...current, ...newAcks]);
        }
        
        if (next >= DEMO_DURATION) {
          setIsPlaying(false);
          setShowConfetti(true);
          setIsComplete(true);
          setTimeout(() => setShowConfetti(false), 5000);
        }
        
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPlaying]);

  const handleStart = () => {
    setIsPlaying(true);
  };

  const handlePause = () => {
    setIsPlaying(false);
  };

  const handleReset = () => {
    setIsPlaying(false);
    setElapsedTime(0);
    setCurrentStageIndex(0);
    setAcknowledgedStakeholders([]);
    setShowConfetti(false);
    setIsComplete(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const currentStage = DEMO_STAGES[currentStageIndex];
  const progress = (elapsedTime / DEMO_DURATION) * 100;

  return (
    <div className="min-h-screen bg-slate-950">
      <StandardNav />
      
      {showConfetti && <Confetti recycle={false} numberOfPieces={200} />}
      
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="text-center mb-8">
          <Badge className="bg-purple-500 text-white mb-4">
            Investor Demo · Locked Preset
          </Badge>
          <h1 className="text-4xl font-bold text-white mb-2" data-testid="heading-investor-demo">
            3-Minute Platform Demo
          </h1>
          <p className="text-slate-400">
            Watch M transform a 72-hour crisis response into 12 minutes
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader className="border-b border-slate-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl ${currentStage.bgColor}`}>
                      <currentStage.icon className={`h-6 w-6 ${currentStage.color}`} />
                    </div>
                    <div>
                      <CardTitle className="text-white text-xl">{currentStage.title}</CardTitle>
                      <p className="text-slate-400">{currentStage.subtitle}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-emerald-400 font-mono">
                      {formatTime(elapsedTime)}
                    </div>
                    <div className="text-sm text-slate-500">Elapsed Time</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="mb-6">
                  <Progress value={progress} className="h-2 bg-slate-700" />
                  <div className="flex justify-between mt-2 text-xs text-slate-500">
                    <span>Signal</span>
                    <span>Recommend</span>
                    <span>Activate</span>
                    <span>Deploy</span>
                    <span>Acknowledge</span>
                    <span>Complete</span>
                  </div>
                </div>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentStage.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="bg-slate-800/50 rounded-xl p-6 border border-slate-700"
                  >
                    <p className="text-lg text-slate-300">{currentStage.description}</p>
                  </motion.div>
                </AnimatePresence>

                <div className="flex items-center justify-center gap-4 mt-6">
                  {!isPlaying && !isComplete && (
                    <Button 
                      size="lg"
                      onClick={handleStart}
                      className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white px-8"
                      data-testid="button-start-demo"
                    >
                      <Play className="mr-2 h-5 w-5" />
                      {elapsedTime > 0 ? 'Resume Demo' : 'Start Demo'}
                    </Button>
                  )}
                  {isPlaying && (
                    <Button 
                      size="lg"
                      variant="outline"
                      onClick={handlePause}
                      className="border-slate-600 text-slate-300"
                      data-testid="button-pause-demo"
                    >
                      <Pause className="mr-2 h-5 w-5" />
                      Pause
                    </Button>
                  )}
                  {elapsedTime > 0 && (
                    <Button 
                      size="lg"
                      variant="outline"
                      onClick={handleReset}
                      className="border-slate-600 text-slate-300"
                      data-testid="button-reset-demo"
                    >
                      <RotateCcw className="mr-2 h-5 w-5" />
                      Reset
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {isComplete && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
              >
                <Card className="bg-gradient-to-br from-emerald-950 to-teal-950 border-emerald-500/50">
                  <CardContent className="p-6">
                    <div className="text-center mb-6">
                      <CheckCircle2 className="h-12 w-12 text-emerald-400 mx-auto mb-3" />
                      <h3 className="text-2xl font-bold text-white">Demo Complete</h3>
                      <p className="text-emerald-300">
                        Full crisis response executed in under 3 minutes
                      </p>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-emerald-400">{formatTime(elapsedTime)}</div>
                        <div className="text-sm text-slate-400">Response Time</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-400">47</div>
                        <div className="text-sm text-slate-400">Stakeholders</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-purple-400">240x</div>
                        <div className="text-sm text-slate-400">Faster</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-center gap-4">
                      <Button 
                        className="bg-white text-slate-900 hover:bg-slate-100"
                        onClick={() => setLocation('/contact')}
                        data-testid="button-schedule-call"
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        Schedule a Call
                      </Button>
                      <Button 
                        variant="outline"
                        className="border-emerald-500 text-emerald-400 hover:bg-emerald-500/20"
                        onClick={() => setLocation('/demo')}
                      >
                        Try Interactive Demo
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          <div className="space-y-6">
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="h-5 w-5 text-blue-400" />
                  Stakeholder Feed
                  <Badge variant="secondary" className="ml-auto">
                    {acknowledgedStakeholders.length}/8
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-[400px] overflow-y-auto">
                  {acknowledgedStakeholders.length === 0 ? (
                    <div className="text-center py-8 text-slate-500">
                      Waiting for stakeholder responses...
                    </div>
                  ) : (
                    acknowledgedStakeholders.map((ack, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700"
                      >
                        <CheckCircle2 className="h-5 w-5 text-emerald-400 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-white text-sm truncate">{ack.name}</div>
                          <div className="text-xs text-slate-400 truncate">{ack.role}</div>
                        </div>
                        <Badge variant="outline" className="text-emerald-400 border-emerald-500/50 text-xs">
                          +{ack.time - 40}s
                        </Badge>
                      </motion.div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-950/50 to-blue-950/50 border-purple-500/30">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-purple-400" />
                  The M Difference
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Traditional Response</span>
                    <span className="text-red-400 font-bold">72 hours</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">With M Platform</span>
                    <span className="text-emerald-400 font-bold">~12 minutes</span>
                  </div>
                  <div className="border-t border-slate-700 pt-4">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Speed Improvement</span>
                      <span className="text-purple-400 font-bold text-xl">240x</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Value Protected</span>
                    <span className="text-amber-400 font-bold">$283K+</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-700">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-white mb-3">Demo Script</h3>
                <div className="space-y-2 text-sm">
                  {DEMO_STAGES.map((stage, index) => (
                    <div 
                      key={stage.id}
                      className={`flex items-center gap-2 p-2 rounded ${
                        index === currentStageIndex ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      <span className="font-mono text-xs w-12">{formatTime(stage.time)}</span>
                      <span className={index <= currentStageIndex ? 'text-white' : ''}>{stage.title}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
