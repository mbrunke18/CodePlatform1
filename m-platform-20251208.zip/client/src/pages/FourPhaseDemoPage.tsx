import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  FileCheck, 
  Radar, 
  Play, 
  GraduationCap,
  CheckCircle2,
  Clock,
  Zap,
  Brain,
  TrendingUp,
  ChevronRight,
  Target,
  AlertTriangle,
  Users,
  BookOpen,
  BarChart3
} from 'lucide-react';
import FourPhasePlaybookWizard from '@/components/playbook/FourPhasePlaybookWizard';
import PlaybookReadinessDashboard from '@/components/playbook/PlaybookReadinessDashboard';

const PHASE_DATA = {
  prepare: {
    icon: FileCheck,
    title: 'PREPARE',
    description: 'Build customized playbooks from 148 strategic templates',
    color: 'bg-blue-500',
    lightColor: 'bg-blue-100 dark:bg-blue-950',
    textColor: 'text-blue-600 dark:text-blue-400',
    items: [
      { name: 'Define trigger criteria', status: 'complete' },
      { name: 'Configure stakeholder matrix', status: 'complete' },
      { name: 'Set pre-approved budgets', status: 'complete' },
      { name: 'Create communication templates', status: 'pending' },
      { name: 'Test decision trees', status: 'pending' },
    ],
    readinessScore: 72,
  },
  monitor: {
    icon: Radar,
    title: 'MONITOR',
    description: 'AI watches 16 signal categories with 92+ data points',
    color: 'bg-amber-500',
    lightColor: 'bg-amber-100 dark:bg-amber-950',
    textColor: 'text-amber-600 dark:text-amber-400',
    items: [
      { name: 'Market dynamics tracking', status: 'active', signals: 23 },
      { name: 'Competitive intelligence', status: 'active', signals: 18 },
      { name: 'Regulatory alerts', status: 'active', signals: 7 },
      { name: 'Social sentiment analysis', status: 'active', signals: 34 },
    ],
    readinessScore: 85,
  },
  execute: {
    icon: Play,
    title: 'EXECUTE',
    description: '12-minute coordinated response with pre-approved resources',
    color: 'bg-green-500',
    lightColor: 'bg-green-100 dark:bg-green-950',
    textColor: 'text-green-600 dark:text-green-400',
    items: [
      { name: 'Auto-create Jira project', time: '0:30' },
      { name: 'Assign all tasks', time: '1:00' },
      { name: 'Stage documents', time: '2:00' },
      { name: 'Notify stakeholders', time: '3:00' },
      { name: 'Unlock budgets', time: '4:00' },
      { name: 'Begin execution', time: '5:00' },
    ],
    readinessScore: 90,
  },
  learn: {
    icon: GraduationCap,
    title: 'LEARN',
    description: 'AI-powered analysis captures insights for continuous improvement',
    color: 'bg-purple-500',
    lightColor: 'bg-purple-100 dark:bg-purple-950',
    textColor: 'text-purple-600 dark:text-purple-400',
    items: [
      { name: 'Execution metrics captured', insight: '8.3 min average response time' },
      { name: 'Stakeholder feedback', insight: '94% positive sentiment' },
      { name: 'Process improvements', insight: '3 bottlenecks identified' },
      { name: 'Playbook updates', insight: '2 recommendations pending' },
    ],
    readinessScore: 65,
  },
};

export default function FourPhaseDemoPage() {
  const [activePhase, setActivePhase] = useState<'prepare' | 'monitor' | 'execute' | 'learn'>('prepare');
  const [showWizard, setShowWizard] = useState(false);
  const [selectedPlaybook, setSelectedPlaybook] = useState<any>(null);

  const { data: libraryData } = useQuery<any>({
    queryKey: ['/api/playbook-library'],
  });

  const playbooks = libraryData?.playbooks || [];
  const demoPlaybook = playbooks[0];

  const overallReadiness = Math.round(
    (PHASE_DATA.prepare.readinessScore * 0.4 +
      PHASE_DATA.monitor.readinessScore * 0.2 +
      PHASE_DATA.execute.readinessScore * 0.3 +
      PHASE_DATA.learn.readinessScore * 0.1)
  );

  const currentPhase = PHASE_DATA[activePhase];
  const PhaseIcon = currentPhase.icon;

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card/50 py-6 px-6">
        <h1 className="text-3xl font-bold">4-Phase System Demo</h1>
        <p className="text-muted-foreground mt-1">PREPARE → MONITOR → EXECUTE → LEARN</p>
      </div>
      <div className="p-6 space-y-8" data-testid="four-phase-demo-page">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="border-2 border-primary/20">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl flex items-center gap-3">
                      <Brain className="h-7 w-7 text-primary" />
                      Future Readiness Index™
                    </CardTitle>
                    <CardDescription className="text-base mt-1">
                      Your organization's strategic preparedness score
                    </CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-5xl font-bold text-primary">{overallReadiness}%</div>
                    <div className="text-sm text-muted-foreground">Target: 84.4%</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Progress value={overallReadiness} className="h-4 mb-6" />
                
                <div className="grid grid-cols-4 gap-4">
                  {(Object.entries(PHASE_DATA) as [keyof typeof PHASE_DATA, typeof PHASE_DATA.prepare][]).map(([key, phase]) => {
                    const Icon = phase.icon;
                    const isActive = activePhase === key;
                    return (
                      <button
                        key={key}
                        onClick={() => setActivePhase(key)}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          isActive 
                            ? 'border-primary bg-primary/5' 
                            : 'border-transparent hover:border-primary/20'
                        }`}
                        data-testid={`phase-button-${key}`}
                      >
                        <div className={`w-10 h-10 rounded-full ${phase.color} flex items-center justify-center mb-2 mx-auto`}>
                          <Icon className="h-5 w-5 text-white" />
                        </div>
                        <div className="text-sm font-medium">{phase.title}</div>
                        <div className="text-2xl font-bold mt-1">{phase.readinessScore}%</div>
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => {
                  setSelectedPlaybook(demoPlaybook);
                  setShowWizard(true);
                }}
                data-testid="button-open-wizard"
              >
                <FileCheck className="h-4 w-4 mr-2" />
                Open 4-Phase Wizard
              </Button>
              <Button className="w-full justify-start" variant="outline" data-testid="button-view-signals">
                <Radar className="h-4 w-4 mr-2" />
                View Active Signals
              </Button>
              <Button className="w-full justify-start" variant="outline" data-testid="button-run-drill">
                <Play className="h-4 w-4 mr-2" />
                Run Practice Drill
              </Button>
              <Button className="w-full justify-start" variant="outline" data-testid="button-view-learnings">
                <GraduationCap className="h-4 w-4 mr-2" />
                View AI Learnings
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className={`${currentPhase.lightColor} rounded-t-lg`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-full ${currentPhase.color} flex items-center justify-center`}>
                  <PhaseIcon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-xl">{currentPhase.title} Phase</CardTitle>
                  <CardDescription>{currentPhase.description}</CardDescription>
                </div>
              </div>
              <Badge className={currentPhase.textColor} variant="outline">
                {currentPhase.readinessScore}% Ready
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            {activePhase === 'prepare' && (
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  Preparation Checklist
                </h4>
                <div className="space-y-2">
                  {currentPhase.items.map((item: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-3">
                        {item.status === 'complete' ? (
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                        ) : (
                          <div className="h-5 w-5 rounded-full border-2 border-muted-foreground/30" />
                        )}
                        <span>{item.name}</span>
                      </div>
                      <Badge variant={item.status === 'complete' ? 'default' : 'secondary'}>
                        {item.status === 'complete' ? 'Complete' : 'Pending'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activePhase === 'monitor' && (
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Radar className="h-4 w-4 text-amber-500" />
                  Active Signal Categories
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  {currentPhase.items.map((item: any, i: number) => (
                    <div key={i} className="p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{item.name}</span>
                        <Badge variant="outline" className="text-amber-600">
                          {item.signals} signals
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        Active monitoring
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activePhase === 'execute' && (
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Clock className="h-4 w-4 text-green-500" />
                  12-Minute Execution Timeline
                </h4>
                <div className="relative">
                  <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-green-200" />
                  <div className="space-y-4 pl-10">
                    {currentPhase.items.map((item: any, i: number) => (
                      <div key={i} className="relative">
                        <div className="absolute -left-6 w-4 h-4 rounded-full bg-green-500 flex items-center justify-center">
                          <div className="w-2 h-2 rounded-full bg-white" />
                        </div>
                        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <span>{item.name}</span>
                          <Badge variant="outline" className="text-green-600">
                            {item.time}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activePhase === 'learn' && (
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Brain className="h-4 w-4 text-purple-500" />
                  AI-Powered Insights
                </h4>
                <div className="space-y-3">
                  {currentPhase.items.map((item: any, i: number) => (
                    <div key={i} className="p-4 bg-muted/50 rounded-lg">
                      <div className="font-medium mb-1">{item.name}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-purple-500" />
                        {item.insight}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {demoPlaybook && (
            <PlaybookReadinessDashboard playbookId={demoPlaybook.id} organizationId="demo-org" />
          )}
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Sample Playbooks
              </CardTitle>
              <CardDescription>
                Select a playbook to explore the 4-phase wizard
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {playbooks.slice(0, 5).map((playbook: any) => (
                  <button
                    key={playbook.id}
                    onClick={() => {
                      setSelectedPlaybook(playbook);
                      setShowWizard(true);
                    }}
                    className="w-full p-4 text-left bg-muted/50 hover:bg-muted rounded-lg transition-colors flex items-center justify-between group"
                    data-testid={`playbook-card-${playbook.id}`}
                  >
                    <div>
                      <div className="font-medium">{playbook.name}</div>
                      <div className="text-sm text-muted-foreground">{playbook.domain}</div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {selectedPlaybook && (
        <FourPhasePlaybookWizard
          playbook={selectedPlaybook}
          organizationId="demo-org"
          isOpen={showWizard}
          onClose={() => {
            setShowWizard(false);
            setSelectedPlaybook(null);
          }}
        />
      )}
    </div>
  );
}
