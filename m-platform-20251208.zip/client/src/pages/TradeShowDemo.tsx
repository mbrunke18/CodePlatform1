import StandardNav from '@/components/layout/StandardNav';
import { useState, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { updatePageMetadata } from '@/lib/seo';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Briefcase,
  DollarSign,
  Settings,
  TrendingUp,
  Server,
  Shield,
  Users,
  Scale,
  Database,
  FileCheck,
  Target,
  AlertTriangle,
  X,
  Maximize2,
  RotateCcw,
  Keyboard,
  ChevronRight
} from 'lucide-react';

type Role = 'CEO' | 'CFO' | 'COO' | 'CMO' | 'CRO' | 'CTO' | 'CISO' | 'CHRO' | 'CDO' | 'GC' | 'CCO' | 'CSO';
type DemoPhase = 'role-select' | 'hook' | 'demo' | 'results' | 'lead-capture';

interface RoleConfig {
  id: Role;
  title: string;
  icon: any;
  color: string;
  hook: {
    question: string;
    pauseText?: string;
    problem: string;
    cost: string;
    solution: string;
    cta: string;
  };
  scenarioType: 'competitive' | 'financial' | 'operational' | 'security' | 'compliance';
  scenarioId: string;
  keyMetrics: string[];
  demoStory: {
    situation: string;
    traditionalTime: string;
    vexorTime: string;
    impact: string;
  };
}

const roleConfigs: RoleConfig[] = [
  {
    id: 'CEO',
    title: 'Chief Executive Officer',
    icon: Briefcase,
    color: 'blue',
    hook: {
      question: "What percentage of your strategic initiatives actually deliver on time and on budget?",
      pauseText: "Most CEOs say 60-70%",
      problem: "McKinsey research on 757 Fortune 1000 CEOs found: You're losing 30% of your strategic value—$144 million annually—not to bad strategy, but to execution gaps.",
      cost: "Your board approved a strategy that should generate $100M. You're delivering $70M. The $30M gap? Coordination delays between your decision and your organization's execution.",
      solution: "Here's what that looks like: You decide Monday to respond to a competitive threat. Your organization schedules meetings, aligns stakeholders, navigates approvals. Three weeks later, you respond. Your competitor responded Day 3.",
      cta: "I spent five years making decisions that had to coordinate across 11 people in 40 seconds. I built the system that brings that to business."
    },
    scenarioType: 'competitive',
    scenarioId: 'competitive-response',
    keyMetrics: ['21 days → 3 days', '$12M market share protected', '18-day competitive advantage'],
    demoStory: {
      situation: 'Competitor launches a product targeting your core customers on Monday morning',
      traditionalTime: '21 days to coordinate brand, content, digital, PR, and legal',
      vexorTime: '3 days - all teams receive coordinated assignments simultaneously',
      impact: '18-day advantage, $12M market share protected'
    }
  },
  {
    id: 'CFO',
    title: 'Chief Financial Officer',
    icon: DollarSign,
    color: 'green',
    hook: {
      question: "What's your company's biggest untracked expense that doesn't show up on any line item?",
      pauseText: "Think about it...",
      problem: "Coordination overhead. McKinsey just quantified it: $144 million annually for the typical Fortune 1000 company.",
      cost: "Deals lost because you moved too slow: $52M. Meetings, rework, delays: $38M. Crisis damage from slow response: $23M. Revenue delayed from slow launches: $31M.",
      solution: "Your teams spend 127,000 hours per year in coordination meetings that create zero value. Here's the ROI I'm offering: $114 million Year 1 return. Payback period: 6.3 weeks.",
      cta: "That's faster than your last ERP upgrade, your Salesforce expansion, your operating model redesign—faster than any strategic initiative you've approved in three years."
    },
    scenarioType: 'financial',
    scenarioId: 'strategic-realignment',
    keyMetrics: ['$114M Year 1 ROI', '6.3 week payback', '$144M coordination overhead eliminated'],
    demoStory: {
      situation: 'Strategic pivot requires reallocating $120M and 1,200 FTEs across new priorities',
      traditionalTime: '12 months of planning meetings, budget negotiations, and sequential approvals',
      vexorTime: '9 months with coordinated execution across all departments simultaneously',
      impact: '$114M ROI Year 1, 12% market share gain, $85M revenue uplift'
    }
  },
  {
    id: 'COO',
    title: 'Chief Operating Officer',
    icon: Settings,
    color: 'orange',
    hook: {
      question: "You have a well-designed supply chain continuity plan, right? When was the last time you actually executed it at the speed the plan assumes?",
      problem: "Every COO I talk to has the same problem: Great processes on paper. Slow execution in reality. Not because your people aren't capable. Because coordination takes time.",
      cost: "Last month, a competitor's primary supplier went down at 3 AM. Traditional response: 72 hours to coordinate procurement, logistics, operations, finance, and legal. Three days of downtime. $2.1M in rush orders.",
      solution: "With the system I built: 12 minutes to activate pre-negotiated backup suppliers, re-route logistics, notify customers. Zero downtime. Zero rush orders.",
      cta: "I spent five years coordinating 11 people in 40 seconds in high-pressure situations. I know what operational excellence at speed looks like."
    },
    scenarioType: 'operational',
    scenarioId: 'supply-chain-disruption',
    keyMetrics: ['72 hours → 12 minutes', '$2.1M rush costs avoided', 'Zero operational downtime'],
    demoStory: {
      situation: 'Primary supplier goes down at 3 AM, threatening production and customer commitments',
      traditionalTime: '72 hours to coordinate procurement, logistics, operations, finance, legal',
      vexorTime: '12 minutes to activate backup supplier playbook with all teams coordinated',
      impact: 'Zero downtime, $2.1M in rush costs avoided, customer satisfaction maintained'
    }
  },
  {
    id: 'CMO',
    title: 'Chief Marketing Officer',
    icon: TrendingUp,
    color: 'purple',
    hook: {
      question: "Your competitor launches a product tomorrow targeting your core customers. How long until your counter-campaign is in market?",
      pauseText: "Most say 'weeks'",
      problem: "Three weeks is typical. Problem: Your competitor's message has three weeks to land with your customers before you respond. Last quarter, a Fortune 500 company lost $12M in market share because their competitive response took 21 days. Their competitor moved in 3 days.",
      cost: "Your brand team needs messaging. Your content team needs assets. Your digital team needs campaigns. Your PR team needs positioning. Your legal team needs approval. Sequential coordination: 21 days.",
      solution: "I built the system that makes all five teams receive coordinated assignments simultaneously and execute in 3 days. Same competitive threat. 18-day advantage.",
      cta: "Want to see how you become the brand that defines the narrative instead of responding to it?"
    },
    scenarioType: 'competitive',
    scenarioId: 'competitive-response',
    keyMetrics: ['21 days → 3 days', '18-day advantage', '$12M market share protected'],
    demoStory: {
      situation: 'Competitor launches product targeting your core customers Monday morning',
      traditionalTime: '21 days - sequential coordination across brand, content, digital, PR, legal teams',
      vexorTime: '3 days - all teams receive coordinated campaign assignments simultaneously',
      impact: '18-day competitive advantage, $12M market share protected, narrative control'
    }
  },
  {
    id: 'CTO',
    title: 'Chief Technology Officer',
    icon: Server,
    color: 'cyan',
    hook: {
      question: "Your CEO announces a major digital transformation initiative Monday morning. How long until IT, security, data, operations, HR, and finance are actually coordinating the execution?",
      pauseText: "Weeks, right?",
      problem: "You have the technology roadmap. You have the budget. You have the talent. But coordination across business units takes forever. Last year, a Fortune 500 CTO's digital transformation took 18 months instead of 12—not because of technology complexity, but because coordinating IT, security, compliance, business units, and change management took 6 months longer than planned.",
      cost: "McKinsey: Companies lose 30% of transformation value to coordination delays. That's $144M annually. Your technology stack is excellent—Salesforce, SAP, ServiceNow, Teams. But they don't coordinate each other.",
      solution: "I built the execution layer that orchestrates your entire stack. When conditions demand coordinated action—security incident, system outage, transformation milestone—IT, security, operations, compliance, and business units receive coordinated assignments simultaneously.",
      cta: "Want to see how your technology investments finally coordinate at the speed of business decisions?"
    },
    scenarioType: 'operational',
    scenarioId: 'digital-transformation',
    keyMetrics: ['36 → 22 months', '$12M ROI', '82% adoption rate'],
    demoStory: {
      situation: '$45M digital transformation replacing 15-year-old systems across 12,000 employees',
      traditionalTime: '36 months with waterfall planning, big-bang rollout, reactive troubleshooting',
      vexorTime: '22 months with phased adoption, AI-monitored progress, proactive interventions',
      impact: '$12M ROI, 82% adoption rate, prevented 3-month delays through early intervention'
    }
  },
  {
    id: 'CISO',
    title: 'Chief Information Security Officer',
    icon: Shield,
    color: 'red',
    hook: {
      question: "You detect a security breach at 2 AM. How long until IT, legal, communications, HR, operations, and executive leadership are executing a coordinated incident response?",
      pauseText: "Hours, typically. And every hour matters.",
      problem: "Last year, a Fortune 500 company had a breach detected at 2:47 AM. Their coordinated response went live at 11 AM—8 hours and 13 minutes later. By then, the breach had spread to three additional systems.",
      cost: "The problem wasn't your incident response plan. You have an excellent plan. The problem was coordination: IT needs to contain, legal needs to assess obligations, communications needs to draft statements, HR needs to notify employees, operations needs continuity protocols, executives need briefings.",
      solution: "I built the system that makes your incident response plan execute at the speed it was designed for. 2:47 AM: Breach detected. 2:58 AM: Pre-built playbook activates. 3:09 AM: IT, legal, comms, HR, operations, executives—all executing coordinated response. 47 minutes instead of 8 hours.",
      cta: "In cybersecurity, time is damage. Every minute of delay is data, reputation, regulatory exposure."
    },
    scenarioType: 'security',
    scenarioId: 'security-breach',
    keyMetrics: ['8 hours → 47 minutes', 'Breach contained', '3 systems protected'],
    demoStory: {
      situation: 'Security breach detected at 2:47 AM - unauthorized access to customer database',
      traditionalTime: '8 hours 13 minutes to coordinate IT, legal, comms, HR, operations, executives',
      vexorTime: '47 minutes - pre-built incident response playbook activates all teams instantly',
      impact: 'Breach contained before spreading to 3 other systems, reputation protected'
    }
  },
  {
    id: 'CHRO',
    title: 'Chief Human Resources Officer',
    icon: Users,
    color: 'pink',
    hook: {
      question: "What's the #1 reason your top performers give in exit interviews?",
      pauseText: "Let me guess: Some version of 'I'm frustrated by how slow we move' or 'I can't get things done here.'",
      problem: "Last year, you lost high performers. At $250K average replacement cost plus productivity loss, that's millions. But here's the invisible cost: the best people in your industry won't even interview with you because they've heard your culture is slow.",
      cost: "In 2028, when college freshmen graduate, they'll interview with you and ask: 'How fast does work happen here?' If you say 'We schedule meetings to discuss responses,' they'll join your competitor who says: 'We execute strategic decisions in 12 minutes.'",
      solution: "I built the system that makes your organization the place top performers choose—and stay. You'll see your work impact the business same-day, not next quarter.",
      cta: "Want to see how you become the company that executes while others coordinate?"
    },
    scenarioType: 'operational',
    scenarioId: 'culture-transformation',
    keyMetrics: ['85% engagement achieved', '$2.1M saved', '40% faster adoption'],
    demoStory: {
      situation: 'Board mandates culture shift from hierarchical to collaborative across 8,000 employees',
      traditionalTime: '24-36 months with consultants, uncertain ROI, fragmented adoption',
      vexorTime: '18 months with measurable milestones, AI-monitored sentiment, triggered interventions',
      impact: '85% engagement, $2.1M saved, 40% faster adoption, top talent retention'
    }
  },
  {
    id: 'CDO',
    title: 'Chief Data Officer',
    icon: Database,
    color: 'indigo',
    hook: {
      question: "You've built an incredible data infrastructure. Analytics, AI, dashboards—your data tells you exactly what's happening. But when your data signals 'Customer churn risk' or 'Supply chain disruption incoming,' how long until the organization actually acts on that insight?",
      problem: "You're not struggling with data quality or analytics. You're struggling with data-to-action speed. Your dashboard shows 'Enterprise customer X showing churn signals.' You alert the account team. They schedule a meeting. They coordinate with product, success, and leadership. Two weeks later, they reach out to the customer.",
      cost: "Customer churned on Day 8. McKinsey: Companies lose $144M annually to coordination delays. In data-driven organizations, that's the gap between insight and action.",
      solution: "I built the system that closes the insight-to-action gap. Your AI detects customer churn risk. M activates 'Customer Retention' playbook. Account team, product team, success team, executive sponsor—all receive coordinated assignments within minutes.",
      cta: "Your data finally drives action at the speed of the insight."
    },
    scenarioType: 'operational',
    scenarioId: 'customer-retention',
    keyMetrics: ['14 days → 2 hours', 'Insight-to-action gap closed', '92% customer save rate'],
    demoStory: {
      situation: 'AI detects enterprise customer showing churn signals - $2.4M annual contract at risk',
      traditionalTime: '14 days to coordinate account team, product, success, and executive sponsor',
      vexorTime: '2 hours - retention playbook activates all stakeholders with coordinated rescue plan',
      impact: 'Customer saved, $2.4M contract renewed, data-to-action speed demonstrated'
    }
  },
  {
    id: 'GC',
    title: 'General Counsel',
    icon: Scale,
    color: 'slate',
    hook: {
      question: "Regulatory change announced Friday afternoon. Multiple business units affected. How long until you have legal assessment complete, business impact understood, compliance protocols updated, and organization executing the required changes?",
      pauseText: "Weeks, typically. Meanwhile, the compliance clock is ticking.",
      problem: "Last quarter, a company faced a regulatory deadline: 60 days to compliance. Legal analysis took 2 weeks. Coordinating business unit responses took another 3 weeks. Implementation took 5 weeks. They hit the deadline with 2 days to spare.",
      cost: "Legal isn't the bottleneck. You provide excellent counsel. The bottleneck is coordination between legal, compliance, operations, IT, HR, and affected business units.",
      solution: "I built the system that makes regulatory response coordinate in days, not weeks. Regulation announced. 'Regulatory Compliance' playbook activates. Legal analysis, compliance updates, IT changes, HR training, operational modifications—all coordinating simultaneously. Five weeks becomes 10 days.",
      cta: "Want to see how legal counsel translates into organizational compliance at the speed regulations demand?"
    },
    scenarioType: 'compliance',
    scenarioId: 'regulatory-compliance',
    keyMetrics: ['5 weeks → 10 days', 'Deadline met easily', '6-team coordination'],
    demoStory: {
      situation: 'New regulation announced Friday - 60 days to compliance across multiple business units',
      traditionalTime: '5 weeks for sequential legal analysis, business coordination, implementation',
      vexorTime: '10 days with parallel execution across legal, compliance, IT, HR, and operations',
      impact: 'Met deadline with 50 days to spare, reduced compliance risk, confident execution'
    }
  },
  {
    id: 'CCO',
    title: 'Chief Compliance Officer',
    icon: FileCheck,
    color: 'teal',
    hook: {
      question: "Audit notification arrives Monday morning. Multiple departments need to provide documentation, evidence, and responses. Deadline: 2 weeks. How long until you actually have coordinated responses from IT, finance, operations, legal, and HR?",
      pauseText: "Usually takes the full 2 weeks, right? Everyone scrambling, emails flying, last-minute coordination.",
      problem: "Last month, a compliance officer got a regulatory audit notice with a 10-day response window. Day 8: Still coordinating responses from six departments. Days 9-10: Working around the clock to compile everything.",
      cost: "The problem isn't that your teams don't care about compliance. The problem is coordination: IT needs to pull system logs. Finance needs transaction records. Operations needs process documentation. Legal needs contract evidence. HR needs training records.",
      solution: "I built the system that makes audit response coordinate like a well-rehearsed plan. Audit notice received. 'Regulatory Audit Response' playbook activates. IT, finance, operations, legal, HR—all receive specific documentation requests with templates, deadlines, and submission protocols. Day 2: All responses compiled and ready.",
      cta: "Want to see how you go from deadline stress to deadline confidence?"
    },
    scenarioType: 'compliance',
    scenarioId: 'audit-response',
    keyMetrics: ['10 days → 2 days', 'Stress eliminated', '6 departments coordinated'],
    demoStory: {
      situation: 'Regulatory audit notification Monday - 10 days to provide comprehensive documentation',
      traditionalTime: '10 days of scrambling, emails, last-minute requests across 6 departments',
      vexorTime: '2 days - audit response playbook gives each department templated assignments',
      impact: 'All documentation compiled Day 2, audit confidence, no last-minute panic'
    }
  },
  {
    id: 'CSO',
    title: 'Chief Strategy Officer',
    icon: Target,
    color: 'violet',
    hook: {
      question: "You develop brilliant strategies. Board approves them. Resources allocated. Clear objectives set. Six months later, how much of that strategy is actually executing as planned?",
      pauseText: "Most say 60-70%",
      problem: "McKinsey just quantified that: 70%. Even high-performing companies deliver only 70% of strategic potential. The 30% gap—$144 million annually—is execution delays.",
      cost: "You present strategy. Everyone nods. Initiatives get assigned. Then… coordination hell. Cross-functional teams can't align. Resources don't deploy fast enough. Dependencies block progress. Status meetings reveal everyone's working, but nothing's coordinating.",
      solution: "I built the system that closes the strategy-to-execution gap. Strategic initiative approved. Decision playbook activates. All six functions receive coordinated assignments, resources, timelines, and dependencies mapped. Your strategy executes at the speed it was designed for. 70% delivery becomes 95% delivery.",
      cta: "Want to see how your strategies finally execute as brilliantly as they're designed?"
    },
    scenarioType: 'operational',
    scenarioId: 'strategic-realignment',
    keyMetrics: ['70% → 95% delivery', '$144M gap closed', '9-month execution'],
    demoStory: {
      situation: 'Board approves $100M strategic initiative - reallocate resources across 6 functions',
      traditionalTime: '12 months with coordination delays, dependency blocks, alignment struggles',
      vexorTime: '9 months with coordinated assignments, mapped dependencies, real-time tracking',
      impact: '95% strategic value delivered (vs 70% traditional), $144M execution gap closed'
    }
  },
  {
    id: 'CRO',
    title: 'Chief Revenue Officer',
    icon: TrendingUp,
    color: 'emerald',
    hook: {
      question: "What's your average time from 'customer requests proposal' to 'proposal delivered'?",
      pauseText: "Most say 2-3 weeks. And your top competitor? They're doing it in 5-7 days.",
      problem: "You're doing it in 21. That 14-day gap is why your win rate is lower than it should be. Last quarter, how many deals came down to 'They moved faster'?",
      cost: "Your deals don't die because of product or price. They die because while you're coordinating—getting legal review, waiting for finance approval, aligning on messaging—your competitor is presenting.",
      solution: "I built the system that takes your proposal cycle from 21 days to 5 days. Sales, legal, finance, product—all coordinating simultaneously instead of sequentially. That 16-day advantage turns into 5 percentage points of win rate. At your deal sizes, that's $44M annually.",
      cta: "Want to see how you close before your competitor even responds?"
    },
    scenarioType: 'competitive',
    scenarioId: 'deal-acceleration',
    keyMetrics: ['21 days → 5 days', '+5% win rate', '$44M annual revenue'],
    demoStory: {
      situation: 'Enterprise customer requests comprehensive proposal - $8M deal on the line',
      traditionalTime: '21 days for sequential legal review, finance approval, product alignment',
      vexorTime: '5 days with simultaneous coordination across sales, legal, finance, product',
      impact: '16-day competitive advantage, +5% win rate, $44M annual revenue impact'
    }
  }
];

export default function TradeShowDemo() {
  const [currentPhase, setCurrentPhase] = useState<DemoPhase>('role-select');
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [showPresenterPanel, setShowPresenterPanel] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [leadData, setLeadData] = useState({ name: '', email: '', company: '' });
  const { toast } = useToast();

  // Mutation to save demo lead to database
  const saveLeadMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', '/api/demo-leads', data);
    },
    onSuccess: () => {
      toast({
        title: "Request Submitted Successfully!",
        description: `Thank you, ${leadData.name}! We'll send information about ${selectedRole} solutions to ${leadData.email}`,
      });
      resetDemo();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save your information. Please try again.",
        variant: "destructive"
      });
    }
  });

  useEffect(() => {
    updatePageMetadata({
      title: "Trade Show Demo - M Strategic Execution Operating System",
      description: "Interactive trade show demonstration of M's decision execution platform",
      ogTitle: "M Trade Show Demo",
      ogDescription: "See how Fortune 1000 companies execute strategic decisions in 12 minutes",
    });
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Toggle presenter panel with ~ key
      if (e.key === '`' || e.key === '~') {
        setShowPresenterPanel(prev => !prev);
        e.preventDefault();
        return;
      }

      // Role shortcuts (1-9, 0 for roles 10-12)
      const roleShortcuts: { [key: string]: Role } = {
        '1': 'CEO',
        '2': 'CFO',
        '3': 'COO',
        '4': 'CMO',
        '5': 'CRO',
        '6': 'CTO',
        '7': 'CISO',
        '8': 'CHRO',
        '9': 'CDO',
        '0': 'GC',
        '-': 'CCO',
        '=': 'CSO'
      };

      if (roleShortcuts[e.key]) {
        selectRole(roleShortcuts[e.key]);
      }

      // Reset with R key
      if (e.key === 'r' || e.key === 'R') {
        resetDemo();
      }

      // Fullscreen with F key
      if (e.key === 'f' || e.key === 'F') {
        toggleFullScreen();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  const selectRole = (role: Role) => {
    setSelectedRole(role);
    setCurrentPhase('hook');
  };

  const proceedToDemo = () => {
    setCurrentPhase('demo');
  };

  const showResults = () => {
    setCurrentPhase('results');
  };

  const captureLeadAndReset = () => {
    // Save lead to database via API
    const capturedData = { 
      ...leadData, 
      role: selectedRole,
      source: 'trade-show-demo',
      metadata: {
        scenarioType: currentRoleConfig?.scenarioType,
        scenarioId: currentRoleConfig?.scenarioId,
        timestamp: new Date().toISOString()
      }
    };
    
    saveLeadMutation.mutate(capturedData);
  };

  const resetDemo = () => {
    setCurrentPhase('role-select');
    setSelectedRole(null);
    setLeadData({ name: '', email: '', company: '' });
  };

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullScreen(true);
    } else {
      document.exitFullscreen();
      setIsFullScreen(false);
    }
  };

  const currentRoleConfig = selectedRole ? roleConfigs.find(r => r.id === selectedRole) : null;

  return (
    <div className="page-background min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white relative">
      {/* Presenter Control Panel */}
      {showPresenterPanel && (
        <div className="fixed top-4 right-4 z-50 bg-slate-800/95 backdrop-blur-sm border-2 border-yellow-500 rounded-lg p-4 w-80 shadow-2xl" data-testid="presenter-panel">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Keyboard className="h-5 w-5 text-yellow-500" />
              <h3 className="text-sm font-bold text-yellow-500">Presenter Controls</h3>
            </div>
            <button onClick={() => setShowPresenterPanel(false)} className="text-gray-400 hover:text-white">
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-1">
              {roleConfigs.map((role, idx) => (
                <button
                  key={role.id}
                  onClick={() => selectRole(role.id)}
                  className="bg-slate-700 hover:bg-slate-600 px-2 py-1 rounded text-left"
                  data-testid={`presenter-role-${role.id.toLowerCase()}`}
                >
                  <span className="text-yellow-400 font-mono">{idx + 1 <= 9 ? idx + 1 : idx === 9 ? '0' : idx === 10 ? '-' : '='}</span> {role.id}
                </button>
              ))}
            </div>
            <div className="border-t border-slate-700 pt-2 mt-2 space-y-1">
              <div><span className="text-yellow-400 font-mono">~</span> Toggle this panel</div>
              <div><span className="text-yellow-400 font-mono">R</span> Reset demo</div>
              <div><span className="text-yellow-400 font-mono">F</span> Toggle fullscreen</div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Controls */}
      <div className="fixed bottom-4 right-4 z-40 flex gap-2">
        <Button
          onClick={() => setShowPresenterPanel(!showPresenterPanel)}
          variant="outline"
          size="sm"
          className="bg-slate-800/90 backdrop-blur-sm border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-slate-900"
          data-testid="button-toggle-presenter"
        >
          <Keyboard className="h-4 w-4 mr-1" />
          Controls (~)
        </Button>
        <Button
          onClick={resetDemo}
          variant="outline"
          size="sm"
          className="bg-slate-800/90 backdrop-blur-sm"
          data-testid="button-reset"
        >
          <RotateCcw className="h-4 w-4 mr-1" />
          Reset (R)
        </Button>
        <Button
          onClick={toggleFullScreen}
          variant="outline"
          size="sm"
          className="bg-slate-800/90 backdrop-blur-sm"
          data-testid="button-fullscreen"
        >
          <Maximize2 className="h-4 w-4 mr-1" />
          Full (F)
        </Button>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        {/* Phase: Role Selection */}
        {currentPhase === 'role-select' && (
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-blue-600 text-white px-4 py-1" data-testid="badge-trade-show">
                Trade Show Demo
              </Badge>
              <h1 className="text-5xl font-bold mb-4" data-testid="heading-main">
                Welcome to M
              </h1>
              <p className="text-xl text-blue-200 mb-2">
                Strategic Execution Operating System
              </p>
              <p className="text-lg text-blue-300">
                Before we begin, what's your role?
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {roleConfigs.map((role) => {
                const Icon = role.icon;
                return (
                  <button
                    key={role.id}
                    onClick={() => selectRole(role.id)}
                    className="group bg-slate-800/50 hover:bg-slate-700/70 border-2 border-slate-700 hover:border-blue-500 rounded-xl p-6 transition-all duration-200 hover:scale-105"
                    data-testid={`role-${role.id.toLowerCase()}`}
                  >
                    <div className={`bg-${role.color}-500/10 rounded-lg p-3 mb-3 inline-flex`}>
                      <Icon className={`h-8 w-8 text-${role.color}-400`} />
                    </div>
                    <div className="text-sm font-bold mb-1">{role.id}</div>
                    <div className="text-xs text-gray-400">{role.title}</div>
                  </button>
                );
              })}
            </div>

            <div className="text-center mt-8 text-sm text-gray-400">
              Press 1-9, 0, -, or = for quick selection | Press ~ for presenter controls
            </div>
          </div>
        )}

        {/* Phase: Hook */}
        {currentPhase === 'hook' && currentRoleConfig && (
          <div className="max-w-4xl mx-auto">
            <Card className="bg-gradient-to-br from-slate-800/90 to-blue-900/50 border-2 border-blue-500 backdrop-blur-sm">
              <CardContent className="p-12">
                <div className="text-center mb-8">
                  <Badge className={`bg-${currentRoleConfig.color}-500 mb-4`} data-testid="badge-role">
                    {currentRoleConfig.id} - {currentRoleConfig.title}
                  </Badge>
                </div>

                <div className="space-y-8 text-lg">
                  {/* Question */}
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-100 mb-4" data-testid="text-hook-question">
                      "{currentRoleConfig.hook.question}"
                    </p>
                    {currentRoleConfig.hook.pauseText && (
                      <p className="text-gray-400 italic">
                        {currentRoleConfig.hook.pauseText}
                      </p>
                    )}
                  </div>

                  {/* Problem */}
                  <div className="bg-red-500/10 border-l-4 border-red-500 p-6 rounded-r-lg">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="h-6 w-6 text-red-400 flex-shrink-0 mt-1" />
                      <p className="text-gray-200" data-testid="text-hook-problem">{currentRoleConfig.hook.problem}</p>
                    </div>
                  </div>

                  {/* Cost */}
                  <div className="bg-orange-500/10 border-l-4 border-orange-500 p-6 rounded-r-lg">
                    <div className="flex items-start gap-3">
                      <DollarSign className="h-6 w-6 text-orange-400 flex-shrink-0 mt-1" />
                      <p className="text-gray-200" data-testid="text-hook-cost">{currentRoleConfig.hook.cost}</p>
                    </div>
                  </div>

                  {/* Solution */}
                  <div className="bg-green-500/10 border-l-4 border-green-500 p-6 rounded-r-lg">
                    <div className="flex items-start gap-3">
                      <Target className="h-6 w-6 text-green-400 flex-shrink-0 mt-1" />
                      <p className="text-gray-200" data-testid="text-hook-solution">{currentRoleConfig.hook.solution}</p>
                    </div>
                  </div>

                  {/* CTA */}
                  <div className="text-center pt-4">
                    <p className="text-xl font-bold text-cyan-300 mb-6" data-testid="text-hook-cta">
                      {currentRoleConfig.hook.cta}
                    </p>
                    <Button
                      onClick={proceedToDemo}
                      size="lg"
                      className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg"
                      data-testid="button-proceed-demo"
                    >
                      See How It Works
                      <ChevronRight className="ml-2 h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Phase: Demo (Scenario showcase) */}
        {currentPhase === 'demo' && currentRoleConfig && (
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-2" data-testid="heading-demo">
                Real-World Scenario: {currentRoleConfig.id}
              </h2>
              <p className="text-blue-200">
                See how M delivers championship-level execution speed
              </p>
            </div>

            {/* Key Metrics Display */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              {currentRoleConfig.keyMetrics.map((metric, idx) => (
                <Card key={idx} className="bg-gradient-to-br from-blue-900/50 to-purple-900/30 border-2 border-blue-500/50">
                  <CardContent className="p-6 text-center">
                    <div className="text-2xl font-bold text-blue-300">{metric}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Situation */}
            <Card className="bg-slate-800/70 border-blue-500/30 mb-6">
              <CardContent className="p-8">
                <div className="flex items-start gap-4">
                  <AlertTriangle className="h-8 w-8 text-orange-400 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold mb-2 text-orange-300">The Situation</h3>
                    <p className="text-lg text-gray-200" data-testid="text-demo-situation">
                      {currentRoleConfig.demoStory.situation}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Side-by-side comparison */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {/* Traditional Approach */}
              <Card className="bg-gradient-to-br from-red-900/30 to-slate-800/50 border-2 border-red-500/30">
                <CardContent className="p-8">
                  <div className="text-center mb-4">
                    <div className="text-sm font-semibold text-red-400 mb-2">Traditional Approach</div>
                    <div className="text-4xl font-bold text-red-400" data-testid="text-traditional-time">
                      {currentRoleConfig.demoStory.traditionalTime.split(' ')[0]} {currentRoleConfig.demoStory.traditionalTime.split(' ')[1] || ''}
                    </div>
                  </div>
                  <div className="space-y-3 text-sm text-gray-300">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span>Sequential coordination</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span>Email chains & meetings</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span>Approval bottlenecks</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span>Reactive problem-solving</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* M Approach */}
              <Card className="bg-gradient-to-br from-green-900/30 to-blue-900/50 border-2 border-green-500 relative overflow-hidden">
                <div className="absolute top-2 right-2">
                  <Badge className="bg-green-500 text-white">M</Badge>
                </div>
                <CardContent className="p-8">
                  <div className="text-center mb-4">
                    <div className="text-sm font-semibold text-green-400 mb-2">With M</div>
                    <div className="text-4xl font-bold text-green-400" data-testid="text-m-time">
                      {currentRoleConfig.demoStory.vexorTime.split(' ')[0]} {currentRoleConfig.demoStory.vexorTime.split(' ')[1] || ''}
                    </div>
                  </div>
                  <div className="space-y-3 text-sm text-gray-200">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Parallel execution</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Pre-built playbooks activate</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Instant team coordination</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>AI-monitored execution</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Execution Visualization */}
            <Card className="bg-gradient-to-br from-slate-800/90 to-blue-900/40 border-blue-500/30 mb-8">
              <CardContent className="p-10">
                <h3 className="text-2xl font-bold text-center mb-8">How It Works</h3>
                <div className="grid grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="bg-blue-500/20 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 border-2 border-blue-500">
                      <span className="text-3xl">⚡</span>
                    </div>
                    <div className="font-semibold text-lg mb-2">1. AI Detects</div>
                    <div className="text-sm text-gray-400">24/7 monitoring triggers instant alert</div>
                  </div>
                  <div className="text-center">
                    <div className="bg-purple-500/20 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 border-2 border-purple-500">
                      <span className="text-3xl">🚀</span>
                    </div>
                    <div className="font-semibold text-lg mb-2">2. Playbook Activates</div>
                    <div className="text-sm text-gray-400">Pre-built response coordinates all teams</div>
                  </div>
                  <div className="text-center">
                    <div className="bg-green-500/20 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 border-2 border-green-500">
                      <span className="text-3xl">✅</span>
                    </div>
                    <div className="font-semibold text-lg mb-2">3. Executed</div>
                    <div className="text-sm text-gray-400">All stakeholders aligned and acting</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Impact */}
            <Card className="bg-gradient-to-br from-green-900/40 to-blue-900/30 border-2 border-green-500/50 mb-8">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-4 text-green-300">The Impact</h3>
                <p className="text-xl text-gray-200" data-testid="text-demo-impact">
                  {currentRoleConfig.demoStory.impact}
                </p>
              </CardContent>
            </Card>

            <div className="text-center">
              <Button
                onClick={showResults}
                size="lg"
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 text-lg"
                data-testid="button-view-results"
              >
                See Full Results
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        )}

        {/* Phase: Results */}
        {currentPhase === 'results' && currentRoleConfig && (
          <div className="max-w-4xl mx-auto">
            <Card className="bg-gradient-to-br from-green-900/50 to-blue-900/50 border-2 border-green-500">
              <CardContent className="p-12">
                <div className="text-center mb-8">
                  <div className="text-6xl mb-4">🏆</div>
                  <h2 className="text-4xl font-bold mb-4" data-testid="heading-results">
                    Championship-Level Execution
                  </h2>
                  <p className="text-xl text-green-300">
                    Built by reverse-engineering NFL coaching decision-making
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-slate-800/50 rounded-lg p-6">
                    <div className="text-sm font-semibold text-gray-400 mb-2">Traditional Approach</div>
                    <div className="text-3xl font-bold text-red-400">Weeks</div>
                    <div className="text-sm text-gray-300 mt-2">Sequential coordination, email chains, meeting delays</div>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-6 border-2 border-green-500">
                    <div className="text-sm font-semibold text-gray-400 mb-2">With M</div>
                    <div className="text-3xl font-bold text-green-400">12 Minutes</div>
                    <div className="text-sm text-gray-300 mt-2">AI-powered triggers, one-click playbooks, instant coordination</div>
                  </div>
                </div>

                <div className="bg-blue-500/10 border-l-4 border-blue-500 p-6 rounded-r-lg mb-8">
                  <p className="text-lg font-semibold mb-2">The NFL Foundation + Dynamic Strategy Validation</p>
                  <p className="text-gray-300">
                    We studied how coaches make 80+ decisions per game in 40 seconds. Then we discovered Microsoft, DBS Bank, and Amazon independently built the same system through Dynamic Strategy methodology. <strong>You get both in 90 days.</strong>
                  </p>
                </div>

                <div className="text-center space-y-4">
                  <Button
                    onClick={() => setCurrentPhase('lead-capture')}
                    size="lg"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 mb-4"
                    data-testid="button-learn-more"
                  >
                    I Want This for My Organization
                    <ChevronRight className="ml-2 h-5 w-5" />
                  </Button>
                  <div>
                    <Button
                      onClick={resetDemo}
                      variant="outline"
                      size="sm"
                      data-testid="button-another-role"
                    >
                      Show Another Role
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Phase: Lead Capture */}
        {currentPhase === 'lead-capture' && (
          <div className="max-w-md mx-auto">
            <Card className="bg-slate-800/90 border-blue-500">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-6 text-center" data-testid="heading-lead-capture">
                  Let's Connect
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Name</label>
                    <input
                      type="text"
                      value={leadData.name}
                      onChange={(e) => setLeadData({ ...leadData, name: e.target.value })}
                      className="w-full bg-slate-700 border border-slate-600 rounded px-4 py-2"
                      data-testid="input-name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Email</label>
                    <input
                      type="email"
                      value={leadData.email}
                      onChange={(e) => setLeadData({ ...leadData, email: e.target.value })}
                      className="w-full bg-slate-700 border border-slate-600 rounded px-4 py-2"
                      data-testid="input-email"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Company</label>
                    <input
                      type="text"
                      value={leadData.company}
                      onChange={(e) => setLeadData({ ...leadData, company: e.target.value })}
                      className="w-full bg-slate-700 border border-slate-600 rounded px-4 py-2"
                      data-testid="input-company"
                    />
                  </div>
                  <Button
                    onClick={() => window.location.href = '/contact'}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-lg py-6"
                    data-testid="button-request-early-access"
                  >
                    Request Early Access Interview
                  </Button>
                  <div className="border-t border-slate-600 pt-4 mt-4 space-y-2">
                    <p className="text-sm text-slate-400 text-center mb-2">Continue Exploring:</p>
                    <Button
                      onClick={() => window.location.href = '/business-scenarios'}
                      variant="outline"
                      className="w-full"
                      data-testid="button-explore-scenarios"
                    >
                      View 148 Playbooks
                    </Button>
                    <Button
                      onClick={() => window.location.href = '/'}
                      variant="outline"
                      className="w-full"
                      data-testid="button-return-home"
                    >
                      Return Home
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
