import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  DollarSign,
  TrendingDown,
  Users,
  Zap,
  Target,
  Trophy
} from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { updatePageMetadata } from "@/lib/seo";
import StandardNav from "@/components/layout/StandardNav";
import ExecutionTimelineDemo from "@/components/demo/ExecutionTimelineDemo";
import InteractiveROICalculator from "@/components/demo/InteractiveROICalculator";
import PlaybookLibraryDemo from "@/components/demo/PlaybookLibraryDemo";
import PracticeDrillsDemo from "@/components/demo/PracticeDrillsDemo";

export default function Demo() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    updatePageMetadata({
      title: "Live Demo - See M in Action | 12-Minute Execution",
      description: "Experience how M transforms a 72-hour competitive response into 12 minutes of coordinated execution. See the complete workflow: Scenario → Triggers → Execution Plan → Results.",
      ogTitle: "M Live Demo - 12-Minute Strategic Execution",
      ogDescription: "Walk through a real competitive response scenario showing strategic playbook execution with triggers, phases, and coordinated stakeholder actions.",
    });
  }, []);

  return (
    <div className="page-background min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      <StandardNav />

      {/* Hero - Demo Introduction */}
      <section className="py-20 px-6 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
        <div className="max-w-5xl mx-auto text-center">
          <Badge className="mb-6 bg-cyan-500 text-white border-0 text-lg px-6 py-2" data-testid="badge-live-demo">
            Live Demo Experience
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-white" data-testid="heading-demo">
            See M in Action
          </h1>
          <p className="text-2xl text-blue-100 mb-4">
            Watch how M transforms a 72-hour competitive response into 12 minutes of coordinated execution
          </p>
          <p className="text-lg text-blue-200 max-w-3xl mx-auto mb-8">
            This demo walks you through the complete M workflow: <span className="text-cyan-400 font-semibold">Scenario → Triggers → Execution Plan → Results</span>
          </p>
          
          <div className="grid md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <Card className="bg-white/10 border-cyan-500/30">
              <CardContent className="p-4 text-center">
                <div className="text-3xl font-bold text-cyan-400 mb-1">1</div>
                <div className="text-sm text-blue-100">The Situation</div>
              </CardContent>
            </Card>
            <Card className="bg-white/10 border-cyan-500/30">
              <CardContent className="p-4 text-center">
                <div className="text-3xl font-bold text-cyan-400 mb-1">2</div>
                <div className="text-sm text-blue-100">Triggers Fire</div>
              </CardContent>
            </Card>
            <Card className="bg-white/10 border-cyan-500/30">
              <CardContent className="p-4 text-center">
                <div className="text-3xl font-bold text-cyan-400 mb-1">3</div>
                <div className="text-sm text-blue-100">12-Min Execution</div>
              </CardContent>
            </Card>
            <Card className="bg-white/10 border-cyan-500/30">
              <CardContent className="p-4 text-center">
                <div className="text-3xl font-bold text-cyan-400 mb-1">4</div>
                <div className="text-sm text-blue-100">Results & Learning</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Step 1: The Situation */}
      <section className="py-20 px-6 bg-white dark:bg-slate-900">
        <div className="max-w-5xl mx-auto">
          <div className="mb-12 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 dark:bg-red-900 mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-400" />
            </div>
            <Badge className="mb-4 bg-red-600 text-white">Step 1: The Situation</Badge>
            <h2 className="text-4xl font-bold mb-4 text-slate-900 dark:text-white">
              Competitive Threat Emerges
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400">
              Monday, 9:15 AM - Your main competitor just launched an aggressive pricing move
            </p>
          </div>

          <Card className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/30 dark:to-orange-950/30 border-2 border-red-200 dark:border-red-800" data-testid="card-situation">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                    <TrendingDown className="w-6 h-6 text-red-600" />
                    The Situation
                  </h3>
                  <div className="space-y-3 text-slate-700 dark:text-slate-300">
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <span className="font-semibold">Competitor announces 15% price cut</span> across their enterprise platform
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <span className="font-semibold">Social media erupts</span> with customer reactions and comparisons
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <span className="font-semibold">Sales team reports</span> 12 deals now at risk
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <span className="font-semibold">Customer sentiment drops</span> to -0.35 (critical threshold)
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                    <Clock className="w-6 h-6 text-orange-600" />
                    Traditional Response Time
                  </h3>
                  <div className="bg-white dark:bg-slate-800 rounded-lg p-6 mb-4">
                    <div className="text-5xl font-bold text-red-600 mb-2">72 Hours</div>
                    <div className="text-sm text-slate-600 dark:text-slate-400 mb-4">Industry standard coordination time</div>
                    <div className="space-y-2 text-sm text-slate-700 dark:text-slate-300">
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-slate-400 rounded-full"></div>
                        <span>Day 1: Emergency meetings scheduled</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-slate-400 rounded-full"></div>
                        <span>Day 2: Analysis & proposals circulate</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-slate-400 rounded-full"></div>
                        <span>Day 3: Finally coordinate response</span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-red-100 dark:bg-red-900/30 rounded-lg p-4 border border-red-300 dark:border-red-700">
                    <p className="text-sm text-red-800 dark:text-red-200 font-semibold">
                      ⚠️ By then: 87% chance you've missed the execution window
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Step 2: Triggers Activate */}
      <section className="py-20 px-6 bg-slate-100 dark:bg-slate-800">
        <div className="max-w-5xl mx-auto">
          <div className="mb-12 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-orange-100 dark:bg-orange-900 mb-4">
              <Zap className="w-8 h-8 text-orange-600 dark:text-orange-400" />
            </div>
            <Badge className="mb-4 bg-orange-600 text-white">Step 2: Triggers Activate</Badge>
            <h2 className="text-4xl font-bold mb-4 text-slate-900 dark:text-white">
              M Detects the Threat Instantly
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400">
              Pre-configured triggers automatically activate your competitive response playbook
            </p>
          </div>

          <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 dark:from-orange-950/30 dark:to-yellow-950/30 border-2 border-orange-200 dark:border-orange-800" data-testid="card-triggers">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">
                Trigger Conditions Met (9:15:34 AM)
              </h3>
              
              <div className="space-y-4 mb-8">
                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border-l-4 border-orange-500">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-semibold text-slate-900 dark:text-white">Competitor Pricing Alert</div>
                    <Badge className="bg-orange-600 text-white">TRIGGERED</Badge>
                  </div>
                  <div className="text-sm text-slate-600 dark:text-slate-400 font-mono">
                    IF competitor_pricing {'<'} our_pricing * 0.85
                  </div>
                  <div className="text-sm text-slate-700 dark:text-slate-300 mt-2">
                    ✓ Competitor price: <span className="font-semibold">$42.50</span> (was $50.00) | Our price: <span className="font-semibold">$50.00</span> | <span className="text-orange-600 font-semibold">15% gap detected</span>
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border-l-4 border-orange-500">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-semibold text-slate-900 dark:text-white">Social Sentiment Alert</div>
                    <Badge className="bg-orange-600 text-white">TRIGGERED</Badge>
                  </div>
                  <div className="text-sm text-slate-600 dark:text-slate-400 font-mono">
                    IF social_sentiment {'<'} -0.3 AND mention_volume {'>'} 100/hour
                  </div>
                  <div className="text-sm text-slate-700 dark:text-slate-300 mt-2">
                    ✓ Sentiment score: <span className="font-semibold text-red-600">-0.35</span> | Mentions: <span className="font-semibold">247/hour</span> | <span className="text-orange-600 font-semibold">Critical threshold crossed</span>
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border-l-4 border-orange-500">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-semibold text-slate-900 dark:text-white">Deal Risk Alert</div>
                    <Badge className="bg-orange-600 text-white">TRIGGERED</Badge>
                  </div>
                  <div className="text-sm text-slate-600 dark:text-slate-400 font-mono">
                    IF at_risk_deals {'>'} 10 AND total_deal_value {'>'} $1M
                  </div>
                  <div className="text-sm text-slate-700 dark:text-slate-300 mt-2">
                    ✓ At-risk deals: <span className="font-semibold">12</span> | Value: <span className="font-semibold">$2.4M</span> | <span className="text-orange-600 font-semibold">Immediate action required</span>
                  </div>
                </div>
              </div>

              <div className="bg-green-100 dark:bg-green-900/30 rounded-lg p-6 border-2 border-green-500">
                <div className="flex items-center gap-3 mb-3">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  <div className="text-lg font-bold text-slate-900 dark:text-white">
                    Playbook Activated: Competitive Response
                  </div>
                </div>
                <div className="text-sm text-slate-700 dark:text-slate-300">
                  All 3 trigger conditions met. Execution plan now deploying to stakeholders across CFO, Legal, Operations, Product, Communications, and Sales teams.
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Step 3: 12-Minute Execution */}
      <section className="py-20 px-6 bg-white dark:bg-slate-900">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 dark:bg-green-900 mb-4">
              <Target className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
            <Badge className="mb-4 bg-green-600 text-white">Step 3: Coordinated Execution</Badge>
            <h2 className="text-4xl font-bold mb-4 text-slate-900 dark:text-white">
              12-Minute Response: Complete Playbook
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 mb-8">
              Watch every stakeholder receive coordinated assignments in real-time. No meetings. No delays. Just execution.
            </p>
          </div>

          {/* Execution Timeline Component */}
          <ExecutionTimelineDemo planType="competitive_response" />

          {/* ROI Comparison */}
          <div className="mt-16">
            <InteractiveROICalculator persona="general" industry="general" />
          </div>

          {/* Playbook Library Demo */}
          <div className="mt-16">
            <PlaybookLibraryDemo />
          </div>

          {/* Practice Drills Demo */}
          <div className="mt-16">
            <PracticeDrillsDemo />
          </div>
        </div>
      </section>

      {/* Step 4: Results & Learning */}
      <section className="py-20 px-6 bg-slate-100 dark:bg-slate-800">
        <div className="max-w-5xl mx-auto">
          <div className="mb-12 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-900 mb-4">
              <Trophy className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            </div>
            <Badge className="mb-4 bg-blue-600 text-white">Step 4: Results & Learning</Badge>
            <h2 className="text-4xl font-bold mb-4 text-slate-900 dark:text-white">
              Execution Complete: Outcomes Captured
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400">
              Every execution builds institutional memory—your organization gets smarter with each response
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 border-2 border-green-200 dark:border-green-800" data-testid="card-results">
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  What Happened
                </h3>
                <div className="space-y-3 text-slate-700 dark:text-slate-300">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div>
                      <span className="font-semibold">CFO validated budget:</span> $2.1M approved for competitive pricing match (2 minutes)
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div>
                      <span className="font-semibold">Legal cleared approach:</span> No regulatory blocks, safe to proceed (2 minutes)
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div>
                      <span className="font-semibold">Operations deployed:</span> Pricing adjustment live across all systems (4 minutes)
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div>
                      <span className="font-semibold">Product activated:</span> Premium features bundled to differentiate (3 minutes)
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div>
                      <span className="font-semibold">Communications notified:</span> All stakeholders informed simultaneously (1 minute)
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div>
                      <span className="font-semibold">Sales updated:</span> New messaging deployed to entire team (1 minute)
                    </div>
                  </div>
                </div>
                <div className="mt-6 pt-6 border-t border-green-200 dark:border-green-800">
                  <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-1">12:03</div>
                  <div className="text-sm text-slate-600 dark:text-slate-400">Total execution time (including buffer)</div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/30 dark:to-pink-950/30 border-2 border-purple-200 dark:border-purple-800" data-testid="card-learning">
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                  <Users className="w-6 h-6 text-purple-600" />
                  What We Learned
                </h3>
                <div className="space-y-4 text-slate-700 dark:text-slate-300">
                  <div className="bg-white dark:bg-slate-800 rounded p-3">
                    <div className="font-semibold text-sm text-purple-600 dark:text-purple-400 mb-1">Timing Insight</div>
                    <div className="text-sm">CFO validation took 2:15 instead of estimated 2:00. Update SLA for future executions.</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 rounded p-3">
                    <div className="font-semibold text-sm text-purple-600 dark:text-purple-400 mb-1">Bottleneck Identified</div>
                    <div className="text-sm">Operations deployment faster than expected (2:45 vs 3:00). Team automation paying off.</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 rounded p-3">
                    <div className="font-semibold text-sm text-purple-600 dark:text-purple-400 mb-1">Dependency Learning</div>
                    <div className="text-sm">Communications can start 30 seconds earlier if we parallelize with Product activation.</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 rounded p-3">
                    <div className="font-semibold text-sm text-purple-600 dark:text-purple-400 mb-1">Playbook Refinement</div>
                    <div className="text-sm">Add pre-approval for pricing adjustments under $2.5M to shave 1 minute off CFO validation.</div>
                  </div>
                </div>
                <div className="mt-6 pt-6 border-t border-purple-200 dark:border-purple-800">
                  <div className="flex items-center gap-2 text-sm text-purple-600 dark:text-purple-400 font-semibold">
                    <CheckCircle2 className="w-4 h-4" />
                    Playbook automatically updated for next execution
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-3xl font-bold mb-4">
                This Is Executive Decision Operations
              </h3>
              <p className="text-xl text-blue-100 mb-6 max-w-3xl mx-auto">
                Elite executives prepare for every strategic situation. M brings that same preparation-driven confidence to your enterprise. Build playbooks once. Trigger automatically. Execute in 12 minutes. Learn systematically.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  onClick={() => setLocation("/contact")}
                  className="bg-white text-blue-600 hover:bg-blue-50 text-lg px-10 py-6"
                  data-testid="button-request-access"
                >
                  Request Early Access <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button 
                  size="lg" 
                  onClick={() => setLocation("/business-scenarios")}
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/10 text-lg px-10 py-6"
                  data-testid="button-explore-scenarios"
                >
                  Explore 148 Playbooks
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
