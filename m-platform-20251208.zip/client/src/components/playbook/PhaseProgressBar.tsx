import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Circle, AlertCircle } from 'lucide-react';

interface PhaseProgressBarProps {
  prepareScore: number;
  monitorScore: number;
  executeScore: number;
  learnScore: number;
  currentPhase?: 'prepare' | 'monitor' | 'execute' | 'learn';
  compact?: boolean;
}

export function PhaseProgressBar({
  prepareScore,
  monitorScore,
  executeScore,
  learnScore,
  currentPhase,
  compact = false
}: PhaseProgressBarProps) {
  const phases = [
    { id: 'prepare', name: 'Prepare', score: prepareScore, color: 'bg-purple-500', icon: '🎯' },
    { id: 'monitor', name: 'Monitor', score: monitorScore, color: 'bg-blue-500', icon: '📡' },
    { id: 'execute', name: 'Execute', score: executeScore, color: 'bg-orange-500', icon: '⚡' },
    { id: 'learn', name: 'Learn', score: learnScore, color: 'bg-green-500', icon: '📚' },
  ];

  const overallScore = Math.round(
    (prepareScore * 0.4) + 
    (monitorScore * 0.2) + 
    (executeScore * 0.3) + 
    (learnScore * 0.1)
  );

  if (compact) {
    return (
      <div className="flex items-center gap-2" data-testid="phase-progress-compact">
        <Badge 
          variant={overallScore >= 80 ? 'default' : overallScore >= 50 ? 'secondary' : 'destructive'}
          className="text-xs"
          data-testid="readiness-badge"
        >
          {overallScore}% Ready
        </Badge>
        <div className="flex gap-1">
          {phases.map((phase) => (
            <div
              key={phase.id}
              className={`w-2 h-2 rounded-full ${
                phase.score === 100 
                  ? 'bg-green-500' 
                  : phase.score > 0 
                    ? 'bg-yellow-500' 
                    : 'bg-slate-600'
              }`}
              title={`${phase.name}: ${phase.score}%`}
              data-testid={`phase-dot-${phase.id}`}
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="phase-progress-full">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-slate-300">Playbook Readiness</span>
        <Badge 
          variant={overallScore >= 80 ? 'default' : overallScore >= 50 ? 'secondary' : 'destructive'}
          data-testid="overall-readiness-badge"
        >
          {overallScore}%
        </Badge>
      </div>
      
      <div className="grid grid-cols-4 gap-2">
        {phases.map((phase) => (
          <div 
            key={phase.id}
            className={`p-3 rounded-lg border transition-all ${
              currentPhase === phase.id 
                ? 'border-white bg-slate-800' 
                : 'border-slate-700 bg-slate-900/50'
            }`}
            data-testid={`phase-card-${phase.id}`}
          >
            <div className="flex items-center gap-2 mb-2">
              <span>{phase.icon}</span>
              <span className="text-xs font-medium text-slate-300">{phase.name}</span>
            </div>
            <Progress value={phase.score} className="h-1.5" />
            <div className="flex items-center justify-between mt-1">
              <span className="text-xs text-slate-500">{phase.score}%</span>
              {phase.score === 100 ? (
                <CheckCircle className="h-3 w-3 text-green-500" />
              ) : phase.score > 0 ? (
                <Circle className="h-3 w-3 text-yellow-500" />
              ) : (
                <AlertCircle className="h-3 w-3 text-red-500" />
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default PhaseProgressBar;
