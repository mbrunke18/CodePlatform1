import { Target, Radio, Zap, BookOpen } from 'lucide-react';
import { useLocation } from 'wouter';

interface PhaseIndicatorProps {
  scores?: {
    prepare: number;
    monitor: number;
    execute: number;
    learn: number;
  };
  compact?: boolean;
}

export default function GlobalPhaseIndicator({ 
  scores = { prepare: 0, monitor: 0, execute: 0, learn: 0 },
  compact = false 
}: PhaseIndicatorProps) {
  const [, setLocation] = useLocation();
  
  const phases = [
    { 
      id: 'prepare', 
      label: 'PREPARE', 
      icon: Target, 
      color: 'text-violet-400', 
      bgColor: 'bg-violet-500',
      score: scores.prepare,
      path: '/playbook-library'
    },
    { 
      id: 'monitor', 
      label: 'MONITOR', 
      icon: Radio, 
      color: 'text-cyan-400', 
      bgColor: 'bg-cyan-500',
      score: scores.monitor,
      path: '/foresight-radar'
    },
    { 
      id: 'execute', 
      label: 'EXECUTE', 
      icon: Zap, 
      color: 'text-emerald-400', 
      bgColor: 'bg-emerald-500',
      score: scores.execute,
      path: '/command-center'
    },
    { 
      id: 'learn', 
      label: 'LEARN', 
      icon: BookOpen, 
      color: 'text-amber-400', 
      bgColor: 'bg-amber-500',
      score: scores.learn,
      path: '/executive-dashboard'
    },
  ];

  if (compact) {
    return (
      <div className="flex items-center gap-1 text-xs" data-testid="phase-indicator-compact">
        {phases.map((phase, index) => {
          const Icon = phase.icon;
          return (
            <div key={phase.id} className="flex items-center">
              <button
                onClick={() => setLocation(phase.path)}
                className={`flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-800 transition-colors ${phase.color}`}
                title={`${phase.label}: ${phase.score}%`}
                data-testid={`phase-compact-${phase.id}`}
              >
                <Icon className="h-3 w-3" />
                <span className="hidden sm:inline">{phase.score}%</span>
              </button>
              {index < phases.length - 1 && (
                <span className="text-slate-600 mx-1">→</span>
              )}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4" data-testid="phase-indicator-full">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium text-slate-400">4-Phase Readiness</span>
        <span className="text-sm text-slate-500">
          Overall: {Math.round((scores.prepare + scores.monitor + scores.execute + scores.learn) / 4)}%
        </span>
      </div>
      <div className="flex items-center gap-2">
        {phases.map((phase, index) => {
          const Icon = phase.icon;
          return (
            <div key={phase.id} className="flex items-center flex-1">
              <button
                onClick={() => setLocation(phase.path)}
                className="flex-1 group"
                data-testid={`phase-full-${phase.id}`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Icon className={`h-4 w-4 ${phase.color}`} />
                  <span className={`text-xs font-medium ${phase.color}`}>{phase.label}</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${phase.bgColor} transition-all`}
                    style={{ width: `${phase.score}%` }}
                  />
                </div>
                <div className="text-xs text-slate-500 mt-1">{phase.score}%</div>
              </button>
              {index < phases.length - 1 && (
                <div className="text-slate-700 mx-2">→</div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
