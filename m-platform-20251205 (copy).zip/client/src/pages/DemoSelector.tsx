import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import StandardNav from '@/components/layout/StandardNav';
import { 
  Handshake,
  Rocket,
  PackageX,
  Shield,
  ArrowRight,
  Clock,
  Users,
  DollarSign,
  Sparkles,
  Swords,
  Scale,
  Heart,
  Play
} from 'lucide-react';

interface DemoCardProps {
  title: string;
  icon: React.ReactNode;
  audience: string;
  impact: string;
  path: string;
  duration: string;
  stakeholders: number;
  valueCreated: string;
}

function DemoCard({ title, icon, audience, impact, path, duration, stakeholders, valueCreated }: DemoCardProps) {
  const getDemoId = (title: string) => {
    return title.toLowerCase().replace(/\s+/g, '-');
  };
  
  return (
    <Link href={path}>
      <Card className="hover:shadow-xl hover:scale-[1.02] transition-all cursor-pointer h-full border-2 hover:border-primary/50" data-testid={`card-demo-${getDemoId(title)}`}>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                {icon}
              </div>
              <CardTitle className="text-xl" data-testid={`text-demo-title-${getDemoId(title)}`}>{title}</CardTitle>
            </div>
            <ArrowRight className="h-5 w-5 text-muted-foreground" />
          </div>
          <Badge variant="secondary" className="w-fit" data-testid={`badge-audience-${getDemoId(title)}`}>
            {audience}
          </Badge>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-xl font-bold text-primary" data-testid={`text-impact-${getDemoId(title)}`}>
            {impact}
          </div>
          
          <div className="grid grid-cols-3 gap-4 pt-4 border-t">
            <div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                <Clock className="h-4 w-4" />
                Duration
              </div>
              <div className="font-semibold" data-testid={`text-duration-${getDemoId(title)}`}>{duration}</div>
            </div>
            
            <div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                <Users className="h-4 w-4" />
                Stakeholders
              </div>
              <div className="font-semibold" data-testid={`text-stakeholders-${getDemoId(title)}`}>{stakeholders}</div>
            </div>
            
            <div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                <DollarSign className="h-4 w-4" />
                Value
              </div>
              <div className="font-semibold text-primary" data-testid={`text-value-${getDemoId(title)}`}>{valueCreated}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

const demos = [
  {
    title: 'Ransomware Response',
    icon: <Shield className="h-6 w-6 text-primary" />,
    audience: 'CISO, CIO, CTO',
    impact: '$22M crisis contained in 12 minutes',
    path: '/demo/live-activation',
    duration: '12 min',
    stakeholders: 47,
    valueCreated: '$22M+'
  },
  {
    title: 'M&A Integration',
    icon: <Handshake className="h-6 w-6 text-primary" />,
    audience: 'CEO, CFO, COO',
    impact: '$500M deal integration accelerated',
    path: '/demo/ma-integration',
    duration: '18 min',
    stakeholders: 89,
    valueCreated: '$500M+'
  },
  {
    title: 'Product Launch',
    icon: <Rocket className="h-6 w-6 text-primary" />,
    audience: 'CMO, CPO, CRO',
    impact: '15 countries coordinated in 11 minutes',
    path: '/demo/product-launch',
    duration: '11 min',
    stakeholders: 156,
    valueCreated: '$120M+'
  },
  {
    title: 'Supplier Crisis',
    icon: <PackageX className="h-6 w-6 text-primary" />,
    audience: 'COO, CPO, VP Supply Chain',
    impact: '$150M supply chain protected',
    path: '/demo/supplier-crisis',
    duration: '15 min',
    stakeholders: 34,
    valueCreated: '$150M+'
  },
  {
    title: 'Competitive Response',
    icon: <Swords className="h-6 w-6 text-primary" />,
    audience: 'CEO, CMO, VP Strategy',
    impact: '$300M market position defended',
    path: '/demo/competitive-response',
    duration: '14 min',
    stakeholders: 28,
    valueCreated: '$300M+'
  },
  {
    title: 'Regulatory Crisis',
    icon: <Scale className="h-6 w-6 text-primary" />,
    audience: 'GC, CCO, VP Compliance',
    impact: '$50M in penalties avoided',
    path: '/demo/regulatory-crisis',
    duration: '16 min',
    stakeholders: 52,
    valueCreated: '$50M+'
  },
  {
    title: 'Customer Crisis',
    icon: <Heart className="h-6 w-6 text-primary" />,
    audience: 'CRO, VP CS, CEO',
    impact: '$120M ARR saved',
    path: '/demo/customer-crisis',
    duration: '13 min',
    stakeholders: 41,
    valueCreated: '$120M+'
  }
];

export default function DemoSelector() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <StandardNav />
      
      <div className="container mx-auto px-6 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-6 px-4 py-2 inline-flex items-center">
            <Play className="w-4 h-4 mr-2" />
            LIVE DEMO EXPERIENCES
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Choose Your Demo Experience
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Select a scenario that matches your industry or role. Each demo shows how M coordinates complex strategic execution in <span className="text-primary font-semibold">12 minutes or less</span>.
          </p>
        </div>

        {/* Demo Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {demos.map((demo) => (
            <DemoCard key={demo.title} {...demo} />
          ))}
        </div>

        {/* Bottom CTA */}
        <Card className="p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to see M in action?</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Each demo is a fully interactive experience showing real strategic execution scenarios.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/industry-demos">
              <Button>
                <Sparkles className="mr-2 h-5 w-5" />
                View Industry Demos
              </Button>
            </Link>
            <Link href="/">
              <Button variant="outline">
                Explore Full Platform
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
