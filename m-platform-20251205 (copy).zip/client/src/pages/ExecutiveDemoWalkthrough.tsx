import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  ChevronRight,
  ChevronLeft,
  Play,
  Pause,
  CheckCircle2,
  Clock,
  TrendingUp,
  Shield,
  Zap,
  Target,
  Users,
  Brain,
  BarChart3,
  Lightbulb,
  Rocket
} from "lucide-react";
import { useLocation } from "wouter";
import StandardNav from "@/components/layout/StandardNav";
import { motion, AnimatePresence } from "framer-motion";

const demoSteps = [
  {
    id: 1,
    title: "The Strategic Challenge",
    subtitle: "Traditional Approach: 72-Hour Coordination",
    description: "Fortune 1000 companies face a critical execution gap. When market opportunities emerge or competitors make moves, coordinating strategic response across departments takes 72+ hours. By then, the opportunity is gone.",
    icon: Clock,
    color: "text-red-500",
    bgColor: "bg-red-500/10",
    metrics: [
      { label: "Average Coordination Time", value: "72 hours", trend: "negative" },
      { label: "Strategic Initiatives That Fail", value: "87%", trend: "negative" },
      { label: "Annual Cost of Delays", value: "$18.4M", trend: "negative" }
    ],
    action: null,
    image: "🚨"
  },
  {
    id: 2,
    title: "Strategic Preparation",
    subtitle: "Build Your Playbook Arsenal",
    description: "Start with 148 playbook templates across 8 strategic domains: Market Dynamics, Financial Strategy, Operational Excellence, Technology & Innovation, Talent & Leadership, Brand & Reputation, Regulatory & Compliance, and Market Opportunities. Use What-If Analyzer to test scenarios before execution. Practice with drills to achieve 94+ Preparedness Score.",
    icon: Shield,
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
    metrics: [
      { label: "Template Library", value: "148 playbooks", trend: "positive" },
      { label: "Preparedness Score", value: "94/100", trend: "positive" },
      { label: "Drill Completion", value: "87%", trend: "positive" }
    ],
    action: { label: "View Playbook Library", route: "/playbook-library" },
    image: "📚"
  },
  {
    id: 3,
    title: "AI Intelligence Layer",
    subtitle: "5 AI Modules Working 24/7",
    description: "Pulse Intelligence monitors 12 strategic signals. Flux Adaptations detects market shifts. Prism Insights reveals competitive patterns. Echo Cultural Analytics tracks organizational readiness. Nova Innovations identifies emerging opportunities. AI operates continuously, never sleeps.",
    icon: Brain,
    color: "text-purple-500",
    bgColor: "bg-purple-500/10",
    metrics: [
      { label: "AI Modules Active", value: "5 systems", trend: "positive" },
      { label: "Signals Monitored", value: "12 sources", trend: "positive" },
      { label: "AI Confidence Score", value: "92%", trend: "positive" }
    ],
    action: { label: "Explore AI Intelligence", route: "/ai-intelligence" },
    image: "🧠"
  },
  {
    id: 4,
    title: "24/7 Proactive Monitoring",
    subtitle: "AI Radar Never Sleeps",
    description: "AI Radar continuously scans market conditions, competitor moves, regulatory changes, and emerging risks. When patterns match your playbook triggers (92% confidence), system automatically recommends activation. You're always ready, never surprised.",
    icon: Target,
    color: "text-cyan-500",
    bgColor: "bg-cyan-500/10",
    metrics: [
      { label: "Active Triggers", value: "8 monitored", trend: "positive" },
      { label: "Early Warnings", value: "3.2 days avg", trend: "positive" },
      { label: "False Positives", value: "< 5%", trend: "positive" }
    ],
    action: { label: "See AI Radar Dashboard", route: "/ai-radar" },
    image: "🎯"
  },
  {
    id: 5,
    title: "One-Click Execution",
    subtitle: "Command Center Activation",
    description: "When AI recommends playbook activation, one click coordinates entire response. Stakeholders notified instantly. Tasks distributed automatically. Resources allocated in real-time. Board briefing generated. Full organizational coordination in minutes, not hours.",
    icon: Zap,
    color: "text-yellow-500",
    bgColor: "bg-yellow-500/10",
    metrics: [
      { label: "Activation Time", value: "12 minutes", trend: "positive" },
      { label: "Stakeholders Coordinated", value: "47 people", trend: "positive" },
      { label: "Task Completion", value: "94%", trend: "positive" }
    ],
    action: { label: "Try Command Center", route: "/command-center" },
    image: "⚡"
  },
  {
    id: 6,
    title: "Institutional Memory",
    subtitle: "Learn From Every Decision",
    description: "AI captures outcomes from every playbook execution. What worked? What didn't? How did competitors respond? System learns continuously, refining recommendations. Your strategic capability compounds over time.",
    icon: Lightbulb,
    color: "text-green-500",
    bgColor: "bg-green-500/10",
    metrics: [
      { label: "Decisions Captured", value: "1,247", trend: "positive" },
      { label: "Pattern Recognition", value: "89% accuracy", trend: "positive" },
      { label: "Playbook Refinement", value: "+34% effective", trend: "positive" }
    ],
    action: { label: "View Decision Outcomes", route: "/decision-outcomes" },
    image: "💡"
  },
  {
    id: 7,
    title: "Executive Intelligence",
    subtitle: "Trust & Proof Engine",
    description: "Board Deck Generator creates executive briefings in one click. ROI Dashboard shows $12.4M in cost savings, 342 hours recovered, 12-minute execution velocity. AI confidence scores (92%) provide transparency. Decision outcomes tracked with verifiable metrics.",
    icon: BarChart3,
    color: "text-indigo-500",
    bgColor: "bg-indigo-500/10",
    metrics: [
      { label: "Cost Savings Realized", value: "$12.4M", trend: "positive" },
      { label: "Time Recovered", value: "342 hours", trend: "positive" },
      { label: "Execution Velocity", value: "12 min avg", trend: "positive" }
    ],
    action: { label: "View Dashboard", route: "/dashboard" },
    image: "📊"
  },
  {
    id: 8,
    title: "The Result: Command Every Decision",
    subtitle: "72 Hours → 12 Minutes",
    description: "M transforms strategic execution from multi-week coordination cycles to 12-minute coordinated responses. Anticipate opportunities. Create advantages. Respond to competitors. Navigate challenges. All with the confidence of complete preparation and AI-powered intelligence.",
    icon: Rocket,
    color: "text-primary",
    bgColor: "bg-primary/10",
    metrics: [
      { label: "Execution Speed", value: "500x faster", trend: "positive" },
      { label: "Strategic Readiness", value: "Complete", trend: "positive" },
      { label: "Competitive Advantage", value: "Category-defining", trend: "positive" }
    ],
    action: { label: "Start Your Journey", route: "/dashboard" },
    image: "🚀"
  }
];

export default function ExecutiveDemoWalkthrough() {
  const [currentStep, setCurrentStep] = useState(0);
  const [, setLocation] = useLocation();
  const [autoPlay, setAutoPlay] = useState(false);
  const [countdown, setCountdown] = useState(8);

  const step = demoSteps[currentStep];
  const progress = ((currentStep + 1) / demoSteps.length) * 100;

  // Auto-play with countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (autoPlay && currentStep < demoSteps.length - 1) {
      setCountdown(8); // Reset countdown
      interval = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            const nextStep = currentStep + 1;
            setCurrentStep(nextStep);
            // Auto-pause when reaching the last step
            if (nextStep >= demoSteps.length - 1) {
              setAutoPlay(false);
            }
            return 8;
          }
          return prev - 1;
        });
      }, 1000); // Update every second
    } else {
      setCountdown(8);
    }
    return () => clearInterval(interval);
  }, [autoPlay, currentStep]);

  const nextStep = () => {
    if (currentStep < demoSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const StepIcon = step.icon;

  return (
    <div className="page-background min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      <StandardNav />
      <div className="page-background min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-950 dark:to-blue-950 py-12">
        <div className="max-w-7xl mx-auto px-6">
          {/* Header */}
          <div className="text-center mb-8">
            <Badge className="mb-4 bg-primary text-white border-0" data-testid="badge-demo-mode">
              Executive Demo Walkthrough
            </Badge>
            <h1 className="text-4xl font-bold mb-4 text-slate-900 dark:text-white" data-testid="heading-demo-title">
              Experience the Future of Strategic Execution
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto" data-testid="text-demo-subtitle">
              8-minute guided journey through M's complete 7-component ecosystem
            </p>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400" data-testid="text-progress-step">
                Step {currentStep + 1} of {demoSteps.length}
              </span>
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400" data-testid="text-progress-percent">
                {Math.round(progress)}% Complete
              </span>
            </div>
            <Progress value={progress} className="h-2" data-testid="progress-demo" />
          </div>

          {/* Main Content Card with Animations */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="mb-8 border-2 shadow-2xl overflow-hidden" data-testid={`card-step-${step.id}`}>
                <CardContent className="p-0">
                  {/* Step Header */}
                  <div className={`${step.bgColor} p-8 border-b`}>
                    <div className="flex items-center gap-4 mb-4">
                      <motion.div 
                        className={`${step.color} bg-white dark:bg-slate-800 p-4 rounded-lg shadow-lg`}
                        initial={{ scale: 0.8, rotate: -10 }}
                        animate={{ scale: 1, rotate: 0 }}
                        transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                      >
                        <StepIcon className="h-8 w-8" />
                      </motion.div>
                      <div className="flex-1 page-background">
                        <motion.div 
                          className="text-sm font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wide mb-1" 
                          data-testid={`text-step-${step.id}-subtitle`}
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.1 }}
                        >
                          {step.subtitle}
                        </motion.div>
                        <motion.h2 
                          className={`text-3xl font-bold ${step.color}`} 
                          data-testid={`heading-step-${step.id}-title`}
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.15 }}
                        >
                          {step.title}
                        </motion.h2>
                      </div>
                      <motion.div 
                        className="text-6xl" 
                        data-testid={`emoji-step-${step.id}`}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: 0.25, type: "spring", stiffness: 300 }}
                      >
                        {step.image}
                      </motion.div>
                    </div>
                  </div>

                  {/* Step Content */}
                  <div className="p-8">
                    <motion.p 
                      className="text-lg text-slate-700 dark:text-slate-300 mb-8 leading-relaxed" 
                      data-testid={`text-step-${step.id}-description`}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      {step.description}
                    </motion.p>

                    {/* Metrics Grid */}
                    <div className="grid md:grid-cols-3 gap-6 mb-8">
                      {step.metrics.map((metric, idx) => (
                        <motion.div 
                          key={idx} 
                          className="card-bg p-6 rounded-lg" 
                          data-testid={`metric-${step.id}-${idx}`}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.4 + idx * 0.1 }}
                        >
                          <div className="text-sm text-slate-600 dark:text-slate-400 mb-2" data-testid={`text-metric-${step.id}-${idx}-label`}>
                            {metric.label}
                          </div>
                          <div className={`text-3xl font-bold mb-2 ${metric.trend === 'positive' ? 'text-green-600' : 'text-red-600'}`} data-testid={`text-metric-${step.id}-${idx}-value`}>
                            {metric.value}
                          </div>
                          {metric.trend === 'positive' && (
                            <TrendingUp className="h-5 w-5 text-green-600" data-testid={`icon-trend-${step.id}-${idx}`} />
                          )}
                        </motion.div>
                      ))}
                    </div>

                    {/* Action Button */}
                    {step.action && (
                      <motion.div 
                        className="flex justify-center"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.7 }}
                      >
                        <Button
                          size="lg"
                          onClick={() => setLocation(step.action.route)}
                          className="bg-primary hover:bg-primary/90 text-white"
                          data-testid={`button-action-step-${step.id}`}
                        >
                          {step.action.label}
                          <ChevronRight className="ml-2 h-5 w-5" />
                        </Button>
                      </motion.div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Controls */}
          <div className="flex justify-between items-center">
            <Button
              variant="outline"
              onClick={prevStep}
              disabled={currentStep === 0}
              data-testid="button-prev-step"
            >
              <ChevronLeft className="mr-2 h-5 w-5" />
              Previous
            </Button>

            <div className="flex gap-2">
              <Button
                variant={autoPlay ? "destructive" : "outline"}
                onClick={() => setAutoPlay(!autoPlay)}
                data-testid="button-autoplay"
                className="relative"
              >
                {autoPlay ? <Pause className="mr-2 h-5 w-5" /> : <Play className="mr-2 h-5 w-5" />}
                {autoPlay ? (
                  <span className="flex items-center gap-2">
                    Next in {countdown}s
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                    </span>
                  </span>
                ) : "Auto-Play (8s)"}
              </Button>

              {/* Step Indicators */}
              <div className="hidden md:flex gap-2 items-center">
                {demoSteps.map((s, idx) => (
                  <button
                    key={s.id}
                    onClick={() => setCurrentStep(idx)}
                    className={`h-2 rounded-full transition-all ${
                      idx === currentStep 
                        ? 'w-8 bg-primary' 
                        : idx < currentStep
                        ? 'w-2 bg-green-500'
                        : 'w-2 bg-slate-300 dark:bg-slate-600'
                    }`}
                    data-testid={`indicator-step-${idx}`}
                  />
                ))}
              </div>
            </div>

            <Button
              onClick={nextStep}
              disabled={currentStep === demoSteps.length - 1}
              className="bg-primary hover:bg-primary/90 text-white"
              data-testid="button-next-step"
            >
              {currentStep === demoSteps.length - 1 ? (
                <>
                  <CheckCircle2 className="mr-2 h-5 w-5" />
                  Complete
                </>
              ) : (
                <>
                  Next
                  <ChevronRight className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>
          </div>

          {/* Key Takeaways */}
          {currentStep === demoSteps.length - 1 && (
            <Card className="mt-8 border-2 border-primary shadow-xl" data-testid="card-takeaways">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-6 text-center text-slate-900 dark:text-white" data-testid="heading-takeaways">
                  Key Takeaways: Why M is a Must-Have
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="flex items-start gap-3" data-testid="takeaway-1">
                    <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-white mb-1">Category-Defining Platform</div>
                      <div className="text-slate-600 dark:text-slate-400">First Strategic Execution Operating System (like Salesforce for CRM)</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3" data-testid="takeaway-2">
                    <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-white mb-1">500x Faster Execution</div>
                      <div className="text-slate-600 dark:text-slate-400">72 hours → 12 minutes coordinated response</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3" data-testid="takeaway-3">
                    <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-white mb-1">$12.4M+ Annual Value</div>
                      <div className="text-slate-600 dark:text-slate-400">Proven ROI with cost savings + time recovery</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3" data-testid="takeaway-4">
                    <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-white mb-1">Complete Ecosystem</div>
                      <div className="text-slate-600 dark:text-slate-400">7 integrated components, not fragmented point solutions</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
