import { useState, useEffect, useCallback, useRef } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Zap, 
  AlertTriangle, 
  TrendingDown, 
  Shield, 
  Clock, 
  CheckCircle2, 
  Target,
  Radio,
  Activity,
  ArrowRight,
  Sparkles,
  Eye,
  Bell,
  Users,
  Building2,
  DollarSign,
  FileText,
  ChevronRight,
  Timer,
  Rocket,
  BarChart3,
  LucideIcon
} from 'lucide-react';
import PageLayout from '@/components/layout/PageLayout';
import { useTimelineState, useTimelineOrchestrator } from '@/contexts/DemoTimelineContext';

type LucideIconType = typeof TrendingDown;

interface DemoScenario {
  id: string;
  name: string;
  description: string;
  icon: LucideIconType;
  color: string;
  signalCategory: string;
  triggerCondition: string;
  simulatedValue: string;
  impactMetrics: {
    revenueAtRisk: string;
    timeToRespond: string;
    competitiveAdvantage: string;
  };
  recommendedPlaybook: {
    id: string;
    name: string;
    actions: string[];
  };
  stakeholders: string[];
}

interface DemoAlert {
  id: string;
  scenarioId: string;
  title: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  timestamp: Date;
  source: string;
  acknowledged: boolean;
}

interface ExecutionTask {
  id: string;
  name: string;
  department: string;
  status: 'pending' | 'in_progress' | 'completed';
  duration: number;
}

const DEMO_SCENARIOS: DemoScenario[] = [
  {
    id: 'competitor-price-war',
    name: 'Competitor Price War',
    description: 'Major competitor announces 20% price reduction in core market segment',
    icon: TrendingDown,
    color: 'text-red-500',
    signalCategory: 'Competitive Movement',
    triggerCondition: 'Competitor price change > 15%',
    simulatedValue: '-20% price reduction by CompetitorX',
    impactMetrics: {
      revenueAtRisk: '$12.4M',
      timeToRespond: '72 hours → 12 minutes',
      competitiveAdvantage: '5-day head start'
    },
    recommendedPlaybook: {
      id: 'PB-COMP-001',
      name: 'Competitive Response Protocol',
      actions: [
        'Convene pricing committee',
        'Analyze margin impact scenarios',
        'Prepare customer retention messaging',
        'Draft sales team talking points',
        'Update competitive battle cards'
      ]
    },
    stakeholders: ['CFO', 'CMO', 'VP Sales', 'Pricing Team']
  },
  {
    id: 'supply-chain-disruption',
    name: 'Supply Chain Disruption',
    description: 'Critical supplier shows signs of financial distress affecting 35% of production capacity',
    icon: AlertTriangle,
    color: 'text-orange-500',
    signalCategory: 'Supply Chain Stress',
    triggerCondition: 'Supplier risk score > 75',
    simulatedValue: 'AcmeParts Inc. - Financial distress detected',
    impactMetrics: {
      revenueAtRisk: '$8.7M',
      timeToRespond: '48 hours → 12 minutes',
      competitiveAdvantage: '3-day procurement advantage'
    },
    recommendedPlaybook: {
      id: 'PB-SCM-001',
      name: 'Supplier Continuity Protocol',
      actions: [
        'Activate backup supplier network',
        'Assess inventory buffer status',
        'Notify production planning',
        'Prepare customer communication',
        'Initiate vendor qualification fast-track'
      ]
    },
    stakeholders: ['COO', 'VP Supply Chain', 'Procurement', 'Production']
  },
  {
    id: 'regulatory-change',
    name: 'Regulatory Alert',
    description: 'New compliance requirement announced affecting product line in key market',
    icon: Shield,
    color: 'text-purple-500',
    signalCategory: 'Regulatory Changes',
    triggerCondition: 'Regulatory impact score = High',
    simulatedValue: 'FDA guidance update - Product labeling requirements',
    impactMetrics: {
      revenueAtRisk: '$15.2M',
      timeToRespond: '2 weeks → 12 minutes',
      competitiveAdvantage: 'First-mover compliance'
    },
    recommendedPlaybook: {
      id: 'PB-REG-001',
      name: 'Regulatory Response Protocol',
      actions: [
        'Legal team impact assessment',
        'Product team compliance gap analysis',
        'Timeline and resource planning',
        'Stakeholder communication plan',
        'Customer advisory preparation'
      ]
    },
    stakeholders: ['General Counsel', 'VP Regulatory', 'Product Management', 'Marketing']
  },
  {
    id: 'market-opportunity',
    name: 'Market Opportunity',
    description: 'Competitor exits key market segment creating $50M addressable opportunity',
    icon: Rocket,
    color: 'text-green-500',
    signalCategory: 'Market Dynamics',
    triggerCondition: 'Competitor market exit detected',
    simulatedValue: 'RivalCorp announces EMEA market withdrawal',
    impactMetrics: {
      revenueAtRisk: '+$50M opportunity',
      timeToRespond: '1 week → 12 minutes',
      competitiveAdvantage: '10-day market capture window'
    },
    recommendedPlaybook: {
      id: 'PB-MKT-001',
      name: 'Market Capture Protocol',
      actions: [
        'Sales team rapid deployment',
        'Customer outreach campaign launch',
        'Competitive positioning update',
        'Channel partner notification',
        'Press release preparation'
      ]
    },
    stakeholders: ['CEO', 'CMO', 'VP Sales', 'Channel Partners']
  }
];

export default function IntelligenceSignalsDemo() {
  const [, setLocation] = useLocation();
  const timelineState = useTimelineState();
  const orchestrator = useTimelineOrchestrator();
  const [activeScenario, setActiveScenario] = useState<DemoScenario | null>(null);
  const [demoPhase, setDemoPhase] = useState<'intro' | 'detection' | 'alert' | 'playbook' | 'execution' | 'complete'>('intro');
  const [isRunning, setIsRunning] = useState(false);
  const [alerts, setAlerts] = useState<DemoAlert[]>([]);
  const [executionTasks, setExecutionTasks] = useState<ExecutionTask[]>([]);
  const [autoAdvance, setAutoAdvance] = useState(true);

  const executionTime = timelineState.elapsedMs;

  const resetDemo = useCallback(() => {
    setActiveScenario(null);
    setDemoPhase('intro');
    setIsRunning(false);
    setAlerts([]);
    setExecutionTasks([]);
    
    orchestrator.resetAll();
  }, [orchestrator]);

  const startScenario = useCallback((scenario: DemoScenario) => {
    setActiveScenario(scenario);
    setDemoPhase('detection');
    setIsRunning(true);
    setAlerts([]);
    setExecutionTasks([]);
    
    orchestrator.startOnce({ duration: 720000, speedMultiplier: 20 });
  }, [orchestrator]);

  const fireAlert = useCallback(() => {
    if (!activeScenario) return;

    const newAlert: DemoAlert = {
      id: `alert-${Date.now()}`,
      scenarioId: activeScenario.id,
      title: activeScenario.name,
      severity: 'critical',
      timestamp: new Date(),
      source: activeScenario.signalCategory,
      acknowledged: false
    };

    setAlerts([newAlert]);
    setDemoPhase('alert');

    if (autoAdvance) {
      setTimeout(() => setDemoPhase('playbook'), 3000);
    }
  }, [activeScenario, autoAdvance]);

  const activatePlaybook = useCallback(() => {
    if (!activeScenario) return;

    const tasks: ExecutionTask[] = activeScenario.recommendedPlaybook.actions.map((action, index) => ({
      id: `task-${index}`,
      name: action,
      department: activeScenario.stakeholders[index % activeScenario.stakeholders.length],
      status: 'pending',
      duration: 1500 + Math.random() * 2000
    }));

    setExecutionTasks(tasks);
    setDemoPhase('execution');
  }, [activeScenario]);


  useEffect(() => {
    if (demoPhase === 'detection' && isRunning && autoAdvance) {
      const timer = setTimeout(fireAlert, 2000);
      return () => clearTimeout(timer);
    }
  }, [demoPhase, isRunning, autoAdvance, fireAlert]);

  useEffect(() => {
    if (demoPhase !== 'execution' || executionTasks.length === 0) return;

    const timeoutIds: NodeJS.Timeout[] = [];

    const completeTask = (index: number) => {
      setExecutionTasks(prev => prev.map((task, i) => 
        i === index ? { ...task, status: 'completed' } : task
      ));
    };

    const startTask = (index: number) => {
      setExecutionTasks(prev => prev.map((task, i) => 
        i === index ? { ...task, status: 'in_progress' } : task
      ));
    };

    executionTasks.forEach((task, index) => {
      if (task.status === 'pending') {
        const startDelay = index * 800;
        const completeDelay = startDelay + task.duration;

        const startTimer = setTimeout(() => startTask(index), startDelay);
        const completeTimer = setTimeout(() => completeTask(index), completeDelay);
        timeoutIds.push(startTimer, completeTimer);
      }
    });

    const totalDuration = executionTasks.length * 800 + 2000;
    const finalTimer = setTimeout(() => {
      setDemoPhase('complete');
      setIsRunning(false);
    }, totalDuration);
    timeoutIds.push(finalTimer);

    return () => {
      timeoutIds.forEach(id => clearTimeout(id));
    };
  }, [demoPhase, executionTasks]);

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const tenths = Math.floor((ms % 1000) / 100);
    return `${minutes}:${seconds.toString().padStart(2, '0')}.${tenths}`;
  };

  const completedTasks = executionTasks.filter(t => t.status === 'completed').length;
  const progressPercent = executionTasks.length > 0 
    ? (completedTasks / executionTasks.length) * 100 
    : 0;

  return (
    <PageLayout>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-teal-500 rounded-lg flex items-center justify-center">
                  <Radio className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-teal-500 bg-clip-text text-transparent">
                  Intelligence Signals Demo
                </h1>
                <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                  Interactive
                </Badge>
              </div>
              <p className="text-muted-foreground">
                Experience how M detects strategic signals and coordinates 12-minute responses
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>Auto-advance</span>
                <Switch 
                  checked={autoAdvance} 
                  onCheckedChange={setAutoAdvance}
                  data-testid="switch-auto-advance"
                />
              </div>
              <Button 
                variant="outline" 
                onClick={resetDemo}
                data-testid="button-reset-demo"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset Demo
              </Button>
              <Button 
                variant="outline"
                onClick={() => setLocation('/foresight-radar')}
                data-testid="button-go-to-platform"
              >
                Go to Platform
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>

          {/* Execution Timer - Always visible when running */}
          {isRunning && (
            <Card className="mb-6 border-2 border-blue-500/50 bg-gradient-to-r from-blue-50 to-teal-50 dark:from-blue-950/30 dark:to-teal-950/30">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center animate-pulse">
                      <Timer className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">M Execution Clock</div>
                      <div className="text-3xl font-mono font-bold text-blue-600 dark:text-blue-400">
                        {formatTime(executionTime)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-8">
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground">Traditional Response</div>
                      <div className="text-xl font-bold text-red-500">72 hours</div>
                    </div>
                    <div className="text-4xl text-muted-foreground">→</div>
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground">M Response</div>
                      <div className="text-xl font-bold text-green-500">12 minutes</div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-sm text-muted-foreground">Time Saved</div>
                    <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                      71h 48m
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left Column - Scenario Selection or Active Scenario */}
            <div className="lg:col-span-1">
              {demoPhase === 'intro' ? (
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-amber-500" />
                      Choose a Scenario
                    </CardTitle>
                    <CardDescription>
                      Select a strategic scenario to see M in action
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {DEMO_SCENARIOS.map((scenario) => (
                      <Button
                        key={scenario.id}
                        variant="outline"
                        className="w-full justify-start h-auto py-4 hover:border-blue-500 transition-all"
                        onClick={() => startScenario(scenario)}
                        data-testid={`button-scenario-${scenario.id}`}
                      >
                        <div className="flex items-start gap-3 text-left">
                          <div className={`p-2 rounded-lg bg-slate-100 dark:bg-slate-800 ${scenario.color}`}>
                            <scenario.icon className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="font-semibold">{scenario.name}</div>
                            <div className="text-xs text-muted-foreground line-clamp-2">
                              {scenario.description}
                            </div>
                          </div>
                        </div>
                      </Button>
                    ))}
                  </CardContent>
                </Card>
              ) : (
                <Card className="h-full">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs">
                        Active Scenario
                      </Badge>
                      <Badge 
                        className={
                          demoPhase === 'complete' 
                            ? 'bg-green-500' 
                            : demoPhase === 'execution' 
                              ? 'bg-blue-500 animate-pulse' 
                              : 'bg-amber-500 animate-pulse'
                        }
                      >
                        {demoPhase === 'detection' && 'Detecting...'}
                        {demoPhase === 'alert' && 'Alert Fired!'}
                        {demoPhase === 'playbook' && 'Playbook Ready'}
                        {demoPhase === 'execution' && 'Executing...'}
                        {demoPhase === 'complete' && 'Complete!'}
                      </Badge>
                    </div>
                    <CardTitle className="flex items-center gap-2 mt-3">
                      {activeScenario && (
                        <>
                          <activeScenario.icon className={`w-5 h-5 ${activeScenario.color}`} />
                          {activeScenario.name}
                        </>
                      )}
                    </CardTitle>
                    <CardDescription>
                      {activeScenario?.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="text-sm font-medium mb-2">Signal Category</div>
                      <Badge variant="secondary">{activeScenario?.signalCategory}</Badge>
                    </div>
                    
                    <div>
                      <div className="text-sm font-medium mb-2">Trigger Condition</div>
                      <div className="text-sm text-muted-foreground bg-slate-100 dark:bg-slate-800 p-2 rounded-lg font-mono">
                        {activeScenario?.triggerCondition}
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <div className="text-sm font-medium mb-3">Impact Metrics</div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Revenue at Risk</span>
                          <span className="font-semibold text-red-500">{activeScenario?.impactMetrics.revenueAtRisk}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Response Time</span>
                          <span className="font-semibold text-green-500">{activeScenario?.impactMetrics.timeToRespond}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Advantage</span>
                          <span className="font-semibold text-blue-500">{activeScenario?.impactMetrics.competitiveAdvantage}</span>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <div className="text-sm font-medium mb-2">Stakeholders</div>
                      <div className="flex flex-wrap gap-2">
                        {activeScenario?.stakeholders.map((stakeholder) => (
                          <Badge key={stakeholder} variant="outline" className="text-xs">
                            {stakeholder}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      variant="outline" 
                      className="w-full" 
                      onClick={resetDemo}
                      data-testid="button-try-another"
                    >
                      Try Another Scenario
                    </Button>
                  </CardFooter>
                </Card>
              )}
            </div>
            
            {/* Center & Right Columns - Demo Flow */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Intro State */}
              {demoPhase === 'intro' && (
                <Card className="border-dashed border-2">
                  <CardContent className="py-16">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-teal-100 dark:from-blue-900/30 dark:to-teal-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
                        <Play className="w-10 h-10 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">Select a Scenario to Begin</h3>
                      <p className="text-muted-foreground max-w-md mx-auto">
                        Choose from four strategic scenarios to experience M's intelligence signals 
                        and 12-minute coordinated response in action.
                      </p>
                      
                      <div className="grid grid-cols-4 gap-4 mt-8 max-w-lg mx-auto">
                        <div className="text-center">
                          <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mx-auto mb-2">
                            <Eye className="w-6 h-6 text-blue-600" />
                          </div>
                          <div className="text-xs text-muted-foreground">Detect</div>
                        </div>
                        <div className="text-center">
                          <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center mx-auto mb-2">
                            <Bell className="w-6 h-6 text-amber-600" />
                          </div>
                          <div className="text-xs text-muted-foreground">Alert</div>
                        </div>
                        <div className="text-center">
                          <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center mx-auto mb-2">
                            <FileText className="w-6 h-6 text-purple-600" />
                          </div>
                          <div className="text-xs text-muted-foreground">Playbook</div>
                        </div>
                        <div className="text-center">
                          <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mx-auto mb-2">
                            <Rocket className="w-6 h-6 text-green-600" />
                          </div>
                          <div className="text-xs text-muted-foreground">Execute</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Detection Phase */}
              {demoPhase === 'detection' && (
                <Card className="border-blue-500/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="w-5 h-5 text-blue-500 animate-pulse" />
                      Signal Detection
                    </CardTitle>
                    <CardDescription>
                      M is monitoring intelligence signals across 16 categories...
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4 p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
                        <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center animate-pulse">
                          <Radio className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="font-medium">Scanning {activeScenario?.signalCategory}</div>
                          <div className="text-sm text-muted-foreground">
                            Monitoring data points for trigger conditions...
                          </div>
                        </div>
                        <div className="text-sm font-mono text-blue-600 animate-pulse">
                          Analyzing...
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-4 gap-4">
                        {['Competitive', 'Market', 'Financial', 'Regulatory'].map((cat, i) => (
                          <div key={cat} className="text-center p-3 rounded-lg bg-slate-50 dark:bg-slate-900">
                            <div className={`text-xs text-muted-foreground mb-1`}>{cat}</div>
                            <div className={`text-lg font-bold ${
                              cat === activeScenario?.signalCategory?.split(' ')[0] 
                                ? 'text-blue-600 animate-pulse' 
                                : 'text-slate-400'
                            }`}>
                              {cat === activeScenario?.signalCategory?.split(' ')[0] ? '●' : '○'}
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      {!autoAdvance && (
                        <Button 
                          onClick={fireAlert} 
                          className="w-full"
                          data-testid="button-fire-alert"
                        >
                          <Zap className="w-4 h-4 mr-2" />
                          Fire Alert
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Alert Phase */}
              {demoPhase === 'alert' && (
                <Card className="border-red-500/50 bg-red-50/50 dark:bg-red-950/20">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-red-600">
                      <AlertTriangle className="w-5 h-5 animate-bounce" />
                      Strategic Alert Triggered!
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {alerts.map((alert) => (
                      <div 
                        key={alert.id}
                        className="p-4 bg-white dark:bg-slate-900 rounded-lg border-2 border-red-500 shadow-lg animate-in slide-in-from-top duration-500"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <Badge className="bg-red-500">CRITICAL</Badge>
                            <span className="font-semibold">{alert.title}</span>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {alert.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="text-sm text-muted-foreground mb-3">
                          {activeScenario?.simulatedValue}
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Badge variant="outline">{alert.source}</Badge>
                          <span className="text-muted-foreground">•</span>
                          <span className="text-muted-foreground">Playbook ready for activation</span>
                        </div>
                      </div>
                    ))}
                    
                    {!autoAdvance && (
                      <Button 
                        onClick={() => setDemoPhase('playbook')} 
                        className="w-full mt-4"
                        data-testid="button-view-playbook"
                      >
                        View Recommended Playbook
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    )}
                  </CardContent>
                </Card>
              )}
              
              {/* Playbook Phase */}
              {demoPhase === 'playbook' && (
                <Card className="border-purple-500/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-purple-500" />
                      Recommended Playbook
                    </CardTitle>
                    <CardDescription>
                      M has identified the optimal response playbook based on this signal
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-purple-50 dark:bg-purple-950/30 rounded-lg border border-purple-200 dark:border-purple-800">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <Badge variant="outline" className="mb-2">{activeScenario?.recommendedPlaybook.id}</Badge>
                          <div className="font-semibold text-lg">{activeScenario?.recommendedPlaybook.name}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-muted-foreground">Match Score</div>
                          <div className="text-2xl font-bold text-purple-600">98%</div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-sm font-medium mb-3">Pre-configured Actions</div>
                      <div className="space-y-2">
                        {activeScenario?.recommendedPlaybook.actions.map((action, index) => (
                          <div 
                            key={index}
                            className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 dark:bg-slate-900"
                          >
                            <div className="w-6 h-6 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-xs font-semibold text-purple-600">
                              {index + 1}
                            </div>
                            <span className="text-sm">{action}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <Button 
                      onClick={activatePlaybook}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                      data-testid="button-activate-playbook"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Activate Playbook
                    </Button>
                  </CardContent>
                </Card>
              )}
              
              {/* Execution Phase */}
              {demoPhase === 'execution' && (
                <Card className="border-green-500/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Rocket className="w-5 h-5 text-green-500" />
                      Coordinated Execution
                    </CardTitle>
                    <CardDescription>
                      Tasks being distributed to stakeholders simultaneously
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">
                        {completedTasks} of {executionTasks.length} tasks completed
                      </span>
                      <span className="text-sm font-medium">{Math.round(progressPercent)}%</span>
                    </div>
                    <Progress value={progressPercent} className="h-2" />
                    
                    <div className="space-y-2 mt-4">
                      {executionTasks.map((task, index) => (
                        <div 
                          key={task.id}
                          className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-500 ${
                            task.status === 'completed' 
                              ? 'bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800' 
                              : task.status === 'in_progress'
                                ? 'bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 animate-pulse'
                                : 'bg-slate-50 dark:bg-slate-900'
                          }`}
                        >
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            task.status === 'completed' 
                              ? 'bg-green-500' 
                              : task.status === 'in_progress'
                                ? 'bg-blue-500 animate-spin'
                                : 'bg-slate-200 dark:bg-slate-700'
                          }`}>
                            {task.status === 'completed' ? (
                              <CheckCircle2 className="w-4 h-4 text-white" />
                            ) : task.status === 'in_progress' ? (
                              <Activity className="w-4 h-4 text-white" />
                            ) : (
                              <Clock className="w-4 h-4 text-slate-500" />
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="text-sm font-medium">{task.name}</div>
                            <div className="text-xs text-muted-foreground">Assigned to: {task.department}</div>
                          </div>
                          <Badge variant="outline" className={
                            task.status === 'completed' ? 'text-green-600 border-green-300' :
                            task.status === 'in_progress' ? 'text-blue-600 border-blue-300' :
                            'text-slate-500'
                          }>
                            {task.status === 'completed' ? 'Done' : 
                             task.status === 'in_progress' ? 'In Progress' : 'Pending'}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Complete Phase */}
              {demoPhase === 'complete' && (
                <Card className="border-green-500 bg-gradient-to-br from-green-50 to-teal-50 dark:from-green-950/30 dark:to-teal-950/30">
                  <CardContent className="py-8">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-in zoom-in duration-500">
                        <CheckCircle2 className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-green-600 mb-2">
                        Response Complete!
                      </h3>
                      <p className="text-muted-foreground mb-6">
                        Coordinated strategic response executed in {formatTime(executionTime)}
                      </p>
                      
                      <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto mb-8">
                        <div className="p-4 bg-white dark:bg-slate-900 rounded-lg shadow">
                          <div className="text-2xl font-bold text-green-600">{activeScenario?.impactMetrics.revenueAtRisk}</div>
                          <div className="text-xs text-muted-foreground">Revenue Protected</div>
                        </div>
                        <div className="p-4 bg-white dark:bg-slate-900 rounded-lg shadow">
                          <div className="text-2xl font-bold text-blue-600">71h 48m</div>
                          <div className="text-xs text-muted-foreground">Time Saved</div>
                        </div>
                        <div className="p-4 bg-white dark:bg-slate-900 rounded-lg shadow">
                          <div className="text-2xl font-bold text-purple-600">{activeScenario?.stakeholders.length}</div>
                          <div className="text-xs text-muted-foreground">Teams Coordinated</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-center gap-4">
                        <Button 
                          variant="outline" 
                          onClick={resetDemo}
                          data-testid="button-try-another-complete"
                        >
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Try Another Scenario
                        </Button>
                        <Button 
                          onClick={() => setLocation('/foresight-radar')}
                          className="bg-gradient-to-r from-blue-600 to-teal-600"
                          data-testid="button-explore-platform"
                        >
                          Explore Full Platform
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Value Proposition Cards */}
              {(demoPhase === 'intro' || demoPhase === 'complete') && (
                <div className="grid grid-cols-3 gap-4">
                  <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/30 border-blue-200 dark:border-blue-800">
                    <CardContent className="py-6 text-center">
                      <Eye className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                      <div className="text-2xl font-bold text-blue-600">16</div>
                      <div className="text-sm text-muted-foreground">Signal Categories</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/30 dark:to-purple-900/30 border-purple-200 dark:border-purple-800">
                    <CardContent className="py-6 text-center">
                      <FileText className="w-8 h-8 text-purple-600 mx-auto mb-3" />
                      <div className="text-2xl font-bold text-purple-600">148</div>
                      <div className="text-sm text-muted-foreground">Strategic Playbooks</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/30 dark:to-green-900/30 border-green-200 dark:border-green-800">
                    <CardContent className="py-6 text-center">
                      <Timer className="w-8 h-8 text-green-600 mx-auto mb-3" />
                      <div className="text-2xl font-bold text-green-600">12 min</div>
                      <div className="text-sm text-muted-foreground">Execution Velocity</div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </div>
          
          {/* Competitive Differentiation Footer */}
          <Card className="mt-8 bg-slate-900 text-white">
            <CardContent className="py-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold mb-1">Why M Wins</h4>
                  <p className="text-sm text-slate-400">
                    Unlike competitors, M doesn't just detect — it detects AND executes.
                  </p>
                </div>
                <div className="flex items-center gap-6 text-sm">
                  <div className="text-center">
                    <div className="text-slate-400">vs Palantir</div>
                    <div className="font-semibold text-green-400">+Execution</div>
                  </div>
                  <div className="text-center">
                    <div className="text-slate-400">vs Anaplan</div>
                    <div className="font-semibold text-green-400">+Detection</div>
                  </div>
                  <div className="text-center">
                    <div className="text-slate-400">vs Dataminr</div>
                    <div className="font-semibold text-green-400">+Orchestration</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
