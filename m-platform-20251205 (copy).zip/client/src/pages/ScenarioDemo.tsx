import { useState, useEffect } from 'react';
import { useRoute, useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Shield,
  ArrowRight, 
  Clock,
  CheckCircle,
  TrendingUp,
  Eye,
  Play,
  Zap,
  Users,
  Brain,
  ChevronLeft,
  AlertTriangle,
  DollarSign,
  Target,
  Sparkles
} from 'lucide-react';
import { getScenarioById, type Scenario } from '@shared/scenarios';
import { updatePageMetadata } from '@/lib/seo';
import StandardNav from '@/components/layout/StandardNav';

const phases = [
  { id: 'situation', label: 'The Situation', icon: AlertTriangle },
  { id: 'preparation', label: 'Your Preparation', icon: Users },
  { id: 'monitoring', label: 'AI Monitoring', icon: Eye },
  { id: 'trigger', label: 'Trigger Fires', icon: Zap },
  { id: 'execution', label: 'Your Execution', icon: Play },
  { id: 'learning', label: 'AI Learning', icon: Brain },
  { id: 'results', label: 'Results', icon: TrendingUp }
];

export default function ScenarioDemo() {
  const [, params] = useRoute('/business-scenario/:id');
  const [, setLocation] = useLocation();
  const [currentPhase, setCurrentPhase] = useState(0);
  const scenario = params?.id ? getScenarioById(params.id) : null;

  useEffect(() => {
    if (scenario) {
      updatePageMetadata({
        title: `${scenario.title} Demo | M Executive Decision Platform`,
        description: scenario.description,
        ogTitle: `Experience ${scenario.title} with M`,
        ogDescription: `See how executives prepare, AI monitors, and teams execute: ${scenario.purpose}`,
      });
    }
  }, [scenario]);

  if (!scenario) {
    return (
      <div className="page-background min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Scenario Not Found</h1>
          <Button onClick={() => setLocation('/playbook-library')}>Back to Playbook Library</Button>
        </div>
      </div>
    );
  }

  const PhaseIcon = phases[currentPhase].icon;
  const progressPercent = ((currentPhase + 1) / phases.length) * 100;

  const categoryColors = {
    'offensive': 'from-green-600 to-emerald-600',
    'defensive': 'from-blue-600 to-cyan-600',
    'special-teams': 'from-purple-600 to-pink-600'
  };

  const categoryLabels = {
    'offensive': 'Market Growth',
    'defensive': 'Risk Management',
    'special-teams': 'Transformation'
  };

  return (
    <div className="page-background min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      <StandardNav />

      {/* Scenario Header */}
      <section className={`py-12 px-6 bg-gradient-to-r ${categoryColors[scenario.category]} text-white`}>
        <div className="max-w-5xl mx-auto">
          <Badge className="mb-4 bg-white/20 border-white/40 text-white" data-testid="badge-category">
            {categoryLabels[scenario.category]}
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="heading-scenario">
            {scenario.title}
          </h1>
          <p className="text-xl text-white/90 mb-6">
            {scenario.purpose}
          </p>
        </div>
      </section>

      {/* Progress Indicator */}
      <div className="card-bg-b sticky top-[73px] z-40">
        <div className="max-w-5xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <PhaseIcon className="h-5 w-5 text-blue-600" />
              <span className="font-semibold text-slate-900 dark:text-white">
                {phases[currentPhase].label}
              </span>
            </div>
            <span className="text-sm text-slate-600 dark:text-slate-400">
              Step {currentPhase + 1} of {phases.length}
            </span>
          </div>
          <Progress value={progressPercent} className="h-2" />
        </div>
      </div>

      {/* Demo Content */}
      <section className="py-12 px-6">
        <div className="max-w-5xl mx-auto">
          
          {/* Phase 0: The Situation */}
          {currentPhase === 0 && (
            <div className="space-y-8" data-testid="phase-situation">
              <Card className="border-2 border-orange-200 dark:border-orange-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <AlertTriangle className="h-6 w-6 text-orange-600" />
                    The Business Situation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-lg text-slate-700 dark:text-slate-300">
                    {scenario.situation}
                  </p>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-6">
                      <h4 className="font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                        <Clock className="h-5 w-5 text-slate-600" />
                        Traditional Approach
                      </h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                        {scenario.traditionalApproach.description}
                      </p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Timeline:</span>
                          <span className="font-semibold text-orange-600">{scenario.traditionalApproach.timeline}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Cost:</span>
                          <span className="font-semibold text-red-600">{scenario.traditionalApproach.cost}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20 rounded-lg p-6 border-2 border-blue-200 dark:border-blue-800">
                      <h4 className="font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                        <Sparkles className="h-5 w-5 text-blue-600" />
                        M Approach
                      </h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                        {scenario.mApproach.description}
                      </p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Timeline:</span>
                          <span className="font-semibold text-green-600">{scenario.mApproach.timeline}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Outcome:</span>
                          <span className="font-semibold text-blue-600">{scenario.mApproach.outcome}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Phase 1: Your Preparation */}
          {currentPhase === 1 && (
            <div className="space-y-8" data-testid="phase-preparation">
              <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-950/20 dark:border-blue-800">
                <Users className="h-5 w-5 text-blue-600" />
                <AlertDescription className="text-slate-700 dark:text-slate-300">
                  <strong>This is YOUR work:</strong> You and your team built this playbook before any situation arose. Every input below came from your strategic planning sessions.
                </AlertDescription>
              </Alert>

              <Card>
                <CardHeader>
                  <CardTitle>Key Inputs You Defined</CardTitle>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">
                    These are the strategic inputs your team prepared to guide this scenario execution
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {scenario.keyInputs.map((input, idx) => (
                    <div key={idx} className="border-l-4 border-blue-500 pl-4 py-2">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 page-background">
                          <h4 className="font-semibold text-slate-900 dark:text-white mb-1">
                            {input.label}
                          </h4>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            {input.description}
                          </p>
                        </div>
                        {input.userDefined && (
                          <Badge variant="outline" className="ml-4 bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-400 shrink-0">
                            You Defined
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-blue-950/20 border-2 border-slate-200 dark:border-slate-700">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <Target className="h-8 w-8 text-blue-600 flex-shrink-0" />
                    <div>
                      <h3 className="font-bold text-lg mb-2 text-slate-900 dark:text-white">
                        Why This Matters
                      </h3>
                      <p className="text-slate-700 dark:text-slate-300">
                        Strong preparation = Strong outcomes. The quality of these inputs directly determines how effectively AI can monitor, trigger, and support your execution. M amplifies your strategy—it doesn't replace it.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Phase 2: AI Monitoring */}
          {currentPhase === 2 && (
            <div className="space-y-8" data-testid="phase-monitoring">
              <Alert className="border-purple-200 bg-purple-50 dark:bg-purple-950/20 dark:border-purple-800">
                <Eye className="h-5 w-5 text-purple-600" />
                <AlertDescription className="text-slate-700 dark:text-slate-300">
                  <strong>AI monitors what YOU told it to watch:</strong> Based on your inputs, AI scans these data streams 24/7 - something humans simply cannot do at this scale.
                </AlertDescription>
              </Alert>

              <Card>
                <CardHeader>
                  <CardTitle>AI Monitoring Capabilities</CardTitle>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">
                    {scenario.aiMonitoring.length} data streams monitored simultaneously based on your scenario requirements
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {scenario.aiMonitoring.map((stream, idx) => (
                      <div key={idx} className="flex items-start gap-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                        <div className="mt-1">
                          <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
                        </div>
                        <div className="text-sm text-slate-700 dark:text-slate-300">
                          {stream}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-purple-200 dark:border-purple-800">
                <CardHeader>
                  <CardTitle>Your Trigger Conditions</CardTitle>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">
                    AI activates your playbook when these thresholds are met - rules YOU defined
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {scenario.triggers.map((trigger, idx) => (
                    <div key={idx} className="border-l-4 border-purple-500 pl-4 py-2">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 page-background">
                          <h4 className="font-semibold text-slate-900 dark:text-white mb-1">
                            {trigger.condition}
                          </h4>
                          <p className="text-sm text-purple-700 dark:text-purple-400">
                            {trigger.threshold}
                          </p>
                        </div>
                        {trigger.userDefined && (
                          <Badge variant="outline" className="ml-4 bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-400 shrink-0">
                            Your Rule
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Phase 3: Trigger Fires */}
          {currentPhase === 3 && (
            <div className="space-y-8" data-testid="phase-trigger">
              <Card className="border-2 border-orange-500 bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20">
                <CardContent className="pt-8 pb-8">
                  <div className="text-center space-y-4">
                    <Zap className="h-16 w-16 text-orange-600 mx-auto" />
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-white">
                      Trigger Condition Met!
                    </h2>
                    <p className="text-lg text-slate-700 dark:text-slate-300">
                      AI detected: <strong>{scenario.triggers[0]?.condition}</strong>
                    </p>
                    <Alert className="max-w-2xl mx-auto">
                      <AlertDescription className="text-left">
                        <strong>What just happened:</strong> AI continuously monitored the signals you specified and recognized the pattern you defined as critical. Your playbook is now ready for activation - this is the plan YOUR team built.
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Your Playbook Ready for Activation</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-6 border-2 border-blue-200 dark:border-blue-800">
                    <h3 className="font-bold text-lg mb-4 text-slate-900 dark:text-white flex items-center gap-2">
                      <Shield className="h-5 w-5 text-blue-600" />
                      {scenario.title} Response Playbook
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600 dark:text-slate-400">Stakeholders Mapped:</span>
                        <span className="font-semibold">47 team members</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600 dark:text-slate-400">Tasks Sequenced:</span>
                        <span className="font-semibold">127 action items</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600 dark:text-slate-400">Decision Trees:</span>
                        <span className="font-semibold">8 go/no-go checkpoints</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600 dark:text-slate-400">Last Practiced:</span>
                        <span className="font-semibold">3 weeks ago (drill completed)</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-center">
                    <p className="text-slate-600 dark:text-slate-400 mb-4">
                      This is YOUR decision. AI detected the signal, but you're in control.
                    </p>
                    <Button size="lg" className="bg-blue-600 hover:bg-blue-500" data-testid="button-activate">
                      <Play className="h-5 w-5 mr-2" />
                      Activate Your Playbook
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Phase 4: Execution */}
          {currentPhase === 4 && (
            <div className="space-y-8" data-testid="phase-execution">
              <Card className="border-2 border-green-500 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20">
                <CardContent className="pt-8 pb-8">
                  <div className="text-center space-y-4">
                    <div className="inline-flex items-center justify-center">
                      <div className="relative">
                        <Clock className="h-20 w-20 text-green-600" />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-2xl font-bold text-green-700">12:00</span>
                        </div>
                      </div>
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-white">
                      Playbook Executing
                    </h2>
                    <p className="text-lg text-slate-700 dark:text-slate-300">
                      Your team is executing the plan you prepared. AI coordinates, you lead.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                      <h4 className="font-bold">Minutes 0-4</h4>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      47 stakeholders notified with specific assignments. War room assembled. Everyone knows their role.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                      <h4 className="font-bold">Minutes 5-8</h4>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Budget approved, resources mobilized. Teams executing pre-assigned tasks with seamless coordination.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                      <h4 className="font-bold">Minutes 9-12</h4>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Response live, stakeholders informed. Crisis contained. Your playbook worked.
                    </p>
                  </CardContent>
                </Card>
              </div>

              <Alert className="border-green-200 bg-green-50 dark:bg-green-950/20 dark:border-green-800">
                <Users className="h-5 w-5 text-green-600" />
                <AlertDescription className="text-slate-700 dark:text-slate-300">
                  <strong>Key Point:</strong> This isn't AI executing - it's YOUR team executing the playbook YOU built. AI coordinated the activation, but these are your people, your plan, your strategy in action.
                </AlertDescription>
              </Alert>
            </div>
          )}

          {/* Phase 5: AI Learning */}
          {currentPhase === 5 && (
            <div className="space-y-8" data-testid="phase-learning">
              <Alert className="border-cyan-200 bg-cyan-50 dark:bg-cyan-950/20 dark:border-cyan-800">
                <Brain className="h-5 w-5 text-cyan-600" />
                <AlertDescription className="text-slate-700 dark:text-slate-300">
                  <strong>Institutional Memory:</strong> AI captures every decision, timing, and outcome from your execution to improve future performance. Your organization gets smarter with each playbook run.
                </AlertDescription>
              </Alert>

              <Card>
                <CardHeader>
                  <CardTitle>AI Learning Captured</CardTitle>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">
                    Insights from your execution that will improve the next scenario
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {scenario.learning.map((insight, idx) => (
                    <div key={idx} className="border-l-4 border-cyan-500 pl-4 py-3">
                      <div className="space-y-2">
                        <div>
                          <Badge variant="outline" className="mb-2 bg-cyan-50 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-400">
                            Observation
                          </Badge>
                          <p className="text-sm text-slate-700 dark:text-slate-300">
                            {insight.observation}
                          </p>
                        </div>
                        <div>
                          <Badge variant="outline" className="mb-2 bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-400">
                            AI Recommendation
                          </Badge>
                          <p className="text-sm font-semibold text-blue-700 dark:text-blue-400">
                            {insight.recommendation}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-slate-50 to-cyan-50 dark:from-slate-900 dark:to-cyan-950/20 border-2 border-slate-200 dark:border-slate-700">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <Sparkles className="h-8 w-8 text-cyan-600 flex-shrink-0" />
                    <div>
                      <h3 className="font-bold text-lg mb-2 text-slate-900 dark:text-white">
                        Your Platform Gets Smarter
                      </h3>
                      <p className="text-slate-700 dark:text-slate-300">
                        These learnings are applied to future executions. Next time you run this playbook, AI will recommend the optimizations based on what YOUR team experienced. The more you execute, the better it gets.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Phase 6: Results */}
          {currentPhase === 6 && (
            <div className="space-y-8" data-testid="phase-results">
              <Card className="border-2 border-green-500 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20">
                <CardHeader>
                  <CardTitle className="text-2xl flex items-center gap-3">
                    <TrendingUp className="h-8 w-8 text-green-600" />
                    Scenario Outcomes
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {scenario.outputs.map((output, idx) => (
                    <div key={idx} className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-slate-200 dark:border-slate-700">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-bold text-slate-900 dark:text-white">{output.label}</h4>
                        {output.metric && (
                          <Badge className="bg-green-600 text-white">{output.metric}</Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400">{output.description}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-slate-50 dark:bg-slate-800/50">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <DollarSign className="h-5 w-5 text-red-600" />
                      Traditional Approach
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Timeline:</span>
                      <span className="font-semibold text-red-600">{scenario.traditionalApproach.timeline}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Cost Impact:</span>
                      <span className="font-semibold text-red-600">{scenario.traditionalApproach.cost}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20 border-2 border-blue-500">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-blue-600" />
                      M Approach
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Timeline:</span>
                      <span className="font-semibold text-green-600">{scenario.mApproach.timeline}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Outcome:</span>
                      <span className="font-semibold text-blue-600">{scenario.mApproach.outcome}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white">
                <CardContent className="pt-8 pb-8">
                  <div className="text-center space-y-4">
                    <h2 className="text-3xl font-bold">
                      The Human-AI Partnership in Action
                    </h2>
                    <p className="text-lg text-blue-100 max-w-3xl mx-auto">
                      You prepared the playbook. AI monitored 24/7. You made the decision. Your team executed. AI learned and improved. Together, you transformed a {scenario.traditionalApproach.timeline} challenge into a {scenario.mApproach.timeline} success.
                    </p>
                    <div className="pt-4 flex gap-4 justify-center">
                      <Button 
                        size="lg" 
                        variant="secondary"
                        onClick={() => setLocation('/playbook-library')}
                        data-testid="button-explore-more"
                      >
                        Explore Playbook Library
                      </Button>
                      <Button 
                        size="lg" 
                        variant="outline"
                        className="border-white text-white hover:bg-white/10"
                        onClick={() => setLocation('/dashboard')}
                        data-testid="button-view-product"
                      >
                        View Full Platform
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between items-center pt-8 border-t">
            <Button
              variant="outline"
              onClick={() => setCurrentPhase(Math.max(0, currentPhase - 1))}
              disabled={currentPhase === 0}
              data-testid="button-previous"
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>

            <Button
              onClick={() => setCurrentPhase(Math.min(phases.length - 1, currentPhase + 1))}
              disabled={currentPhase === phases.length - 1}
              data-testid="button-next"
            >
              Next
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
