import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 border-t border-slate-800">
      {/* Research Trust Bar */}
      <div className="border-b border-slate-800 py-8">
        <div className="max-w-7xl mx-auto px-6 sm:px-8">
          <p className="text-center text-sm text-slate-500 mb-6">
            Research and methodology informed by industry leaders
          </p>
          <div className="flex flex-wrap justify-center items-center gap-6 md:gap-10">
            <div className="text-center">
              <p className="font-semibold text-slate-400 text-sm">McKinsey & Company</p>
              <p className="text-xs text-slate-600">Crisis Framework</p>
            </div>
            <div className="hidden md:block h-8 w-px bg-slate-800" />
            <div className="text-center">
              <p className="font-semibold text-slate-400 text-sm">PwC</p>
              <p className="text-xs text-slate-600">Global Crisis Survey</p>
            </div>
            <div className="hidden md:block h-8 w-px bg-slate-800" />
            <div className="text-center">
              <p className="font-semibold text-slate-400 text-sm">IBM Security</p>
              <p className="text-xs text-slate-600">Cost of Data Breach</p>
            </div>
            <div className="hidden md:block h-8 w-px bg-slate-800" />
            <div className="text-center">
              <p className="font-semibold text-slate-400 text-sm">Ponemon Institute</p>
              <p className="text-xs text-slate-600">Security Research</p>
            </div>
          </div>
          <div className="text-center mt-6">
            <Link to="/research" className="text-primary text-sm hover:underline inline-flex items-center gap-1">
              View Research Sources
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-6 sm:px-8">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 md:gap-12">
            <div className="col-span-2 md:col-span-1">
              <Link to="/">
                <div className="flex items-center gap-3 mb-4 cursor-pointer hover:opacity-80 transition-opacity">
                  <div className="w-10 h-10 bg-gradient-to-br from-slate-100 to-slate-300 rounded-xl flex items-center justify-center shadow-lg">
                    <span className="text-slate-900 font-bold text-xl">M</span>
                  </div>
                  <span className="text-2xl font-bold text-white">M</span>
                </div>
              </Link>
              <p className="text-slate-400 text-sm">
                Strategic Execution Operating System
              </p>
              <p className="text-slate-500 text-xs mt-2">
                72 hours → 12 minutes
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Platform</h4>
              <ul className="space-y-2">
                <li><Link to="/command-center" className="text-slate-400 hover:text-white text-sm transition-colors">Command Center</Link></li>
                <li><Link to="/playbook-library" className="text-slate-400 hover:text-white text-sm transition-colors">Playbook Library</Link></li>
                <li><Link to="/foresight-radar" className="text-slate-400 hover:text-white text-sm transition-colors">Foresight Radar</Link></li>
                <li><Link to="/executive-dashboard" className="text-slate-400 hover:text-white text-sm transition-colors">Executive Dashboard</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Capabilities</h4>
              <ul className="space-y-2">
                <li><Link to="/future-gym" className="text-slate-400 hover:text-white text-sm transition-colors">Future Gym</Link></li>
                <li><Link to="/living-playbooks" className="text-slate-400 hover:text-white text-sm transition-colors">Living Playbooks</Link></li>
                <li><Link to="/what-if-analyzer" className="text-slate-400 hover:text-white text-sm transition-colors">What-If Analyzer</Link></li>
                <li><Link to="/playbook-readiness" className="text-slate-400 hover:text-white text-sm transition-colors">Readiness Audit</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Resources</h4>
              <ul className="space-y-2">
                <li><Link to="/demo-selector" className="text-slate-400 hover:text-white text-sm transition-colors">Watch Demo</Link></li>
                <li><Link to="/research" className="text-slate-400 hover:text-white text-sm transition-colors">Research</Link></li>
                <li><Link to="/why-m" className="text-slate-400 hover:text-white text-sm transition-colors">Why M</Link></li>
                <li><Link to="/pricing" className="text-slate-400 hover:text-white text-sm transition-colors">Pricing</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Company</h4>
              <ul className="space-y-2">
                <li><Link to="/our-story" className="text-slate-400 hover:text-white text-sm transition-colors">Our Story</Link></li>
                <li><Link to="/investor-resources" className="text-slate-400 hover:text-white text-sm transition-colors">Investors</Link></li>
                <li><Link to="/contact" className="text-slate-400 hover:text-white text-sm transition-colors">Contact</Link></li>
                <li><Link to="/sitemap" className="text-slate-400 hover:text-white text-sm transition-colors">Sitemap</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-slate-500 text-sm">
              &copy; {currentYear} M Strategic Execution OS. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-slate-500 text-sm">
              <span>Enterprise Security</span>
              <span>SOC 2 Compliant</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
