import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Target, Radio, CheckCircle, BookOpen, Play, TrendingUp, ChevronDown, Layers, Settings, Presentation, Sparkles, Info, Mail, LogIn, LogOut, User, ArrowLeft, Home } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import GlobalPhaseIndicator from "@/components/GlobalPhaseIndicator";

export default function StandardNav() {
  const [location, setLocation] = useLocation();
  const [platformOpen, setPlatformOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const { user, isAuthenticated, isLoading, login, logout } = useAuth();

  const navigateTo = (path: string) => {
    setLocation(path);
    setPlatformOpen(false);
    setAboutOpen(false);
  };

  // THE 4 PILLARS with all features
  const fourPillars = [
    {
      label: 'PREPARE',
      icon: Target,
      color: 'text-blue-400',
      borderColor: 'border-blue-500/30',
      items: [
        { label: 'Playbook Library', path: '/playbook-library', badge: '148' },
        { label: 'What-If Analyzer', path: '/what-if-analyzer' },
        { label: 'Practice Drills', path: '/practice-drills' },
      ]
    },
    {
      label: 'MONITOR',
      icon: Radio,
      color: 'text-cyan-400',
      borderColor: 'border-cyan-500/30',
      items: [
        { label: 'Intelligence Control Center', path: '/intelligence', badge: 'ALL' },
        { label: 'AI Intelligence Hub', path: '/ai', badge: '5 MODULES' },
        { label: 'Triggers & Signals', path: '/triggers-management', badge: '92 DATA' },
        { label: 'Foresight Radar', path: '/foresight-radar' },
      ]
    },
    {
      label: 'EXECUTE',
      icon: CheckCircle,
      color: 'text-green-400',
      borderColor: 'border-green-500/30',
      items: [
        { label: 'Command Center', path: '/command-center' },
        { label: 'Team Coordination', path: '/collaboration' },
        { label: 'Ecosystem Connectors', path: '/integrations', badge: '15+' },
        { label: 'Integration Hub', path: '/integration-hub', badge: 'MONITOR' },
      ]
    },
    {
      label: 'LEARN',
      icon: BookOpen,
      color: 'text-purple-400',
      borderColor: 'border-purple-500/30',
      items: [
        { label: 'Executive Dashboard', path: '/executive-dashboard', badge: 'NEW' },
        { label: 'Institutional Memory', path: '/institutional-memory' },
        { label: 'Board Briefings', path: '/board-briefings' },
        { label: 'Advanced Analytics', path: '/analytics' },
      ]
    },
  ];
  
  const configurationSection = {
    label: 'CONFIGURE',
    icon: Settings,
    color: 'text-cyan-400',
    borderColor: 'border-cyan-500/30',
    items: [
      { label: 'Organization Setup', path: '/organization-setup', badge: 'NEW' },
      { label: 'Trigger Configuration', path: '/triggers-management' },
      { label: 'Playbook Customization', path: '/playbook-customization', badge: 'NEW' },
      { label: 'Success Metrics', path: '/success-metrics', badge: 'NEW' },
    ]
  };
  
  const demosSection = {
    label: 'DEMOS',
    icon: Presentation,
    color: 'text-green-400',
    borderColor: 'border-green-500/30',
    items: [
      { label: '4-Phase System Demo', path: '/four-phase-demo', badge: 'NEW' },
      { label: 'Transformational Demo', path: '/transformational-demo', badge: 'ROADSHOW' },
      { label: 'Demo Hub', path: '/demo-hub', badge: 'ALL DEMOS' },
      { label: 'Live Activation Demo', path: '/demo/live-activation', badge: 'LIVE' },
      { label: 'Product Tour', path: '/product-tour', badge: '14 scenes' },
      { label: 'Executive Simulation', path: '/executive-simulation' },
      { label: 'How It Works', path: '/how-it-works' },
    ]
  };

  return (
    <>
      <nav className="border-b bg-slate-950 backdrop-blur-sm sticky top-0 z-50 shadow-lg">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          {/* Logo */}
          <div 
            className="flex items-center gap-3 cursor-pointer hover:opacity-80 transition-opacity duration-200 flex-shrink-0" 
            onClick={() => navigateTo('/')}
            data-testid="button-home-logo"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xl">M</span>
            </div>
            <div className="hidden sm:block">
              <div className="font-bold text-lg text-white leading-tight">M</div>
              <div className="text-[10px] text-slate-400">Strategic Execution OS</div>
            </div>
          </div>
          
          {/* Main Navigation */}
          <div className="flex items-center gap-1 sm:gap-2">
            {/* Back Button */}
            <Button 
              variant="ghost" 
              onClick={() => window.history.back()}
              className="text-slate-300 hover:text-white hover:bg-slate-800 h-9 w-9 p-0 flex items-center justify-center"
              data-testid="button-back"
              title="Go back"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            
            {/* Home */}
            <Button 
              variant="ghost" 
              onClick={() => navigateTo("/")}
              className="text-slate-300 hover:text-white hover:bg-slate-800 h-9 w-9 p-0 sm:w-auto sm:px-3 flex items-center justify-center"
              data-testid="button-home"
              title="Go to home"
            >
              <Home className="h-4 w-4 sm:hidden" />
              <span className="hidden sm:inline">Home</span>
            </Button>

            {/* About M Dropdown */}
            <div className="relative">
              <Button 
                variant="ghost"
                onClick={() => {
                  setAboutOpen(!aboutOpen);
                  setPlatformOpen(false);
                }}
                className={`text-sm h-9 px-3 hidden md:flex ${aboutOpen ? 'bg-slate-800 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}
                data-testid="button-about-m"
              >
                <Info className="h-4 w-4 mr-1.5" />
                About M
                <ChevronDown className={`h-4 w-4 ml-1 transition-transform ${aboutOpen ? 'rotate-180' : ''}`} />
              </Button>
              
              {/* About Dropdown Menu */}
              {aboutOpen && (
                <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setAboutOpen(false)}
                />
                <div className="absolute top-full left-0 mt-1 w-56 bg-slate-900 border border-slate-700 rounded-lg shadow-xl z-50 py-2">
                  <button
                    onClick={() => navigateTo("/how-it-works")}
                    className="w-full text-left px-4 py-2.5 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-sm flex items-center gap-3"
                    data-testid="nav-how-it-works"
                  >
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                      <Sparkles className="h-4 w-4 text-blue-400" />
                    </div>
                    <div>
                      <div className="font-medium">How It Works</div>
                      <div className="text-xs text-slate-500">The 4-phase methodology</div>
                    </div>
                  </button>
                  <button
                    onClick={() => navigateTo("/our-story")}
                    className="w-full text-left px-4 py-2.5 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-sm flex items-center gap-3"
                    data-testid="nav-our-story"
                  >
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center">
                      <BookOpen className="h-4 w-4 text-amber-400" />
                    </div>
                    <div>
                      <div className="font-medium">Our Story</div>
                      <div className="text-xs text-slate-500">The origin & validation</div>
                    </div>
                  </button>
                  <button
                    onClick={() => navigateTo("/why-m")}
                    className="w-full text-left px-4 py-2.5 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-sm flex items-center gap-3"
                    data-testid="nav-why-m"
                  >
                    <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                      <Target className="h-4 w-4 text-purple-400" />
                    </div>
                    <div>
                      <div className="font-medium">Why M</div>
                      <div className="text-xs text-slate-500">Competitive advantage</div>
                    </div>
                  </button>
                  <div className="border-t border-slate-700 my-2" />
                  <button
                    onClick={() => navigateTo("/start")}
                    className="w-full text-left px-4 py-2.5 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-sm flex items-center gap-3"
                    data-testid="nav-get-started"
                  >
                    <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center">
                      <TrendingUp className="h-4 w-4 text-green-400" />
                    </div>
                    <div>
                      <div className="font-medium">Get Started</div>
                      <div className="text-xs text-slate-500">15-min setup experience</div>
                    </div>
                  </button>
                  <button
                    onClick={() => navigateTo("/contact")}
                    className="w-full text-left px-4 py-2.5 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-sm flex items-center gap-3"
                    data-testid="nav-contact"
                  >
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                      <Mail className="h-4 w-4 text-blue-400" />
                    </div>
                    <div>
                      <div className="font-medium">Contact Sales</div>
                      <div className="text-xs text-slate-500">Talk to our team</div>
                    </div>
                  </button>
                </div>
                </>
              )}
            </div>

            {/* Platform Dropdown - THE MEGA MENU */}
            <div className="relative">
              <Button 
                variant="ghost"
                onClick={() => {
                  setPlatformOpen(!platformOpen);
                  setAboutOpen(false);
                }}
                className={`text-sm h-9 px-3 font-semibold ${platformOpen ? 'bg-slate-800 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}
                data-testid="button-platform"
              >
                <Layers className="h-4 w-4 mr-1.5" />
                Platform
                <ChevronDown className={`h-4 w-4 ml-1 transition-transform ${platformOpen ? 'rotate-180' : ''}`} />
              </Button>
            </div>

            {/* Pricing */}
            <Button 
              variant="ghost" 
              onClick={() => navigateTo("/pricing")}
              className="text-slate-300 hover:text-white hover:bg-slate-800 text-sm h-9 px-3 hidden md:flex"
              data-testid="button-pricing"
            >
              Pricing
            </Button>

            {/* Live Demo - Highlighted */}
            <Button 
              variant="ghost" 
              onClick={() => navigateTo("/demo/live-activation")}
              className="text-green-400 hover:text-green-300 hover:bg-green-900/30 text-sm h-9 px-3 font-semibold"
              data-testid="button-demo"
            >
              <Play className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Live Demo</span>
              <span className="sm:hidden">Demo</span>
            </Button>
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            <Button 
              onClick={() => navigateTo("/executive-dashboard")} 
              variant="ghost"
              className="text-slate-300 hover:text-white hover:bg-slate-800 text-sm h-9 px-3"
              data-testid="button-dashboard"
            >
              <TrendingUp className="h-4 w-4 sm:mr-1.5" />
              <span className="hidden sm:inline">Dashboard</span>
            </Button>
            
            {/* Phase Indicator - Compact */}
            <div className="hidden lg:block border-l border-slate-700 pl-3 ml-1">
              <GlobalPhaseIndicator 
                scores={{ prepare: 72, monitor: 68, execute: 85, learn: 64 }}
                compact={true} 
              />
            </div>
            
            {/* Auth Buttons */}
            {isLoading ? (
              <div className="h-9 w-20 bg-slate-800 animate-pulse rounded" />
            ) : isAuthenticated && user ? (
              <div className="flex items-center gap-2">
                <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-800 rounded-lg">
                  <User className="h-4 w-4 text-slate-400" />
                  <span className="text-sm text-slate-300">{user.firstName || user.email}</span>
                </div>
                <Button 
                  onClick={logout}
                  variant="ghost"
                  className="text-slate-300 hover:text-white hover:bg-slate-800 text-sm h-9 px-3"
                  data-testid="button-logout"
                >
                  <LogOut className="h-4 w-4 sm:mr-1.5" />
                  <span className="hidden sm:inline">Sign Out</span>
                </Button>
              </div>
            ) : (
              <Button 
                onClick={login}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm h-9 px-4"
                data-testid="button-login"
              >
                <LogIn className="h-4 w-4 mr-1.5" />
                <span className="hidden sm:inline">Sign In</span>
                <span className="sm:hidden">Login</span>
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Platform Mega Menu Dropdown */}
      {platformOpen && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 z-40 bg-black/50"
            onClick={() => {
              setPlatformOpen(false);
              setAboutOpen(false);
            }}
          />
          
          {/* Mega Menu */}
          <div className="fixed left-0 right-0 top-[60px] z-50 bg-slate-900 border-b border-slate-700 shadow-2xl">
            <div className="max-w-[1600px] mx-auto px-6 py-6">
              {/* Platform Grid - 4 Pillars + Configure + Demos */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
                {fourPillars.map((pillar) => (
                  <div key={pillar.label} className={`border-l-2 ${pillar.borderColor} pl-4`}>
                    {/* Pillar Header */}
                    <div className={`flex items-center gap-2 mb-3 ${pillar.color}`}>
                      <pillar.icon className="h-5 w-5" />
                      <span className="font-bold text-sm tracking-wide">{pillar.label}</span>
                    </div>
                    
                    {/* Pillar Features */}
                    <ul className="space-y-1">
                      {pillar.items.map((item) => (
                        <li key={item.path}>
                          <button
                            onClick={() => navigateTo(item.path)}
                            className="w-full text-left py-2 px-3 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-sm flex items-center justify-between group"
                            data-testid={`nav-${item.path.replace('/', '')}`}
                          >
                            <span>{item.label}</span>
                            {item.badge && (
                              <span className={`text-xs px-1.5 py-0.5 rounded ${
                                item.badge === 'LIVE' 
                                  ? 'bg-green-500 text-white animate-pulse' 
                                  : 'bg-blue-600 text-white'
                              }`}>
                                {item.badge}
                              </span>
                            )}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
                
                {/* Configuration Section */}
                <div className={`border-l-2 ${configurationSection.borderColor} pl-4`}>
                  <div className={`flex items-center gap-2 mb-3 ${configurationSection.color}`}>
                    <configurationSection.icon className="h-5 w-5" />
                    <span className="font-bold text-sm tracking-wide">{configurationSection.label}</span>
                  </div>
                  <ul className="space-y-1">
                    {configurationSection.items.map((item) => (
                      <li key={item.path}>
                        <button
                          onClick={() => navigateTo(item.path)}
                          className="w-full text-left py-2 px-3 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-sm flex items-center justify-between group"
                          data-testid={`nav-${item.path.replace('/', '')}`}
                        >
                          <span>{item.label}</span>
                          {item.badge && (
                            <span className={`text-xs px-1.5 py-0.5 rounded ${
                              item.badge === 'LIVE' 
                                ? 'bg-green-500 text-white animate-pulse' 
                                : item.badge === 'NEW'
                                  ? 'bg-cyan-500 text-white'
                                  : 'bg-blue-600 text-white'
                            }`}>
                              {item.badge}
                            </span>
                          )}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Demos Section - Highlighted */}
                <div className={`border-l-2 ${demosSection.borderColor} pl-4 bg-gradient-to-b from-green-950/20 to-transparent rounded-r-lg`}>
                  <div className={`flex items-center gap-2 mb-3 ${demosSection.color}`}>
                    <demosSection.icon className="h-5 w-5" />
                    <span className="font-bold text-sm tracking-wide">{demosSection.label}</span>
                    <Sparkles className="h-3 w-3 text-yellow-400" />
                  </div>
                  <ul className="space-y-1">
                    {demosSection.items.map((item) => (
                      <li key={item.path}>
                        <button
                          onClick={() => navigateTo(item.path)}
                          className="w-full text-left py-2 px-3 rounded-lg text-slate-300 hover:text-white hover:bg-green-900/30 transition-colors text-sm flex items-center justify-between group"
                          data-testid={`nav-${item.path.replace(/\//g, '-').replace(/^-/, '')}`}
                        >
                          <span>{item.label}</span>
                          {item.badge && (
                            <span className={`text-xs px-1.5 py-0.5 rounded ${
                              item.badge === 'LIVE' 
                                ? 'bg-green-500 text-white animate-pulse' 
                                : 'bg-green-700 text-green-100'
                            }`}>
                              {item.badge}
                            </span>
                          )}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Quick Links Row */}
              <div className="mt-6 pt-6 border-t border-slate-700 flex flex-wrap gap-4 items-center justify-between">
                <div className="flex flex-wrap gap-3">
                  <span className="text-xs text-slate-500 mr-2">Quick Access:</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateTo('/luxury-demo')}
                    className="text-slate-400 hover:text-white text-xs"
                    data-testid="quick-luxury-demo"
                  >
                    Luxury Crisis
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateTo('/financial-demo')}
                    className="text-slate-400 hover:text-white text-xs"
                    data-testid="quick-financial-demo"
                  >
                    Ransomware Response
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateTo('/spacex-demo')}
                    className="text-slate-400 hover:text-white text-xs"
                    data-testid="quick-spacex-demo"
                  >
                    SpaceX Launch
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateTo('/investor-presentation')}
                    className="text-slate-400 hover:text-white text-xs"
                    data-testid="quick-investor-deck"
                  >
                    Investor Deck
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateTo('/demo-hub')}
                    className="text-green-400 hover:text-green-300 text-xs font-medium"
                    data-testid="quick-all-demos"
                  >
                    View All Demos →
                  </Button>
                </div>
                <div className="text-xs text-slate-500">
                  6 sections • 148 playbooks • 9 industry demos • Full customization
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}
