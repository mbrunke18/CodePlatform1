/**
 * Authentication Configuration
 * 
 * Defines which API routes require authentication and which are public.
 * This centralized configuration makes it easy to manage auth across the platform.
 */

/**
 * PUBLIC ROUTES - Accessible without authentication
 * These are typically used for marketing, demos, and public information
 */
export const PUBLIC_ROUTES = [
  // Marketing & Demo Routes - allow prospects to view content
  '/api/scenario-templates',
  '/api/scenario-templates/crisis',
  '/api/scenario-templates/category/:category',
  '/api/scenario-templates/comprehensive',
  '/api/scenario-templates/:id',
  
  // NFL Methodology - Playbook Library & Practice Drills (public demo access)
  '/api/playbook-library',
  '/api/playbook-library/domains',
  '/api/playbook-library/domains/:domainId/categories',
  '/api/playbook-library/featured',
  '/api/playbook-library/by-number/:playbookNumber',
  '/api/playbook-library/:playbookId',
  '/api/playbook-library/ai-suggestions/:organizationId',
  '/api/playbook-library/activations/:organizationId',
  '/api/practice-drills',
  '/api/practice-drills/:organizationId',
  '/api/practice-drills/drill/:drillId',
  '/api/practice-drills/performance',
  '/api/practice-drills/performance/:organizationId',
  '/api/crisis-simulations',
  '/api/crisis-simulations/:organizationId',
  '/api/crisis-simulations/:id',
  '/api/crisis-simulations/:id/status',
  '/api/preparedness/score',
  '/api/preparedness/score/:organizationId',
  '/api/preparedness/history',
  '/api/preparedness/calculate',
  '/api/preparedness/activity',
  '/api/organizations',
  '/api/organizations/:id',
  '/api/users', // Public access for demo mode (NO AUTHENTICATION requirement)
  
  // Demo & Public Data Access
  '/api/demo/scenarios',
  '/api/demo/reset',
  '/api/dashboard/metrics',
  '/api/strategic-scenarios',
  '/api/strategic-scenarios/:id',
  
  // Public Query & Analysis  
  '/api/scenarios',
  '/api/scenarios/:id',
  '/api/scenarios/recent',
  '/api/tasks',
  '/api/what-if-scenarios',
  '/api/executive-triggers',
  '/api/executive-briefings',
  '/api/board-reports',
  
  // Health & Status - for monitoring/uptime checks
  '/api/health',
  '/api/status',
  '/api/pilot-monitoring/system-health',
  '/api/pilot-monitoring/pilot-metrics',
  '/api/pilot-monitoring/recent-activity',
  
  // Auth Routes - needed for login/logout flow
  '/auth/login',
  '/auth/logout',
  '/auth/callback',
  '/api/auth/status',
];

/**
 * PROTECTED ROUTE PATTERNS - Require authentication
 * All routes NOT in PUBLIC_ROUTES should require auth by default
 */
export const PROTECTED_ROUTE_CATEGORIES = {
  // User & Organization Management
  USERS: [
    '/api/users',
    '/api/organizations',
    '/api/roles',
    '/api/permissions',
  ],
  
  // Strategic Scenarios & Execution
  SCENARIOS: [
    '/api/scenarios',
    '/api/scenarios/:id',
    '/api/scenarios/from-template',
    '/api/scenarios/:id/import',
  ],
  
  // Triggers & Monitoring
  TRIGGERS: [
    '/api/triggers',
    '/api/trigger-monitoring-history',
    '/api/playbook-trigger-associations',
    '/api/strategic-alerts',
  ],
  
  // Execution & War Room
  EXECUTION: [
    '/api/war-room',
    '/api/playbook-activation',
    '/api/execution-instances',
    '/api/execution-validation-reports',
  ],
  
  // AI Intelligence Modules
  AI_INTELLIGENCE: [
    '/api/pulse',
    '/api/flux',
    '/api/prism',
    '/api/echo',
    '/api/nova',
    '/api/intelligence',
  ],
  
  // Analytics & Reporting
  ANALYTICS: [
    '/api/preparedness',
    '/api/decision-confidence',
    '/api/stakeholder-alignment',
    '/api/roi-metrics',
    '/api/decision-outcomes',
  ],
  
  // Board & Executive
  EXECUTIVE: [
    '/api/executive-briefings',
    '/api/board-reports',
    '/api/executive-insights',
  ],
  
  // Integrations & Data Sources
  INTEGRATIONS: [
    '/api/data-sources',
    '/api/integrations',
    '/api/action-hooks',
  ],
  
  // Learning & Institutional Memory
  LEARNING: [
    '/api/learning-patterns',
    '/api/what-if-scenarios',
    '/api/crisis-simulations',
  ],
};

/**
 * Check if a route should be public (no auth required)
 */
export function isPublicRoute(path: string): boolean {
  return PUBLIC_ROUTES.some(publicRoute => {
    // Exact match
    if (publicRoute === path) return true;
    
    // Pattern match with :param
    const pattern = publicRoute.replace(/:[^/]+/g, '[^/]+');
    const regex = new RegExp(`^${pattern}$`);
    return regex.test(path);
  });
}

/**
 * Get auth status for all routes (for auditing)
 */
export function getAuthAudit(): {
  publicRoutes: string[];
  protectedCategories: typeof PROTECTED_ROUTE_CATEGORIES;
  summary: {
    totalPublic: number;
    totalProtected: number;
  };
} {
  const protectedCount = Object.values(PROTECTED_ROUTE_CATEGORIES)
    .flat()
    .length;
  
  return {
    publicRoutes: PUBLIC_ROUTES,
    protectedCategories: PROTECTED_ROUTE_CATEGORIES,
    summary: {
      totalPublic: PUBLIC_ROUTES.length,
      totalProtected: protectedCount,
    },
  };
}

/**
 * Middleware factory for conditional authentication
 * Returns requireAuth middleware unless route is public
 */
export function conditionalAuth(req: any, res: any, next: any) {
  // Use originalUrl to get the full path including /api prefix
  // When mounted with app.use('/api', middleware), req.path gets stripped
  const path = req.originalUrl || req.url;
  
  // Check if route is public
  if (isPublicRoute(path)) {
    return next(); // Skip auth for public routes
  }
  
  // Require auth for all other routes
  const userId = req.user?.claims?.sub || req.user?.sub || req.user?.id || null;
  if (!userId) {
    return res.status(401).json({ 
      error: 'Authentication required',
      message: 'This endpoint requires authentication. Please log in to continue.',
    });
  }
  
  req.userId = userId;
  next();
}
