import { Router } from 'express';
import { db } from '../db';
import {
  playbookDomains,
  playbookCategories,
  playbookLibrary,
  playbookCommunicationTemplates,
  playbookDecisionTrees,
  practiceDrills,
  drillPerformance,
  aiOptimizationSuggestions,
  playbookActivations,
  type PlaybookDomain,
  type PlaybookCategory,
  type PlaybookLibrary,
} from '@shared/schema';
import { eq, desc, sql } from 'drizzle-orm';
import { getPlaybookInsights } from '../services/preparedness-scoring';

export const playbookLibraryRouter = Router();

/**
 * GET /api/playbook-library/domains
 * Get all playbook domains with playbook counts
 */
playbookLibraryRouter.get('/domains', async (req, res) => {
  try {
    const domains = await db
      .select()
      .from(playbookDomains)
      .orderBy(playbookDomains.sequence);

    res.json(domains);
  } catch (error) {
    console.error('Error fetching domains:', error);
    res.status(500).json({ error: 'Failed to fetch playbook domains' });
  }
});

/**
 * GET /api/playbook-library/domains/:domainId/categories
 * Get all categories for a specific domain
 */
playbookLibraryRouter.get('/domains/:domainId/categories', async (req, res) => {
  try {
    const { domainId } = req.params;

    const categories = await db
      .select()
      .from(playbookCategories)
      .where(eq(playbookCategories.domainId, domainId))
      .orderBy(playbookCategories.sequence);

    res.json(categories);
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

/**
 * GET /api/playbook-library
 * Get all domains, categories, and playbooks in a structured format
 */
playbookLibraryRouter.get('/', async (req, res) => {
  try {
    // Fetch all domains
    const domains = await db
      .select()
      .from(playbookDomains)
      .orderBy(playbookDomains.sequence);

    // Fetch all categories
    const categories = await db
      .select()
      .from(playbookCategories)
      .orderBy(playbookCategories.sequence);

    // Fetch all playbooks
    const playbooks = await db
      .select()
      .from(playbookLibrary)
      .orderBy(playbookLibrary.playbookNumber);

    // Return structured data
    res.json({
      domains,
      categories,
      playbooks,
    });
  } catch (error) {
    console.error('Error fetching playbook library:', error);
    res.status(500).json({ error: 'Failed to fetch playbook library' });
  }
});

/**
 * GET /api/playbook-library/featured
 * Get the 13 featured playbooks with full details and domain info
 */
playbookLibraryRouter.get('/featured', async (req, res) => {
  try {
    const featuredPlaybooks = await db
      .select()
      .from(playbookLibrary)
      .where(sql`${playbookLibrary.playbookNumber} BETWEEN 6 AND 18`)
      .orderBy(playbookLibrary.playbookNumber);

    // Fetch domains for each playbook
    const playbooksWithDomains = await Promise.all(
      featuredPlaybooks.map(async (playbook) => {
        const [domain] = await db
          .select()
          .from(playbookDomains)
          .where(eq(playbookDomains.id, playbook.domainId));

        return {
          ...playbook,
          domain: domain || null,
        };
      })
    );

    res.json(playbooksWithDomains);
  } catch (error) {
    console.error('Error fetching featured playbooks:', error);
    res.status(500).json({ error: 'Failed to fetch featured playbooks' });
  }
});

/**
 * GET /api/playbook-library/by-number/:playbookNumber
 * Get a playbook by its playbook number with domain info
 */
playbookLibraryRouter.get('/by-number/:playbookNumber', async (req, res) => {
  try {
    const { playbookNumber } = req.params;

    const [playbook] = await db
      .select()
      .from(playbookLibrary)
      .where(eq(playbookLibrary.playbookNumber, parseInt(playbookNumber)));

    if (!playbook) {
      return res.status(404).json({ error: 'Playbook not found' });
    }

    // Get domain info
    const [domain] = await db
      .select()
      .from(playbookDomains)
      .where(eq(playbookDomains.id, playbook.domainId));

    res.json({
      ...playbook,
      domain: domain || null,
    });
  } catch (error) {
    console.error('Error fetching playbook by number:', error);
    res.status(500).json({ error: 'Failed to fetch playbook' });
  }
});

/**
 * GET /api/playbook-library/:playbookId
 * Get detailed playbook information including templates and decision trees
 */
playbookLibraryRouter.get('/:playbookId', async (req, res) => {
  try {
    const { playbookId } = req.params;

    // Get playbook details
    const [playbook] = await db
      .select()
      .from(playbookLibrary)
      .where(eq(playbookLibrary.id, playbookId));

    if (!playbook) {
      return res.status(404).json({ error: 'Playbook not found' });
    }

    // Get communication templates
    const templates = await db
      .select()
      .from(playbookCommunicationTemplates)
      .where(eq(playbookCommunicationTemplates.playbookId, playbookId))
      .orderBy(playbookCommunicationTemplates.sendTiming);

    // Get decision trees
    const decisionTrees = await db
      .select()
      .from(playbookDecisionTrees)
      .where(eq(playbookDecisionTrees.playbookId, playbookId))
      .orderBy(playbookDecisionTrees.sequence);

    // Get domain and category info
    const [domain] = await db
      .select()
      .from(playbookDomains)
      .where(eq(playbookDomains.id, playbook.domainId));

    const [category] = await db
      .select()
      .from(playbookCategories)
      .where(eq(playbookCategories.id, playbook.categoryId));

    res.json({
      playbook,
      domain,
      category,
      communicationTemplates: templates,
      decisionTrees,
    });
  } catch (error) {
    console.error('Error fetching playbook details:', error);
    res.status(500).json({ error: 'Failed to fetch playbook details' });
  }
});

/**
 * GET /api/playbook-library/:playbookId/insights
 * Get dynamic playbook insights (preparedness score, metrics, etc.)
 */
playbookLibraryRouter.get('/:playbookId/insights', async (req, res) => {
  try {
    const { playbookId } = req.params;
    
    const insights = await getPlaybookInsights(playbookId);
    res.json(insights);
  } catch (error) {
    console.error('Error fetching playbook insights:', error);
    res.status(500).json({ error: 'Failed to fetch playbook insights' });
  }
});

/**
 * GET /api/playbook-library/preparedness-coverage
 * Calculate preparedness coverage across all domains for an organization
 */
playbookLibraryRouter.get('/preparedness-coverage/:organizationId', async (req, res) => {
  try {
    const { organizationId } = req.params;

    // Get all domains
    const domains = await db
      .select()
      .from(playbookDomains)
      .orderBy(playbookDomains.sequence);

    // For each domain, calculate coverage
    // Coverage = (# of drills completed + # of real activations) / total playbooks in domain
    const coverage = await Promise.all(
      domains.map(async (domain) => {
        // Count playbooks in domain
        const [playbookCount] = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(playbookLibrary)
          .where(eq(playbookLibrary.domainId, domain.id));

        // Count completed drills for this organization in this domain
        const [drillCount] = await db
          .select({ count: sql<number>`count(DISTINCT ${practiceDrills.playbookId})::int` })
          .from(practiceDrills)
          .leftJoin(playbookLibrary, eq(practiceDrills.playbookId, playbookLibrary.id))
          .where(
            sql`${practiceDrills.organizationId} = ${organizationId} AND ${practiceDrills.status} = 'completed' AND ${playbookLibrary.domainId} = ${domain.id}`
          );

        // Count real activations for this organization in this domain
        const [activationCount] = await db
          .select({ count: sql<number>`count(DISTINCT ${playbookActivations.playbookId})::int` })
          .from(playbookActivations)
          .leftJoin(playbookLibrary, eq(playbookActivations.playbookId, playbookLibrary.id))
          .where(
            sql`${playbookActivations.organizationId} = ${organizationId} AND ${playbookLibrary.domainId} = ${domain.id}`
          );

        const totalPlaybooks = playbookCount?.count || 0;
        const preparedPlaybooks = Math.min(
          totalPlaybooks,
          (drillCount?.count || 0) + (activationCount?.count || 0)
        );
        const coveragePercentage = totalPlaybooks > 0 ? (preparedPlaybooks / totalPlaybooks) * 100 : 0;

        return {
          domain: domain.name,
          domainCode: domain.code,
          totalPlaybooks,
          preparedPlaybooks,
          coveragePercentage: Math.round(coveragePercentage),
          color: domain.color,
        };
      })
    );

    // Calculate overall coverage
    const totalPlaybooks = coverage.reduce((sum, d) => sum + d.totalPlaybooks, 0);
    const totalPrepared = coverage.reduce((sum, d) => sum + d.preparedPlaybooks, 0);
    const overallCoverage = totalPlaybooks > 0 ? Math.round((totalPrepared / totalPlaybooks) * 100) : 0;

    res.json({
      overallCoverage,
      domainCoverage: coverage,
      totalPlaybooks,
      preparedPlaybooks: totalPrepared,
      gapCount: totalPlaybooks - totalPrepared,
    });
  } catch (error) {
    console.error('Error calculating preparedness coverage:', error);
    res.status(500).json({ error: 'Failed to calculate preparedness coverage' });
  }
});

/**
 * GET /api/playbook-library/activations/:organizationId
 * Get all playbook activations for an organization
 */
playbookLibraryRouter.get('/activations/:organizationId', async (req, res) => {
  try {
    const { organizationId } = req.params;

    const activations = await db
      .select({
        activation: playbookActivations,
        playbook: playbookLibrary,
        domain: playbookDomains,
      })
      .from(playbookActivations)
      .leftJoin(playbookLibrary, eq(playbookActivations.playbookId, playbookLibrary.id))
      .leftJoin(playbookDomains, eq(playbookLibrary.domainId, playbookDomains.id))
      .where(eq(playbookActivations.organizationId, organizationId))
      .orderBy(desc(playbookActivations.activatedAt));

    res.json(activations);
  } catch (error) {
    console.error('Error fetching activations:', error);
    res.status(500).json({ error: 'Failed to fetch playbook activations' });
  }
});

/**
 * POST /api/playbook-library/activations
 * Create a new playbook activation (when a playbook is triggered)
 */
playbookLibraryRouter.post('/activations', async (req, res) => {
  try {
    const {
      organizationId,
      playbookId,
      activatedBy,
      activationReason,
      situationSummary,
      triggerEventId,
    } = req.body;

    const [activation] = await db
      .insert(playbookActivations)
      .values({
        organizationId,
        playbookId,
        activatedBy,
        activationReason,
        situationSummary,
        triggerEventId,
      })
      .returning();

    res.json(activation);
  } catch (error) {
    console.error('Error creating activation:', error);
    res.status(500).json({ error: 'Failed to create playbook activation' });
  }
});

/**
 * GET /api/playbook-library/ai-suggestions/:organizationId
 * Get AI optimization suggestions for an organization
 */
playbookLibraryRouter.get('/ai-suggestions/:organizationId', async (req, res) => {
  try {
    const { organizationId } = req.params;
    const { status } = req.query;

    // Build WHERE conditions
    const whereConditions = [eq(aiOptimizationSuggestions.organizationId, organizationId)];
    if (status) {
      whereConditions.push(eq(aiOptimizationSuggestions.status, status as string));
    }

    const suggestions = await db
      .select({
        suggestion: aiOptimizationSuggestions,
        playbook: playbookLibrary,
      })
      .from(aiOptimizationSuggestions)
      .leftJoin(playbookLibrary, eq(aiOptimizationSuggestions.playbookId, playbookLibrary.id))
      .where(sql`${sql.join(whereConditions, sql.raw(' AND '))}`)
      .orderBy(desc(aiOptimizationSuggestions.generatedAt));

    res.json(suggestions);
  } catch (error) {
    console.error('Error fetching AI suggestions:', error);
    res.status(500).json({ error: 'Failed to fetch AI suggestions' });
  }
});

/**
 * PATCH /api/playbook-library/ai-suggestions/:suggestionId
 * Update AI suggestion status (accept, reject, etc.)
 */
playbookLibraryRouter.patch('/ai-suggestions/:suggestionId', async (req, res) => {
  try {
    const { suggestionId } = req.params;
    const { status, reviewedBy } = req.body;

    const [updated] = await db
      .update(aiOptimizationSuggestions)
      .set({
        status,
        reviewedBy,
        reviewedAt: new Date(),
        implementedAt: status === 'accepted' ? new Date() : undefined,
      })
      .where(eq(aiOptimizationSuggestions.id, suggestionId))
      .returning();

    res.json(updated);
  } catch (error) {
    console.error('Error updating suggestion:', error);
    res.status(500).json({ error: 'Failed to update suggestion' });
  }
});

/**
 * PATCH /api/playbook-library/:playbookId/customize
 * Save playbook customizations for an organization
 */
playbookLibraryRouter.patch('/:playbookId/customize', async (req, res) => {
  try {
    const { playbookId } = req.params;
    const { organizationId, customizations } = req.body;

    // For now, update the playbook library entry with customized fields
    // In a production system, you might want a separate playbookCustomizations table
    // to preserve the original template while storing org-specific modifications
    
    const updateData: any = {};
    
    // Map customization fields to database columns
    if (customizations.severityScore !== undefined) {
      updateData.severityScore = customizations.severityScore;
    }
    if (customizations.timeSensitivity !== undefined) {
      updateData.timeSensitivity = customizations.timeSensitivity;
    }
    if (customizations.activationFrequencyTier !== undefined) {
      updateData.activationFrequencyTier = customizations.activationFrequencyTier;
    }
    if (customizations.triggerCriteria !== undefined) {
      updateData.triggerCriteria = customizations.triggerCriteria;
    }
    if (customizations.triggerDataSources !== undefined) {
      updateData.triggerDataSources = customizations.triggerDataSources;
    }
    if (customizations.tier1Stakeholders !== undefined) {
      updateData.tier1Stakeholders = customizations.tier1Stakeholders;
    }
    if (customizations.tier2Stakeholders !== undefined) {
      updateData.tier2Stakeholders = customizations.tier2Stakeholders;
    }
    if (customizations.tier3Stakeholders !== undefined) {
      updateData.tier3Stakeholders = customizations.tier3Stakeholders;
    }
    if (customizations.externalPartners !== undefined) {
      updateData.externalPartners = customizations.externalPartners;
    }
    if (customizations.preApprovedBudget !== undefined) {
      updateData.preApprovedBudget = String(customizations.preApprovedBudget);
    }
    if (customizations.budgetApprovalRequired !== undefined) {
      updateData.budgetApprovalRequired = customizations.budgetApprovalRequired;
    }
    if (customizations.vendorContracts !== undefined) {
      updateData.vendorContracts = customizations.vendorContracts;
    }
    if (customizations.targetResponseSpeed !== undefined) {
      updateData.targetResponseSpeed = customizations.targetResponseSpeed;
    }
    if (customizations.targetStakeholderReach !== undefined) {
      updateData.targetStakeholderReach = String(customizations.targetStakeholderReach);
    }
    if (customizations.outcomeMetrics !== undefined) {
      updateData.outcomeMetrics = customizations.outcomeMetrics;
    }

    updateData.updatedAt = new Date();

    const [updated] = await db
      .update(playbookLibrary)
      .set(updateData)
      .where(eq(playbookLibrary.id, playbookId))
      .returning();

    res.json(updated);
  } catch (error) {
    console.error('Error saving playbook customizations:', error);
    res.status(500).json({ error: 'Failed to save playbook customizations' });
  }
});
