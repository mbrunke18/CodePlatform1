import { Server as SocketIOServer } from 'socket.io';
import { Server as HTTPServer } from 'http';

interface AcknowledgmentData {
  stakeholderId: string;
  stakeholderName: string;
  acknowledgedAt: Date;
  responseTimeMinutes: number;
}

interface CoordinationCompleteMetrics {
  coordinationTimeMinutes: number;
  acknowledgedCount: number;
  totalStakeholders: number;
  acknowledgmentRate: number;
}

interface TaskUpdateData {
  taskId: string;
  status: string;
  completedAt?: Date;
}

class WebSocketService {
  private io: SocketIOServer | null = null;

  initialize(httpServer: HTTPServer): void {
    this.io = new SocketIOServer(httpServer, {
      cors: {
        origin: '*',
        methods: ['GET', 'POST'],
        credentials: true,
      },
      path: '/socket.io/',
    });

    this.io.on('connection', (socket) => {
      console.log(`✓ WebSocket client connected: ${socket.id}`);

      // Join execution instance room
      socket.on('join-execution', (executionInstanceId: string) => {
        socket.join(`execution-${executionInstanceId}`);
        console.log(`Client ${socket.id} joined execution-${executionInstanceId}`);
        
        // Acknowledge join
        socket.emit('execution-joined', { executionInstanceId });
      });

      // Leave execution instance room
      socket.on('leave-execution', (executionInstanceId: string) => {
        socket.leave(`execution-${executionInstanceId}`);
        console.log(`Client ${socket.id} left execution-${executionInstanceId}`);
      });

      socket.on('disconnect', () => {
        console.log(`Client disconnected: ${socket.id}`);
      });
    });

    console.log('✓ WebSocket server initialized');
  }

  /**
   * Broadcast stakeholder acknowledgment to all clients watching this execution
   */
  broadcastAcknowledgment(
    executionInstanceId: string,
    data: AcknowledgmentData
  ): void {
    if (!this.io) {
      console.warn('WebSocket not initialized, cannot broadcast acknowledgment');
      return;
    }

    const room = `execution-${executionInstanceId}`;
    this.io.to(room).emit('stakeholder-acknowledged', {
      ...data,
      timestamp: new Date().toISOString(),
    });

    console.log(`📡 Broadcast acknowledgment to ${room}:`, data.stakeholderName);
  }

  /**
   * Broadcast coordination completion to all clients watching this execution
   */
  broadcastCoordinationComplete(
    executionInstanceId: string,
    metrics: CoordinationCompleteMetrics
  ): void {
    if (!this.io) {
      console.warn('WebSocket not initialized, cannot broadcast completion');
      return;
    }

    const room = `execution-${executionInstanceId}`;
    this.io.to(room).emit('coordination-complete', {
      ...metrics,
      timestamp: new Date().toISOString(),
      executionInstanceId,
    });

    console.log(`🎉 Broadcast coordination complete to ${room}`);
  }

  /**
   * Broadcast task update to all clients watching this execution
   */
  broadcastTaskUpdate(executionInstanceId: string, task: TaskUpdateData): void {
    if (!this.io) {
      console.warn('WebSocket not initialized, cannot broadcast task update');
      return;
    }

    const room = `execution-${executionInstanceId}`;
    this.io.to(room).emit('task-updated', {
      ...task,
      timestamp: new Date().toISOString(),
    });

    console.log(`📋 Broadcast task update to ${room}:`, task.taskId);
  }

  /**
   * Broadcast notification sent event
   */
  broadcastNotificationSent(
    executionInstanceId: string,
    notification: { id: string; recipientId: string; sentAt: Date }
  ): void {
    if (!this.io) {
      console.warn('WebSocket not initialized, cannot broadcast notification');
      return;
    }

    const room = `execution-${executionInstanceId}`;
    this.io.to(room).emit('notification-sent', {
      ...notification,
      timestamp: new Date().toISOString(),
    });

    console.log(`📬 Broadcast notification sent to ${room}`);
  }

  /**
   * Get connection status
   */
  isInitialized(): boolean {
    return this.io !== null;
  }
}

export const wsService = new WebSocketService();
