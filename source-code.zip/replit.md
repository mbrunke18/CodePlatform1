# M - Strategic Execution Operating System

## Overview
M is the Strategic Execution Operating System designed for Fortune 1000 companies. Its primary purpose is to revolutionize strategic execution by dramatically reducing coordinated response times, leveraging AI-driven trigger monitoring and an extensive library of 148 strategic playbooks across 8 domains. M operates through four distinct phases: PREPARE, MONITOR, EXECUTE, and LEARN, serving as the execution layer for strategic velocity. This enables rapid market response, efficient opportunity capture, and effective threat mitigation. The platform fosters a human-AI partnership, where AI monitors and recommends, while human executives define playbooks, approve activations, and make final decisions. A real activation orchestration engine ensures automatic execution and stakeholder coordination.

## User Preferences
- Preferred communication style: Simple, everyday language
- Valued prioritization approach with phase-by-phase implementation
- Maintain core product vision of human-AI partnership for strategic velocity
- Executive professional language required across UI/UX

## Brand Messaging (Dec 2024)
**Core Tagline:** "Success Favors the Prepared"
- Chosen over "Growth favors..." because M covers both offensive (growth, opportunities) AND defensive (risk mitigation, crisis response) use cases
- "Success" encompasses the full value proposition

**Full Value Statement:**
"M is the Strategic Execution Operating System that fundamentally changes how Fortune 1000 leaders work—replacing reactive scrambles with coordinated precision, turning emerging opportunities into decisive action, and transforming risk into competitive advantage. Born from the split-second discipline that wins championships, built for the moments that define companies."

**Messaging Locations:**
- Homepage hero section
- Investor Presentation (Slide 2 - Mission)
- New User Journey (Welcome step)
- Demo Hub intro
- Our Story closing CTA ("Success Favors the Prepared. Are You?")

## System Architecture
M operates on a 4-phase methodology (PREPARE, MONITOR, EXECUTE, LEARN) to facilitate a human-AI partnership where AI handles monitoring, pattern detection, recommendations, and learning, while executives maintain decision-making control. The core philosophy is augmentation, not automation, ensuring human oversight.

**UI/UX Decisions:**
- **Design:** Modern, enterprise-grade interface focused on decision velocity and human-AI collaboration.
- **Theme:** Full dark/light mode support with localStorage persistence and WCAG AAA contrast compliance.
- **Navigation:** Features a sidebar with collapsible 4-phase sections (PREPARE, MONITOR, EXECUTE, LEARN) for platform pages and a light topbar navigation for marketing pages.
- **Branding:** Consistent "M - Strategic Execution Operating System" branding throughout the application.
- **Design System:** Established with 60+ utility classes for typography, backgrounds, cards, metrics, status indicators, badges, and layout.

**Technical Implementations & Feature Specifications:**
- **Phases:**
    - **PREPARE:** Users build and customize playbooks from 148 templates across 8 strategic domains.
    - **MONITOR:** AI continuously monitors 12 intelligence signals for trigger conditions, recommending playbook activation. Includes a Signal Control Center UI with 16 intelligence signal categories and 92 data points, a Visual Trigger Builder, and an Alert Command Center.
    - **EXECUTE:** Orchestrates a 12-minute coordinated response upon activation, utilizing pre-approved budgets and enterprise integrations. Features a Command Center for real-time strategic execution coordination.
    - **LEARN:** Captures outcomes, conducts AI-powered analysis, and suggests playbook refinements. Includes a Signal-to-Playbook Mapper.
- **Authentication:** Replit OIDC integration with session management (7-day TTL) using PostgreSQL, `requireAuth()` and `optionalAuth()` middleware.
- **Dashboard Metrics:** Live metrics display for active scenarios, teams coordinating, on-track percentage, weak signals, and Oracle patterns.
- **Scenario Library:** Real-time search/filtering, instant playbook search, category browsing, and featured playbooks.
- **Portal Homepage:** Rebuilt as a clean entry portal with hero section, stats bar, 4-Phase Navigation Grid, Quick Access cards (Future Gym, What-If Analyzer, Living Playbooks), and a consistent footer.
- **Intelligence Signals Framework:** Comprehensive backend service for CRUD operations on data sources, triggers, alerts, and weak signals, with a playbook recommendation engine. API routes for catalog, triggers, alerts, data sources, recommendations, and simulation.
- **Demos:** Three complementary demo experiences: Intelligence Signals Demo (guided scenarios), Executive Simulation Demo (immersive role-play), and Product Tour (cinematic marketing video walkthrough with 14 scenes at /product-tour).
- **New User Journey:** Complete 7-step guided onboarding experience at /start, /welcome, or /new-user-journey:
    1. **Welcome:** Value proposition and time-to-value promise (15 min to first playbook)
    2. **Organization Profile:** Company name, industry selection (8 industries), employee count, executive role
    3. **Strategic Priorities:** Select top priorities to seed playbook recommendations
    4. **Playbook Selection:** Industry-personalized recommendations from 148 playbook library
    5. **Signal Configuration:** Quick-toggle to enable relevant intelligence signals with default thresholds
    6. **Success Metrics:** Set FRI target, velocity target, and coverage goals
    7. **Command Center Preview:** Live simulation showing 12-minute coordinated response ("aha moment")
    - Persists configuration via API upon completion: departments, triggers, success metrics
    - Homepage CTA "Get Started Free" links to this journey
- **Investor Presentation:** Full-featured presenter mode at /investor-presentation with 5-act structure (Hook, Problem & Market, Product Deep Dive, Proof & Traction, Growth & Ask), keyboard navigation, speaker notes panel, act-based quick navigation, and live demo transitions.

**System Design Choices:**
- **Frontend**: React 18, TypeScript, Vite, Radix UI, shadcn/ui, Tailwind CSS, TanStack Query v5, Wouter, React Hook Form, Zod.
- **Backend**: Node.js, Express.js, TypeScript.
- **Database**: PostgreSQL (Neon serverless) with Drizzle ORM.
- **Authentication**: Replit OIDC with Passport.js and Express sessions.
- **Real-time**: Socket.IO WebSocket server.
- **AI Services**: Primarily OpenAI GPT-4o.

## External Dependencies
- **AI Services**: OpenAI GPT-4o
- **Database Services**: Neon PostgreSQL (Replit built-in) → RDS PostgreSQL (AWS production)
- **Authentication**: Replit OIDC (dev) → AWS Cognito (production)
- **Enterprise Integrations**: Salesforce, HubSpot, ServiceNow, Jira, Slack, Microsoft Teams, Google Workspace, Outlook/Exchange, AWS CloudWatch, Workday, Okta, Microsoft Active Directory

## Integration Architecture (Critical for Platform Power)
M's true value comes from being the **orchestration layer** that connects enterprise systems for real-time intelligence and coordinated execution. Integrations serve three core purposes:

**1. Intelligence Gathering (MONITOR Phase)**
- Pull real-time data for trigger detection
- Feed the 92 data points across 16 signal categories
- Sources: CRMs, project management, financial systems, HR platforms

**2. Execution Orchestration (EXECUTE Phase)**
- Push coordinated actions across stakeholder systems
- Automate task creation, notifications, calendar blocks
- Targets: Jira, Slack/Teams, calendars, email systems

**3. Learning & Reporting (LEARN Phase)**
- Aggregate outcomes from connected systems
- Feed institutional memory with real execution data
- Sources: All connected platforms for outcome tracking

**Available Integrations (Ready to Connect):**
| Integration | Purpose | Phase |
|-------------|---------|-------|
| Jira | Project/task orchestration, issue tracking | EXECUTE |
| Google Calendar | Executive availability, response coordination | EXECUTE |
| Gmail | Stakeholder notifications, escalations | EXECUTE |
| Google Docs | Playbook documentation, briefing generation | PREPARE/LEARN |
| Google Sheets | Data import, KPI tracking, reporting | MONITOR/LEARN |
| Google Drive | Document management, briefing distribution | ALL |
| SendGrid | Transactional emails, alert notifications | EXECUTE |
| Twilio | SMS alerts, voice escalations for critical triggers | EXECUTE |

**Integration Priority for Enterprise Value:**
1. **Tier 1 (Immediate Value):** Jira, Slack/Teams, Email (SendGrid/Gmail)
2. **Tier 2 (Enhanced Intelligence):** Google Workspace, Calendar sync
3. **Tier 3 (Full Orchestration):** Salesforce, ServiceNow, Workday, AWS CloudWatch

## Platform Consolidation (Dec 2024)

**Consolidated Entry Points:** Reduced 40+ overlapping pages to ~10-12 core experiences:

1. **Executive Dashboard** (`/executive-dashboard`)
   - Unified hub with 5 tabs: Overview, Readiness, Velocity, Preparedness, Intelligence
   - Redirects from: /dashboard, /future-readiness, /preparedness-report, /scorecard, /executive-scorecard, /decision-velocity
   
2. **Demo Hub** (`/demo-hub`)
   - Unified demo center with persona/industry filters
   - Features demos, Product Tour, Executive Simulation, Live Activation
   - Redirects from: /demo, /demo-selector, /demos, /industry-demos
   
3. **Intelligence Control Center** (`/intelligence`)
   - Unified entry point for all intelligence features
   - Links to AI Intelligence Hub, Signal Intelligence, Foresight Radar, Trigger Management
   - Quick stats for data points, signal categories, weak signals, active patterns

4. **Playbook Library** (`/playbook-library`)
   - 148 strategic playbooks across 8 domains
   - Search, filter, and browse capabilities
   - Redirects from: /scenarios, /templates, /business-scenarios

**Navigation Updates:**
- StandardNav MONITOR section now features Intelligence Control Center
- Footer updated with Demo Hub and Executive Dashboard links
- NavigationBar Product dropdown updated with consolidated entry points

## Enterprise Readiness Status (Updated Dec 2024)

**Production Readiness Improvements Made:**
1. **Customer Context Provider** - Added `CustomerProvider` to dynamically load organization data across all pages
2. **Onboarding Wizard** - Full 4-step wizard with API persistence for org setup, triggers, playbooks, and metrics
3. **Configuration Pages Wired** - OrganizationSetup, PlaybookCustomization, and SuccessMetricsConfiguration now use React Query mutations
4. **Mock Data Elimination** - Removed hardcoded stakeholder names, prompting users to configure their own data
5. **Integration Navigation** - Enhanced visibility of Ecosystem Connectors (15+ available) and Integration Hub in navigation
6. **Platform Consolidation** - Unified Executive Dashboard, Demo Hub, and Intelligence Control Center as primary entry points

**Integration Status:**
- Jira connector available but not yet configured (user can set up via Replit integrations panel)
- For manual integration setup, store API credentials as secrets: `JIRA_API_TOKEN`, `JIRA_BASE_URL`, `JIRA_EMAIL`

**Remaining Enterprise Gaps:**
- Some demo pages still contain industry-specific sample data (acceptable for demos)
- Integration credentials need to be configured per customer deployment
- Consider adding empty state components that guide users to configuration

## AWS Production Deployment
- **Containerization**: Docker (Dockerfile included)
- **Container Orchestration**: ECS Fargate
- **Frontend**: CloudFront + S3
- **API Gateway**: Application Load Balancer (ALB)
- **Database**: RDS PostgreSQL (Multi-AZ)
- **Caching**: ElastiCache Redis
- **Secrets Management**: AWS Secrets Manager
- **CI/CD**: CodePipeline → CodeBuild → CodeDeploy
- **Monitoring**: CloudWatch (logs, metrics, alarms)
- **DNS**: Route 53
- **Security**: WAF, Security Groups, SSL/TLS with ACM
- **Deployment Guide**: See AWS_DEPLOYMENT_GUIDE.md for comprehensive setup instructions
- **Quick Deploy Script**: `./scripts/deploy-to-aws.sh` for automated builds, tests, and pushes to ECR