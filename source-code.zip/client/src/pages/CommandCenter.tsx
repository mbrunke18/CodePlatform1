import { useState, useEffect } from 'react';
import PageLayout from '@/components/layout/PageLayout';
import { useDynamicStrategy } from '@/contexts/DynamicStrategyContext';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import OnboardingTrigger from '@/components/onboarding/OnboardingTrigger';
import { 
  Activity, 
  Zap, 
  Users, 
  Target, 
  TrendingUp, 
  AlertTriangle,
  PlayCircle,
  Pause,
  Radio,
  DollarSign,
  Clock,
  CheckCircle2,
  ArrowRight,
  Bell,
  Shield,
  Radar
} from 'lucide-react';

interface CoordinationEvent {
  id: string;
  time: string;
  team: string;
  action: string;
  status: 'completed' | 'in-progress' | 'pending';
}

interface SignalAlert {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  source: string;
  time: string;
}

export default function CommandCenter() {
  const { 
    readiness, 
    activeScenarios, 
    weakSignals, 
    oraclePatterns,
    continuousMode,
    teamsCoordinating,
    percentOnTrack,
    isLoading
  } = useDynamicStrategy();

  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const coordinationTimeline: CoordinationEvent[] = [
    { id: '1', time: '2 min ago', team: 'Legal', action: 'Approved crisis communication draft', status: 'completed' },
    { id: '2', time: '5 min ago', team: 'Communications', action: 'Drafting stakeholder message', status: 'in-progress' },
    { id: '3', time: '8 min ago', team: 'Operations', action: 'Activated supply chain backup', status: 'completed' },
    { id: '4', time: '10 min ago', team: 'Executive', action: 'CEO briefing scheduled', status: 'pending' },
    { id: '5', time: '12 min ago', team: 'IT Security', action: 'System isolation complete', status: 'completed' },
  ];

  const signalAlerts: SignalAlert[] = [
    { id: '1', severity: 'critical', title: 'Competitor acquisition announced', source: 'Market Intel', time: '1 min ago' },
    { id: '2', severity: 'high', title: 'Supply chain disruption - Region APAC', source: 'Operations Monitor', time: '15 min ago' },
    { id: '3', severity: 'medium', title: 'Social sentiment shift detected', source: 'Echo Analytics', time: '32 min ago' },
    { id: '4', severity: 'low', title: 'Regulatory update - GDPR amendment', source: 'Compliance Watch', time: '1 hr ago' },
  ];

  const severityColors = {
    critical: 'bg-red-500 text-white',
    high: 'bg-orange-500 text-white',
    medium: 'bg-amber-500 text-white',
    low: 'bg-blue-500 text-white'
  };

  // Fetch ROI metrics
  const { data: roiReport } = useQuery<any>({
    queryKey: ['/api/roi/report'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-950 dark:via-slate-900 dark:to-blue-950 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-4">
            <div className="h-12 bg-slate-200 dark:bg-slate-800 rounded"></div>
            <div className="h-64 bg-slate-200 dark:bg-slate-800 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <PageLayout>
      {/* Header with Key Metrics */}
      <div className="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-950 dark:via-slate-900 dark:to-blue-950 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-title">
                  Command Center
                </h1>
                <OnboardingTrigger pageId="command-center" autoStart={true} />
              </div>
              <p className="text-body flex items-center gap-2">
                Real-time strategic execution coordination and control
                <Badge variant="outline" className="text-xs">
                  <Clock className="w-3 h-3 mr-1" />
                  {currentTime.toLocaleTimeString()}
                </Badge>
              </p>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                  {activeScenarios.length}
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400 uppercase tracking-wide">
                  Active Scenarios
                </div>
              </div>
              <div className="h-12 w-px bg-slate-300 dark:bg-slate-700"></div>
              <div className="text-center">
                <div className="text-3xl font-bold text-violet-600 dark:text-violet-400">
                  {teamsCoordinating}
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400 uppercase tracking-wide">
                  Teams Coordinating
                </div>
              </div>
              <div className="h-12 w-px bg-slate-300 dark:bg-slate-700"></div>
              <div className="text-center">
                <div className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">
                  {percentOnTrack}%
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400 uppercase tracking-wide">
                  On Track
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-8 space-y-8">
        {/* Active Scenarios */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Active Scenarios</h2>
            <Button data-testid="button-launch-scenario">
              <PlayCircle className="w-4 h-4 mr-2" />
              Launch New Scenario
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeScenarios.map((scenario) => (
              <Card key={scenario.id} className="border-l-4 border-l-blue-500" data-testid={`card-scenario-${scenario.id}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{scenario.name}</CardTitle>
                      <CardDescription>
                        {scenario.teamsInvolved} teams coordinating
                      </CardDescription>
                    </div>
                    <Badge variant={scenario.status === 'active' ? 'default' : 'secondary'}>
                      {scenario.status === 'active' && <Radio className="w-3 h-3 mr-1 animate-pulse" />}
                      {scenario.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">Progress</span>
                      <span className="font-semibold">{scenario.progress}%</span>
                    </div>
                    <Progress value={scenario.progress} />
                    <Button variant="outline" size="sm" className="w-full mt-2" data-testid={`button-view-${scenario.id}`}>
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* ROI & Value Demonstration */}
        {roiReport && (
          <Card className="border-2 border-emerald-500 dark:border-emerald-700 bg-emerald-50 dark:bg-emerald-950/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-600" />
                Enterprise Value Realized
              </CardTitle>
              <CardDescription>
                Cumulative impact from strategic executions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-3 bg-white dark:bg-slate-800 rounded-lg border border-emerald-200 dark:border-emerald-900">
                  <div className="text-xs text-slate-600 dark:text-slate-400 mb-1">Total Value</div>
                  <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                    ${(roiReport.cumulativeValue / 1000000).toFixed(1)}M
                  </div>
                </div>
                <div className="p-3 bg-white dark:bg-slate-800 rounded-lg border border-emerald-200 dark:border-emerald-900">
                  <div className="text-xs text-slate-600 dark:text-slate-400 mb-1">Executions</div>
                  <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                    {roiReport.totalExecutions}
                  </div>
                </div>
                <div className="p-3 bg-white dark:bg-slate-800 rounded-lg border border-emerald-200 dark:border-emerald-900">
                  <div className="text-xs text-slate-600 dark:text-slate-400 mb-1">Avg Velocity</div>
                  <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                    {roiReport.avgTimeToActivate}m
                  </div>
                </div>
                <div className="p-3 bg-white dark:bg-slate-800 rounded-lg border border-emerald-200 dark:border-emerald-900">
                  <div className="text-xs text-slate-600 dark:text-slate-400 mb-1">Efficiency</div>
                  <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                    {roiReport.efficiency}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Real-time Coordination & Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Coordination Timeline */}
          <Card data-testid="card-coordination-timeline">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-violet-600" />
                Coordination Timeline
              </CardTitle>
              <CardDescription>
                Live team coordination across active scenarios
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {coordinationTimeline.map((event) => (
                  <div 
                    key={event.id} 
                    className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700"
                    data-testid={`timeline-event-${event.id}`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      event.status === 'completed' ? 'bg-emerald-100 dark:bg-emerald-900' :
                      event.status === 'in-progress' ? 'bg-blue-100 dark:bg-blue-900' :
                      'bg-slate-200 dark:bg-slate-700'
                    }`}>
                      {event.status === 'completed' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      ) : event.status === 'in-progress' ? (
                        <Radio className="w-4 h-4 text-blue-600 dark:text-blue-400 animate-pulse" />
                      ) : (
                        <Clock className="w-4 h-4 text-slate-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm text-slate-900 dark:text-white">
                          {event.team}
                        </span>
                        <span className="text-xs text-slate-500">{event.time}</span>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400 truncate">
                        {event.action}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Signal Alerts */}
          <Card data-testid="card-signal-alerts">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-amber-600" />
                Signal Alerts
              </CardTitle>
              <CardDescription>
                Real-time intelligence from 12 monitoring sources
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {signalAlerts.map((alert) => (
                  <div 
                    key={alert.id} 
                    className="flex items-start gap-3 p-3 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
                    data-testid={`signal-alert-${alert.id}`}
                  >
                    <Badge className={`${severityColors[alert.severity]} text-xs px-2`}>
                      {alert.severity.toUpperCase()}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-slate-900 dark:text-white">
                        {alert.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-slate-500">{alert.source}</span>
                        <span className="text-xs text-slate-400">•</span>
                        <span className="text-xs text-slate-500">{alert.time}</span>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="flex-shrink-0">
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Grid: Readiness + Weak Signals + Oracle */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Future Readiness */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                Future Readiness Index™
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <div className="text-5xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                  {readiness.overall.toFixed(1)}%
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Overall Readiness Score
                </p>
              </div>
              <div className="space-y-3">
                {Object.entries(readiness).filter(([key]) => key !== 'overall').map(([key, value]) => (
                  <div key={key}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="capitalize text-slate-700 dark:text-slate-300">{key}</span>
                      <span className="font-semibold">{value}%</span>
                    </div>
                    <Progress value={value} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Weak Signals */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                Weak Signals Detected
              </CardTitle>
              <CardDescription>
                {weakSignals.length} signals detected
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {weakSignals.slice(0, 5).map((signal) => (
                  <div 
                    key={signal.id} 
                    className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-900"
                    data-testid={`weak-signal-${signal.id}`}
                  >
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="font-semibold text-sm text-slate-900 dark:text-white">
                        {signal.title}
                      </h4>
                      <Badge variant="outline" className="text-xs">
                        {signal.confidence}%
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {signal.source} • {signal.category}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Oracle Patterns */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-violet-600" />
                Oracle Intelligence
              </CardTitle>
              <CardDescription>
                {oraclePatterns.length} patterns recognized
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {oraclePatterns.map((pattern) => (
                  <div 
                    key={pattern.id} 
                    className="p-3 bg-violet-50 dark:bg-violet-950/30 rounded-lg border border-violet-200 dark:border-violet-900"
                    data-testid={`oracle-pattern-${pattern.id}`}
                  >
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="font-semibold text-sm text-slate-900 dark:text-white">
                        {pattern.name}
                      </h4>
                      <Badge variant="outline" className="text-xs">
                        {pattern.accuracy}%
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {pattern.signals} signals • {pattern.trend}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Continuous Mode Status */}
        <Card className="border-2 border-blue-500 dark:border-blue-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  Continuous Operations Mode
                </CardTitle>
                <CardDescription>
                  Always-on strategic monitoring and coordination
                </CardDescription>
              </div>
              <Button 
                variant={continuousMode.enabled ? "destructive" : "default"}
                data-testid="button-toggle-continuous-mode"
              >
                {continuousMode.enabled ? (
                  <>
                    <Pause className="w-4 h-4 mr-2" />
                    Pause
                  </>
                ) : (
                  <>
                    <PlayCircle className="w-4 h-4 mr-2" />
                    Activate
                  </>
                )}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-1">
                  {continuousMode.enabled ? 'ON' : 'OFF'}
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400">Status</div>
              </div>
              <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                <div className="text-3xl font-bold text-violet-600 dark:text-violet-400 mb-1">
                  {continuousMode.tasksScheduled}
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400">Tasks Scheduled</div>
              </div>
              <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                <div className="text-3xl font-bold text-emerald-600 dark:text-emerald-400 mb-1">
                  {continuousMode.nextRun ? new Date(continuousMode.nextRun).toLocaleTimeString() : '--'}
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400">Next Run</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  );
}
