import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  Play,
  Clock,
  Target,
  Zap,
  BookOpen,
  Radar,
  Radio,
  Dumbbell,
  BarChart3,
  Shield,
  Users,
  CheckCircle,
  Sparkles,
  AlertTriangle,
  Briefcase
} from "lucide-react";
import { useLocation } from "wouter";
import StandardNav from "@/components/layout/StandardNav";
import Footer from "@/components/layout/Footer";

export default function Homepage() {
  const [, setLocation] = useLocation();

  const phases = [
    {
      id: 'prepare',
      phase: 'PREPARE',
      title: 'Build Your Playbooks',
      description: 'Access 148 strategic playbooks across 8 domains. Customize for your organization, train your teams.',
      icon: BookOpen,
      color: 'from-violet-500 to-purple-600',
      borderColor: 'border-violet-200 hover:border-violet-400',
      bgColor: 'bg-violet-50 dark:bg-violet-950/20',
      iconBg: 'bg-violet-100 dark:bg-violet-900/30',
      iconColor: 'text-violet-600 dark:text-violet-400',
      features: ['148 Playbook Templates', 'Future Gym Training', 'What-If Analyzer'],
      primaryLink: '/playbook-library',
      primaryLabel: 'Browse Playbooks'
    },
    {
      id: 'monitor',
      phase: 'MONITOR',
      title: 'Detect Early Signals',
      description: 'AI continuously scans 12 intelligence sources for emerging threats and opportunities.',
      icon: Radar,
      color: 'from-blue-500 to-cyan-600',
      borderColor: 'border-blue-200 hover:border-blue-400',
      bgColor: 'bg-blue-50 dark:bg-blue-950/20',
      iconBg: 'bg-blue-100 dark:bg-blue-900/30',
      iconColor: 'text-blue-600 dark:text-blue-400',
      features: ['Foresight Radar', 'Weak Signal Detection', 'Trigger Monitoring'],
      primaryLink: '/foresight-radar',
      primaryLabel: 'View Radar'
    },
    {
      id: 'execute',
      phase: 'EXECUTE',
      title: 'Coordinate in 12 Minutes',
      description: 'Launch coordinated responses across all stakeholders. Real-time tracking and status updates.',
      icon: Radio,
      color: 'from-emerald-500 to-green-600',
      borderColor: 'border-emerald-200 hover:border-emerald-400',
      bgColor: 'bg-emerald-50 dark:bg-emerald-950/20',
      iconBg: 'bg-emerald-100 dark:bg-emerald-900/30',
      iconColor: 'text-emerald-600 dark:text-emerald-400',
      features: ['Command Center', 'Team Coordination', 'Progress Tracking'],
      primaryLink: '/command-center',
      primaryLabel: 'Launch Command Center'
    },
    {
      id: 'learn',
      phase: 'LEARN',
      title: 'Improve Continuously',
      description: 'AI analyzes every execution to refine playbooks. Your organization gets smarter over time.',
      icon: BarChart3,
      color: 'from-amber-500 to-orange-600',
      borderColor: 'border-amber-200 hover:border-amber-400',
      bgColor: 'bg-amber-50 dark:bg-amber-950/20',
      iconBg: 'bg-amber-100 dark:bg-amber-900/30',
      iconColor: 'text-amber-600 dark:text-amber-400',
      features: ['Dashboard', 'Living Playbooks', 'ROI Analytics'],
      primaryLink: '/executive-dashboard',
      primaryLabel: 'View Dashboard'
    }
  ];

  const stats = [
    { value: '148', label: 'Strategic Playbooks', icon: BookOpen },
    { value: '12 min', label: 'Coordination Time', icon: Clock },
    { value: '8', label: 'Strategic Domains', icon: Target },
    { value: '84.4%', label: 'Readiness Target', icon: Shield }
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950">
      <StandardNav />
      
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 px-6 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-40"></div>
        
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <Badge className="mb-6 bg-white/10 text-white border-white/20 px-4 py-1.5" data-testid="badge-hero">
            <Sparkles className="w-4 h-4 mr-2" />
            Strategic Execution Operating System
          </Badge>
          
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight" data-testid="heading-hero">
            Success Favors
            <span className="block bg-gradient-to-r from-blue-400 via-purple-400 to-emerald-400 bg-clip-text text-transparent">
              The Prepared
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-slate-300 mb-10 max-w-3xl mx-auto leading-relaxed" data-testid="text-hero-subtitle">
            M is the Strategic Execution Operating System that fundamentally changes how Fortune 1000 leaders work—replacing reactive scrambles with coordinated precision, turning emerging opportunities into decisive action, and transforming risk into competitive advantage. Born from the split-second discipline that wins championships, built for the moments that define companies.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg"
              onClick={() => setLocation('/start')}
              className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-semibold px-8 py-6 text-lg shadow-xl hover:shadow-2xl transition-all"
              data-testid="button-get-started"
            >
              <Zap className="mr-2 h-5 w-5" />
              Get Started Free
            </Button>
            <Button 
              size="lg"
              onClick={() => setLocation('/product-tour')}
              className="bg-white text-slate-900 hover:bg-slate-100 font-semibold px-8 py-6 text-lg shadow-xl hover:shadow-2xl transition-all"
              data-testid="button-watch-video"
            >
              <Play className="mr-2 h-5 w-5" />
              Watch Tour
            </Button>
          </div>
          <div className="mt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg"
              variant="link"
              onClick={() => setLocation('/executive-dashboard')}
              className="text-white/80 hover:text-white font-medium"
              data-testid="button-enter-platform"
            >
              Enter Platform →
            </Button>
            <span className="hidden sm:block text-slate-500">|</span>
            <Button 
              size="lg"
              variant="link"
              onClick={() => setLocation('/executive-simulation')}
              className="text-white/80 hover:text-white font-medium"
              data-testid="button-try-simulation"
            >
              Try Simulation →
            </Button>
            <span className="hidden sm:block text-slate-500">|</span>
            <Button 
              size="lg"
              variant="link"
              onClick={() => setLocation('/investor-presentation')}
              className="text-white/80 hover:text-white font-medium"
              data-testid="button-investor-deck"
            >
              <Briefcase className="w-4 h-4 mr-2" />
              Investors
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-8 bg-slate-50 dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center" data-testid={`stat-${index}`}>
                <div className="flex items-center justify-center gap-2 mb-1">
                  <stat.icon className="h-5 w-5 text-slate-500 dark:text-slate-400" />
                  <span className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">{stat.value}</span>
                </div>
                <span className="text-sm text-slate-600 dark:text-slate-400">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4-Phase Navigation Grid */}
      <section className="py-20 px-6 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4" data-testid="heading-phases">
              The M 4-Phase Operating System
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              A complete cycle from preparation to continuous improvement. Click any phase to explore.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {phases.map((phase) => (
              <Card 
                key={phase.id}
                className={`${phase.borderColor} ${phase.bgColor} cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 group`}
                onClick={() => setLocation(phase.primaryLink)}
                data-testid={`card-phase-${phase.id}`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`p-3 rounded-xl ${phase.iconBg}`}>
                      <phase.icon className={`h-6 w-6 ${phase.iconColor}`} />
                    </div>
                    <Badge variant="outline" className={`${phase.iconColor} border-current text-xs font-bold`}>
                      {phase.phase}
                    </Badge>
                  </div>
                  
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-slate-700 dark:group-hover:text-slate-200 transition-colors">
                    {phase.title}
                  </h3>
                  
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                    {phase.description}
                  </p>
                  
                  <ul className="space-y-2 mb-4">
                    {phase.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                        <CheckCircle className={`h-4 w-4 ${phase.iconColor}`} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    variant="ghost" 
                    className={`w-full justify-between ${phase.iconColor} hover:bg-white/50 dark:hover:bg-slate-800/50`}
                  >
                    {phase.primaryLabel}
                    <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="py-20 px-6 bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-6" data-testid="heading-value">
            Why Fortune 1000 Executives Choose M
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="text-center" data-testid="value-speed">
              <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center">
                <Zap className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">72 Hours → 12 Minutes</h3>
              <p className="text-slate-600 dark:text-slate-400">
                Compress coordination time from days to minutes. Faster response = better outcomes.
              </p>
            </div>
            
            <div className="text-center" data-testid="value-playbooks">
              <div className="w-16 h-16 mx-auto mb-4 bg-purple-100 dark:bg-purple-900/30 rounded-2xl flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">148 Battle-Tested Playbooks</h3>
              <p className="text-slate-600 dark:text-slate-400">
                From M&A to crisis response. Pre-mapped stakeholders, decision trees, communication templates.
              </p>
            </div>
            
            <div className="text-center" data-testid="value-ai">
              <div className="w-16 h-16 mx-auto mb-4 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl flex items-center justify-center">
                <Users className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Human-AI Partnership</h3>
              <p className="text-slate-600 dark:text-slate-400">
                AI monitors and recommends. You decide and execute. Augmentation, not automation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured: Executive Simulation Demo */}
      <section className="py-12 px-6 bg-gradient-to-r from-purple-600 via-blue-600 to-teal-500">
        <div className="max-w-5xl mx-auto">
          <Card 
            className="border-0 bg-white/10 backdrop-blur-sm cursor-pointer transition-all hover:bg-white/20 group"
            onClick={() => setLocation('/executive-simulation')}
            data-testid="card-simulation-demo-featured"
          >
            <CardContent className="p-8 flex flex-col md:flex-row items-center gap-6">
              <div className="p-4 bg-white/20 rounded-2xl">
                <Briefcase className="h-10 w-10 text-white" />
              </div>
              <div className="flex-1 text-center md:text-left">
                <Badge className="mb-2 bg-white/20 text-white border-white/30">Interactive Experience</Badge>
                <h3 className="text-2xl font-bold text-white mb-2">Executive Simulation Demo</h3>
                <p className="text-white/80">
                  Step into the shoes of a Fortune 500 CSO. Experience real-time signal detection, playbook activation, and 12-minute coordinated response across your executive team. This is exactly how M works in production.
                </p>
              </div>
              <Button 
                size="lg"
                className="bg-white text-purple-600 hover:bg-white/90 font-semibold"
                data-testid="button-try-simulation-featured"
              >
                Start Simulation
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Quick Access to Key Features */}
      <section className="py-16 px-6 bg-white dark:bg-slate-950">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Try M Today</h2>
            <p className="text-slate-600 dark:text-slate-400">Choose your experience level</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card 
              className="border-2 border-purple-200 dark:border-purple-800 hover:border-purple-400 dark:hover:border-purple-500 bg-purple-50 dark:bg-purple-950/20 cursor-pointer transition-all hover:shadow-lg group"
              onClick={() => setLocation('/executive-simulation')}
              data-testid="card-simulation-demo"
            >
              <CardContent className="p-6 flex items-center gap-4">
                <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-xl">
                  <Briefcase className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">Full Simulation</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Be the CSO for a day</p>
                </div>
                <ArrowRight className="h-5 w-5 text-slate-400 group-hover:text-purple-600 group-hover:translate-x-1 transition-all" />
              </CardContent>
            </Card>

            <Card 
              className="border-2 border-blue-200 dark:border-blue-800 hover:border-blue-400 dark:hover:border-blue-500 bg-blue-50 dark:bg-blue-950/20 cursor-pointer transition-all hover:shadow-lg group"
              onClick={() => setLocation('/intelligence-demo')}
              data-testid="card-signals-demo"
            >
              <CardContent className="p-6 flex items-center gap-4">
                <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-xl">
                  <AlertTriangle className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">Signals Demo</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Quick 12-min demo</p>
                </div>
                <ArrowRight className="h-5 w-5 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
              </CardContent>
            </Card>

            <Card 
              className="border-2 border-slate-200 dark:border-slate-800 hover:border-violet-400 dark:hover:border-violet-500 cursor-pointer transition-all hover:shadow-lg group"
              onClick={() => setLocation('/future-gym')}
              data-testid="card-future-gym"
            >
              <CardContent className="p-6 flex items-center gap-4">
                <div className="p-3 bg-amber-100 dark:bg-amber-900/30 rounded-xl">
                  <Dumbbell className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-white group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">Future Gym</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Practice crisis drills</p>
                </div>
                <ArrowRight className="h-5 w-5 text-slate-400 group-hover:text-violet-600 group-hover:translate-x-1 transition-all" />
              </CardContent>
            </Card>

            <Card 
              className="border-2 border-slate-200 dark:border-slate-800 hover:border-violet-400 dark:hover:border-violet-500 cursor-pointer transition-all hover:shadow-lg group"
              onClick={() => setLocation('/what-if-analyzer')}
              data-testid="card-what-if"
            >
              <CardContent className="p-6 flex items-center gap-4">
                <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-xl">
                  <Sparkles className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-white group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">What-If Analyzer</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Model any scenario</p>
                </div>
                <ArrowRight className="h-5 w-5 text-slate-400 group-hover:text-violet-600 group-hover:translate-x-1 transition-all" />
              </CardContent>
            </Card>

            <Card 
              className="border-2 border-slate-200 dark:border-slate-800 hover:border-violet-400 dark:hover:border-violet-500 cursor-pointer transition-all hover:shadow-lg group"
              onClick={() => setLocation('/living-playbooks')}
              data-testid="card-living-playbooks"
            >
              <CardContent className="p-6 flex items-center gap-4">
                <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl">
                  <Sparkles className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-white group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">Living Playbooks</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Self-improving strategies</p>
                </div>
                <ArrowRight className="h-5 w-5 text-slate-400 group-hover:text-violet-600 group-hover:translate-x-1 transition-all" />
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-r from-slate-900 to-slate-800">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6" data-testid="heading-cta">
            Ready to Transform Your Strategic Execution?
          </h2>
          <p className="text-xl text-slate-300 mb-8">
            Join Fortune 1000 executives who coordinate in minutes, not days.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg"
              onClick={() => setLocation('/contact')}
              className="bg-white text-slate-900 hover:bg-slate-100 font-semibold px-8 py-6 text-lg"
              data-testid="button-request-access"
            >
              Request Access
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg"
              variant="outline"
              onClick={() => setLocation('/our-story')}
              className="border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-6 text-lg"
              data-testid="button-learn-more"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
