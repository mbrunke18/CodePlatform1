import { useState, useEffect } from 'react';
import { updatePageMetadata } from '@/lib/seo';
import StandardNav from '@/components/layout/StandardNav';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import WhatIfAnalyzer from '@/components/demo/WhatIfAnalyzer';
import {
  User,
  Brain,
  Bell,
  Zap,
  Users,
  CheckCircle,
  ArrowRight,
  PlayCircle,
  TrendingUp,
  Shield,
  AlertTriangle,
  Target,
  Sparkles,
  Clock,
  BarChart3,
  ChevronRight
} from 'lucide-react';

type DemoPhase = 'setup' | 'monitoring' | 'alert' | 'decision' | 'execution' | 'learning' | 'results';

export default function InteractiveMasterDemo() {
  const [, setLocation] = useLocation();
  const [currentPhase, setCurrentPhase] = useState<DemoPhase>('setup');
  const [formData, setFormData] = useState({
    scenarioName: '',
    department: '',
    stakeholders: '',
    triggerThreshold: [70],
  });
  const [aiMonitoring, setAiMonitoring] = useState(false);
  const [currentMetric, setCurrentMetric] = useState(45);
  const [playbookActivated, setPlaybookActivated] = useState(false);
  const [tasksCompleted, setTasksCompleted] = useState(0);

  useEffect(() => {
    updatePageMetadata({
      title: "Interactive Master Demo - See How M Works | M",
      description: "Step-by-step interactive demo showing where you input data, where AI monitors, and how the human-AI partnership delivers 12-minute strategic execution.",
      ogTitle: "Interactive Master Demo - Human + AI Partnership",
      ogDescription: "Experience the complete M workflow: Your preparation, AI monitoring, instant execution.",
    });
  }, []);

  // Simulate AI monitoring
  useEffect(() => {
    if (aiMonitoring && currentPhase === 'monitoring') {
      const interval = setInterval(() => {
        setCurrentMetric(prev => {
          const newValue = prev + Math.random() * 10 - 3;
          const clamped = Math.min(Math.max(newValue, 40), 85);
          
          // Trigger alert when threshold is reached
          if (clamped >= formData.triggerThreshold[0] && currentPhase === 'monitoring') {
            setTimeout(() => setCurrentPhase('alert'), 1000);
          }
          
          return clamped;
        });
      }, 1500);
      
      return () => clearInterval(interval);
    }
  }, [aiMonitoring, currentPhase, formData.triggerThreshold]);

  // Simulate task execution
  useEffect(() => {
    if (playbookActivated && currentPhase === 'execution') {
      const interval = setInterval(() => {
        setTasksCompleted(prev => {
          if (prev >= 12) {
            setTimeout(() => setCurrentPhase('learning'), 500);
            return 12;
          }
          return prev + 1;
        });
      }, 400);
      
      return () => clearInterval(interval);
    }
  }, [playbookActivated, currentPhase]);

  const startMonitoring = () => {
    if (formData.scenarioName && formData.department && formData.stakeholders) {
      setAiMonitoring(true);
      setCurrentPhase('monitoring');
    }
  };

  const activatePlaybook = () => {
    setCurrentPhase('decision');
    setTimeout(() => {
      setPlaybookActivated(true);
      setCurrentPhase('execution');
    }, 2000);
  };

  const viewResults = () => {
    setCurrentPhase('results');
  };

  const resetDemo = () => {
    setCurrentPhase('setup');
    setFormData({
      scenarioName: '',
      department: '',
      stakeholders: '',
      triggerThreshold: [70],
    });
    setAiMonitoring(false);
    setCurrentMetric(45);
    setPlaybookActivated(false);
    setTasksCompleted(0);
  };

  const phases = [
    { id: 'setup', label: 'Setup', completed: currentPhase !== 'setup' },
    { id: 'monitoring', label: 'AI Monitors', completed: ['alert', 'decision', 'execution', 'learning', 'results'].includes(currentPhase) },
    { id: 'alert', label: 'AI Alerts', completed: ['decision', 'execution', 'learning', 'results'].includes(currentPhase) },
    { id: 'decision', label: 'You Decide', completed: ['execution', 'learning', 'results'].includes(currentPhase) },
    { id: 'execution', label: 'Execute', completed: ['learning', 'results'].includes(currentPhase) },
    { id: 'results', label: 'Results', completed: currentPhase === 'results' },
  ];

  return (
    <div className="page-background min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      <StandardNav />
      <div className="max-w-7xl mx-auto space-y-6 p-6">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <Badge className="bg-blue-600/20 text-blue-300 border-blue-500/50">
            <Sparkles className="h-3 w-3 mr-1.5" />
            Interactive Master Demo
          </Badge>
          <h1 className="text-4xl font-bold text-white">
            See How <span className="text-blue-400">You</span> + <span className="text-purple-400">AI</span> Work Together
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Follow the complete journey from setup to results. Clear labels show where YOU input data and where AI takes action.
          </p>
          <div className="flex justify-center gap-4 mt-6">
            <Button 
              variant="outline" 
              onClick={() => setLocation('/business-scenarios')}
              className="border-cyan-500 text-cyan-300 hover:bg-cyan-500/10"
              data-testid="button-skip-to-scenarios"
            >
              Skip to Playbook Library <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Four-Phase Framework Overview */}
        <Card className="border-cyan-500/30 bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-3">
                The PREPARE → MONITOR → EXECUTE → LEARN Framework
              </h2>
              <p className="text-blue-200 text-lg">
                This demo walks you through all four phases that power championship-level decision velocity
              </p>
            </div>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-green-400 mb-2">1. PREPARE</div>
                <p className="text-green-200 text-sm mb-2 font-semibold">Build Your Playbook</p>
                <p className="text-gray-300 text-xs">
                  Define scenarios, stakeholders, and triggers before you need them
                </p>
              </div>
              <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-blue-400 mb-2">2. MONITOR</div>
                <p className="text-blue-200 text-sm mb-2 font-semibold">AI Watches 24/7</p>
                <p className="text-gray-300 text-xs">
                  AI detects patterns and identifies trigger conditions in real-time
                </p>
              </div>
              <div className="bg-orange-900/20 border border-orange-500/30 rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-orange-400 mb-2">3. EXECUTE</div>
                <p className="text-orange-200 text-sm mb-2 font-semibold">One-Click Activation</p>
                <p className="text-gray-300 text-xs">
                  Coordinated execution across all stakeholders in 12 minutes
                </p>
              </div>
              <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-purple-400 mb-2">4. LEARN</div>
                <p className="text-purple-200 text-sm mb-2 font-semibold">Capture & Improve</p>
                <p className="text-gray-300 text-xs">
                  Document results, refine playbooks, get better every time
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress Indicator */}
        <Card className="border-blue-500/30 bg-slate-900/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              {phases.map((phase, index) => (
                <div key={phase.id} className="flex items-center">
                  <div className={`flex flex-col items-center ${phase.id === currentPhase ? 'scale-110' : ''} transition-transform`}>
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                      phase.completed 
                        ? 'bg-green-500 border-green-500' 
                        : phase.id === currentPhase
                        ? 'bg-blue-500 border-blue-500 animate-pulse'
                        : 'bg-slate-800 border-slate-600'
                    }`}>
                      {phase.completed ? (
                        <CheckCircle className="h-5 w-5 text-white" />
                      ) : (
                        <span className="text-white text-sm font-bold">{index + 1}</span>
                      )}
                    </div>
                    <span className={`text-xs mt-2 ${
                      phase.id === currentPhase ? 'text-blue-400 font-semibold' : 'text-gray-500'
                    }`}>
                      {phase.label}
                    </span>
                  </div>
                  {index < phases.length - 1 && (
                    <div className={`w-16 h-0.5 mx-2 ${
                      phase.completed ? 'bg-green-500' : 'bg-slate-700'
                    }`} />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Phase 1: Setup - YOU DO THIS */}
        {currentPhase === 'setup' && (
          <Card className="border-blue-500/50 bg-gradient-to-br from-blue-950/40 to-slate-900/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <User className="h-6 w-6 text-blue-400" />
                  Step 1: Build Your Playbook
                </CardTitle>
                <Badge className="bg-blue-600/20 text-blue-300 border-blue-500/50">
                  YOU DO THIS
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-300">
                Define your strategic scenario, stakeholders, and trigger thresholds. This is YOUR playbook for YOUR business.
              </p>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="scenario-name" className="text-white">Scenario Name</Label>
                  <Input
                    id="scenario-name"
                    data-testid="input-scenario-name"
                    placeholder="e.g., Supply Chain Disruption"
                    value={formData.scenarioName}
                    onChange={(e) => setFormData({ ...formData, scenarioName: e.target.value })}
                    className="bg-slate-800 border-slate-600 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department" className="text-white">Primary Department</Label>
                  <Input
                    id="department"
                    data-testid="input-department"
                    placeholder="e.g., Operations"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="bg-slate-800 border-slate-600 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="stakeholders" className="text-white">Key Stakeholders</Label>
                  <Input
                    id="stakeholders"
                    data-testid="input-stakeholders"
                    placeholder="e.g., COO, Supply Chain Director, CFO"
                    value={formData.stakeholders}
                    onChange={(e) => setFormData({ ...formData, stakeholders: e.target.value })}
                    className="bg-slate-800 border-slate-600 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Alert Threshold: {formData.triggerThreshold[0]}%</Label>
                  <Slider
                    data-testid="slider-threshold"
                    value={formData.triggerThreshold}
                    onValueChange={(value) => setFormData({ ...formData, triggerThreshold: value })}
                    min={50}
                    max={90}
                    step={5}
                    className="mt-2"
                  />
                  <p className="text-xs text-gray-400">AI will alert you when risk exceeds this threshold</p>
                </div>
              </div>

              {/* What-If Analyzer - only show when scenario is defined */}
              {formData.scenarioName && formData.department && formData.stakeholders && (
                <div className="pt-6">
                  <WhatIfAnalyzer
                    scenario={{
                      name: formData.scenarioName,
                      department: formData.department,
                      stakeholders: formData.stakeholders
                    }}
                  />
                </div>
              )}

              <Button
                data-testid="button-start-monitoring"
                onClick={startMonitoring}
                disabled={!formData.scenarioName || !formData.department || !formData.stakeholders}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg py-6"
              >
                <PlayCircle className="h-5 w-5 mr-2" />
                Start AI Monitoring
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Phase 2: AI Monitoring - AI DOES THIS */}
        {currentPhase === 'monitoring' && (
          <Card className="border-purple-500/50 bg-gradient-to-br from-purple-950/40 to-slate-900/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <Brain className="h-6 w-6 text-purple-400" />
                  Step 2: AI Monitors 24/7
                </CardTitle>
                <Badge className="bg-purple-600/20 text-purple-300 border-purple-500/50 animate-pulse">
                  AI DOES THIS
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-300">
                AI continuously tracks the signals YOU defined. No human intervention needed - the platform watches for YOUR trigger.
              </p>

              <div className="bg-slate-800/50 rounded-lg p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Target className="h-5 w-5 text-purple-400" />
                    <span className="text-white font-medium">Monitoring: {formData.scenarioName}</span>
                  </div>
                  <Badge className="bg-green-600/20 text-green-300 border-green-500/50">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2" />
                    Active
                  </Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Current Risk Level</span>
                    <span className={`font-bold ${
                      currentMetric >= formData.triggerThreshold[0] 
                        ? 'text-red-400' 
                        : currentMetric >= formData.triggerThreshold[0] - 10
                        ? 'text-yellow-400'
                        : 'text-green-400'
                    }`} data-testid="text-current-metric">
                      {Math.round(currentMetric)}%
                    </span>
                  </div>
                  <Progress value={currentMetric} className="h-3" />
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Safe</span>
                    <span className="text-red-400">Threshold: {formData.triggerThreshold[0]}%</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 pt-4">
                  <div className="bg-slate-900/50 rounded p-3 text-center">
                    <Clock className="h-4 w-4 text-gray-400 mx-auto mb-1" />
                    <p className="text-xs text-gray-400">Uptime</p>
                    <p className="text-sm font-bold text-white">24/7</p>
                  </div>
                  <div className="bg-slate-900/50 rounded p-3 text-center">
                    <TrendingUp className="h-4 w-4 text-gray-400 mx-auto mb-1" />
                    <p className="text-xs text-gray-400">Signals</p>
                    <p className="text-sm font-bold text-white">12</p>
                  </div>
                  <div className="bg-slate-900/50 rounded p-3 text-center">
                    <Shield className="h-4 w-4 text-gray-400 mx-auto mb-1" />
                    <p className="text-xs text-gray-400">Coverage</p>
                    <p className="text-sm font-bold text-white">100%</p>
                  </div>
                </div>

                <p className="text-xs text-gray-500 text-center pt-2">
                  AI is analyzing patterns in real-time. When risk exceeds {formData.triggerThreshold[0]}%, you'll be alerted instantly.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Phase 3: AI Alert - AI DOES THIS */}
        {currentPhase === 'alert' && (
          <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-950/40 to-slate-900/40 animate-pulse">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <Bell className="h-6 w-6 text-yellow-400" />
                  Step 3: AI Alert Triggered
                </CardTitle>
                <Badge className="bg-yellow-600/20 text-yellow-300 border-yellow-500/50">
                  AI DOES THIS
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-yellow-900/20 border border-yellow-500/50 rounded-lg p-6 space-y-4">
                <div className="flex items-start gap-4">
                  <AlertTriangle className="h-12 w-12 text-yellow-400 flex-shrink-0" />
                  <div className="flex-1 page-background">
                    <h3 className="text-xl font-bold text-yellow-300 mb-2">Trigger Threshold Reached!</h3>
                    <p className="text-gray-300 mb-4">
                      AI detected that <strong>{formData.scenarioName}</strong> risk has exceeded your {formData.triggerThreshold[0]}% threshold.
                    </p>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-slate-800/50 rounded p-3">
                        <p className="text-gray-400">Current Level</p>
                        <p className="text-2xl font-bold text-red-400">{Math.round(currentMetric)}%</p>
                      </div>
                      <div className="bg-slate-800/50 rounded p-3">
                        <p className="text-gray-400">Your Threshold</p>
                        <p className="text-2xl font-bold text-yellow-400">{formData.triggerThreshold[0]}%</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t border-yellow-500/30 pt-4">
                  <p className="text-sm text-gray-400 mb-3">AI Recommendation:</p>
                  <div className="bg-slate-800/50 rounded p-4">
                    <p className="text-white">
                      Activate <strong>"{formData.scenarioName}"</strong> playbook to coordinate response across {formData.department} and notify {formData.stakeholders}.
                    </p>
                  </div>
                </div>
              </div>

              <Button
                data-testid="button-review-decision"
                onClick={activatePlaybook}
                className="w-full bg-yellow-600 hover:bg-yellow-700 text-white"
              >
                <User className="h-5 w-5 mr-2" />
                Review & Make Decision
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Phase 4: Decision Point - YOU DO THIS */}
        {currentPhase === 'decision' && (
          <Card className="border-blue-500/50 bg-gradient-to-br from-blue-950/40 to-slate-900/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <User className="h-6 w-6 text-blue-400" />
                  Step 4: You Make The Call
                </CardTitle>
                <Badge className="bg-blue-600/20 text-blue-300 border-blue-500/50">
                  YOU DECIDE
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-300 text-center text-lg">
                AI has provided the recommendation. <strong>YOU</strong> are in control. <strong>YOU</strong> make the final decision.
              </p>

              <div className="bg-slate-800/50 rounded-lg p-6 space-y-4">
                <h3 className="text-white font-semibold">Activating Playbook...</h3>
                <Progress value={100} className="h-2" />
                <p className="text-sm text-gray-400">Preparing coordinated response...</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Phase 5: Execution - AI + YOU PARTNERSHIP */}
        {currentPhase === 'execution' && (
          <Card className="border-green-500/50 bg-gradient-to-br from-green-950/40 to-slate-900/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <Zap className="h-6 w-6 text-green-400" />
                  Step 5: Coordinated Execution
                </CardTitle>
                <Badge className="bg-green-600/20 text-green-300 border-green-500/50">
                  YOU + AI PARTNERSHIP
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-300">
                AI executes YOUR playbook. Tasks distributed to YOUR stakeholders. YOU monitor progress in real-time.
              </p>

              <div className="bg-slate-800/50 rounded-lg p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-white font-medium">Playbook: {formData.scenarioName}</span>
                  <Badge className="bg-green-600/20 text-green-300 border-green-500/50">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2" />
                    Executing
                  </Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Tasks Completed</span>
                    <span className="font-bold text-green-400" data-testid="text-tasks-completed">{tasksCompleted}/12</span>
                  </div>
                  <Progress value={(tasksCompleted / 12) * 100} className="h-3" />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-900/50 rounded p-3">
                    <Users className="h-4 w-4 text-gray-400 mb-1" />
                    <p className="text-xs text-gray-400">Stakeholders Notified</p>
                    <p className="text-sm font-bold text-white">{formData.stakeholders.split(',').length}</p>
                  </div>
                  <div className="bg-slate-900/50 rounded p-3">
                    <Clock className="h-4 w-4 text-gray-400 mb-1" />
                    <p className="text-xs text-gray-400">Response Time</p>
                    <p className="text-sm font-bold text-white">8 min</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Phase 6: Learning - AI LEARNS, YOU APPROVE */}
        {currentPhase === 'learning' && (
          <Card className="border-purple-500/50 bg-gradient-to-br from-purple-950/40 to-slate-900/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <Brain className="h-6 w-6 text-purple-400" />
                  Step 6: AI Learning & Improvement
                </CardTitle>
                <Badge className="bg-purple-600/20 text-purple-300 border-purple-500/50">
                  AI SUGGESTS, YOU APPROVE
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-300">
                AI analyzed what worked. Review recommendations and decide what to keep for next time.
              </p>

              <div className="bg-slate-800/50 rounded-lg p-6 space-y-4">
                <h3 className="text-white font-semibold flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-purple-400" />
                  AI-Generated Insights
                </h3>

                <div className="space-y-3">
                  <div className="bg-green-900/20 border border-green-500/30 rounded p-3">
                    <p className="text-sm text-gray-300">
                      ✅ Early stakeholder notification improved response time by 23%
                    </p>
                  </div>
                  <div className="bg-green-900/20 border border-green-500/30 rounded p-3">
                    <p className="text-sm text-gray-300">
                      ✅ {formData.department} coordination prevented $450K in potential losses
                    </p>
                  </div>
                  <div className="bg-blue-900/20 border border-blue-500/30 rounded p-3">
                    <p className="text-sm text-gray-300">
                      💡 Recommendation: Add Finance VP to stakeholder list for faster budget approval
                    </p>
                  </div>
                </div>
              </div>

              <Button
                data-testid="button-view-results"
                onClick={viewResults}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              >
                <BarChart3 className="h-5 w-5 mr-2" />
                View Final Results
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Phase 7: Results - THE OUTCOME */}
        {currentPhase === 'results' && (
          <Card className="border-green-500/50 bg-gradient-to-br from-green-950/40 to-slate-900/40">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <CheckCircle className="h-6 w-6 text-green-400" />
                  Results: Human + AI Partnership
                </CardTitle>
                <Badge className="bg-green-600/20 text-green-300 border-green-500/50">
                  SUCCESS
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Show user's input data - proving persistence */}
              <div className="bg-slate-800/50 rounded-lg p-4 border border-blue-500/30">
                <h3 className="text-sm font-semibold text-blue-400 mb-3">Your Scenario:</h3>
                <div className="grid md:grid-cols-3 gap-3 text-sm">
                  <div>
                    <p className="text-gray-400">Scenario Name</p>
                    <p className="text-white font-medium" data-testid="text-result-scenario">{formData.scenarioName}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Department</p>
                    <p className="text-white font-medium">{formData.department}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Stakeholders</p>
                    <p className="text-white font-medium" data-testid="text-result-stakeholders">{formData.stakeholders}</p>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-slate-800/50 rounded-lg p-6 text-center">
                  <Clock className="h-8 w-8 text-blue-400 mx-auto mb-3" />
                  <p className="text-3xl font-bold text-white mb-1">8 min</p>
                  <p className="text-sm text-gray-400">Response Time</p>
                  <p className="text-xs text-green-400 mt-2">vs 72 hrs traditional</p>
                </div>

                <div className="bg-slate-800/50 rounded-lg p-6 text-center">
                  <Users className="h-8 w-8 text-purple-400 mx-auto mb-3" />
                  <p className="text-3xl font-bold text-white mb-1">{formData.stakeholders.split(',').length}</p>
                  <p className="text-sm text-gray-400">Stakeholders Aligned</p>
                  <p className="text-xs text-green-400 mt-2">Instant coordination</p>
                </div>

                <div className="bg-slate-800/50 rounded-lg p-6 text-center">
                  <TrendingUp className="h-8 w-8 text-green-400 mx-auto mb-3" />
                  <p className="text-3xl font-bold text-white mb-1">$450K</p>
                  <p className="text-sm text-gray-400">Value Protected</p>
                  <p className="text-xs text-green-400 mt-2">Strategic success</p>
                </div>
              </div>

              <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-6">
                <h3 className="text-white font-semibold mb-3">What You Just Experienced:</h3>
                <div className="space-y-2 text-sm text-gray-300">
                  <p>✅ <strong>YOU</strong> built the playbook with your business rules</p>
                  <p>✅ <strong>AI</strong> monitored 24/7 for the signals you defined</p>
                  <p>✅ <strong>AI</strong> alerted you when thresholds were breached</p>
                  <p>✅ <strong>YOU</strong> made the final decision to activate</p>
                  <p>✅ <strong>AI</strong> coordinated execution across your team</p>
                  <p>✅ <strong>AI</strong> learned and suggested improvements (YOU approve)</p>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  data-testid="button-try-again"
                  onClick={resetDemo}
                  variant="outline"
                  className="flex-1 border-slate-600 text-white hover:bg-slate-800"
                >
                  Try Different Scenario
                </Button>
                <Button
                  data-testid="button-explore-scenarios"
                  onClick={() => window.location.href = '/business-scenarios'}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Explore 148 Playbooks
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* The Five Systems - How M Actually Works */}
        <Card className="border-cyan-500/30 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 mt-12">
          <CardHeader>
            <CardTitle className="text-3xl text-white text-center">
              Under the Hood: The Five Systems That Power M
            </CardTitle>
            <p className="text-blue-200 text-center text-lg mt-2">
              This demo showed you the experience. Here's the technology that makes it possible.
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* System 1 */}
            <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-lg bg-blue-500 text-white flex items-center justify-center text-xl font-bold">
                    1
                  </div>
                </div>
                <div className="flex-1 page-background">
                  <h3 className="text-xl font-bold text-white mb-2">Operating Model Intelligence</h3>
                  <p className="text-blue-200 mb-3">
                    Maps your unique organizational "fingerprint" across McKinsey's 12 elements
                  </p>
                  <div className="bg-slate-800/50 rounded p-4 text-sm text-gray-300">
                    <p className="mb-2"><strong className="text-blue-300">What happens:</strong> During implementation, we analyze your structure (matrix, functional, agile), decision authorities, governance model, approval workflows, ecosystem partners, leadership styles, talent distribution.</p>
                    <p className="text-green-300"><strong>Output:</strong> Your organization's unique fingerprint—the specific combination of design choices across all 12 elements that makes YOUR playbooks work for YOUR business.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* System 2 */}
            <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-lg bg-green-500 text-white flex items-center justify-center text-xl font-bold">
                    2
                  </div>
                </div>
                <div className="flex-1 page-background">
                  <h3 className="text-xl font-bold text-white mb-2">Decision Playbook Library</h3>
                  <p className="text-green-200 mb-3">
                    Translates your operating model into executable decision frameworks
                  </p>
                  <div className="bg-slate-800/50 rounded p-4 text-sm text-gray-300 space-y-2">
                    <p><strong className="text-green-300">148 Strategic Playbooks:</strong> Across 8 operational domains - Market Dynamics, Financial Strategy, Operational Excellence, Technology & Innovation, Talent & Leadership, Brand & Reputation, Regulatory & Compliance, Market Opportunities.</p>
                    <p><strong className="text-green-300">Each playbook includes:</strong> Which McKinsey elements activate, stakeholder assignments, approval workflows, communication templates, success metrics.</p>
                    <p className="text-green-300"><strong>Example:</strong> Competitive Response activates Leadership + Governance + Structure + Processes + Technology. Expected: 21 days → 3 days. Annual value: $12M.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* System 3 */}
            <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-lg bg-purple-500 text-white flex items-center justify-center text-xl font-bold">
                    3
                  </div>
                </div>
                <div className="flex-1 page-background">
                  <h3 className="text-xl font-bold text-white mb-2">AI-Powered Decision Intelligence</h3>
                  <p className="text-purple-200 mb-3">
                    Your "coaches in the booth"—continuously monitoring for conditions that require decisions
                  </p>
                  <div className="bg-slate-800/50 rounded p-4 text-sm text-gray-300">
                    <p className="mb-3"><strong className="text-purple-300">24/7 surveillance across:</strong></p>
                    <div className="grid md:grid-cols-2 gap-2 mb-3">
                      <div>• Competitive signals (launches, pricing, market moves)</div>
                      <div>• Customer signals (sentiment, churn, engagement)</div>
                      <div>• Operational signals (supply chain, capacity constraints)</div>
                      <div>• Market signals (regulatory changes, industry shifts)</div>
                      <div>• Internal signals (opportunities, resource utilization)</div>
                      <div>• Organizational signals (12-element performance)</div>
                    </div>
                    <p className="text-purple-300"><strong>When trigger detected:</strong> "Competitive Response scenario detected - 94% confidence. Recommended: Activate Playbook v3.2. Expected: 3-day response vs 21-day historical average."</p>
                  </div>
                </div>
              </div>
            </div>

            {/* System 4 */}
            <div className="bg-orange-900/20 border border-orange-500/30 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-lg bg-orange-500 text-white flex items-center justify-center text-xl font-bold">
                    4
                  </div>
                </div>
                <div className="flex-1 page-background">
                  <h3 className="text-xl font-bold text-white mb-2">Coordinated Execution Engine</h3>
                  <p className="text-orange-200 mb-3">
                    Translates executive decision into simultaneous action across all 12 elements
                  </p>
                  <div className="bg-slate-800/50 rounded p-4 text-sm text-gray-300">
                    <p className="mb-2"><strong className="text-orange-300">Minute-by-minute breakdown:</strong></p>
                    <div className="space-y-2 mb-3">
                      <div><strong>Minute 0-2:</strong> System validation (stakeholders available, resources allocated, decision authorities confirmed)</div>
                      <div><strong>Minute 2-5:</strong> Simultaneous distribution across all 12 elements (strategic context, team assembly, partner notifications, budget allocation, process activation)</div>
                      <div><strong>Minute 5-12:</strong> Coordinated execution begins (campaigns launch, sales outreach starts, product priorities adjust, legal reviews complete)</div>
                      <div className="text-orange-300"><strong>Day 3:</strong> Response in market (vs Day 21 without M)</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* System 5 */}
            <div className="bg-cyan-900/20 border border-cyan-500/30 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-lg bg-cyan-500 text-white flex items-center justify-center text-xl font-bold">
                    5
                  </div>
                </div>
                <div className="flex-1 page-background">
                  <h3 className="text-xl font-bold text-white mb-2">Operating Model Learning Engine</h3>
                  <p className="text-cyan-200 mb-3">
                    Continuous improvement of your operating model's execution effectiveness
                  </p>
                  <div className="bg-slate-800/50 rounded p-4 text-sm text-gray-300">
                    <p className="mb-2"><strong className="text-cyan-300">After each execution, measures:</strong></p>
                    <div className="space-y-1 mb-3 text-xs">
                      <div>• <strong>Leadership:</strong> Decision authority clarity? Speed of approvals?</div>
                      <div>• <strong>Governance:</strong> Resource allocation effective? Budget flexibility?</div>
                      <div>• <strong>Structure:</strong> Cross-functional coordination smooth? Bottlenecks?</div>
                      <div>• <strong>Processes:</strong> Which workflows performed? Where were delays?</div>
                      <div>• <strong>Technology:</strong> AI triggers accurate? System integrations smooth?</div>
                      <div>• <strong>All 12 elements:</strong> Design quality vs execution effectiveness</div>
                    </div>
                    <p className="text-cyan-300"><strong>Quarterly Health Report:</strong> Shows you which elements are performing, which need refinement, and specific recommendations for optimization.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Summary */}
            <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/50 rounded-lg p-8 text-center">
              <h3 className="text-2xl font-bold text-white mb-3">
                Five Systems. One Platform. Championship-Level Execution.
              </h3>
              <p className="text-blue-200 text-lg mb-4">
                McKinsey helped you design your operating model across 12 elements. M shows you how it performs in reality—and how to optimize it for 12-minute strategic execution.
              </p>
              
              <div className="mb-6">
                <p className="text-white font-semibold text-lg mb-2">Ready to Transform Your Execution?</p>
                <p className="text-blue-200 text-sm mb-4">
                  Join M's Q1 2025 pilot program. Limited to 10 Fortune 1000 companies.
                </p>
                <Button
                  data-testid="button-request-early-access-demo"
                  onClick={() => window.location.href = '/contact'}
                  size="lg"
                  className="bg-purple-600 hover:bg-purple-700 text-white text-lg px-8 py-6 mb-4"
                >
                  Request Early Access Interview
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Button>
              </div>

              <div className="border-t border-blue-500/30 pt-6">
                <p className="text-blue-300 text-sm mb-3">Continue Exploring:</p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button
                    data-testid="button-explore-all-scenarios"
                    onClick={() => window.location.href = '/business-scenarios'}
                    variant="outline"
                    className="border-blue-500 text-blue-300 hover:bg-blue-500/10"
                  >
                    View 148 Playbooks
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </Button>
                  <Button
                    data-testid="button-trade-show-demo"
                    onClick={() => window.location.href = '/trade-show-demo'}
                    variant="outline"
                    className="border-blue-500 text-blue-300 hover:bg-blue-500/10"
                  >
                    Trade Show Demo
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </Button>
                  <Button
                    data-testid="button-home-return"
                    onClick={() => window.location.href = '/'}
                    variant="outline"
                    className="border-blue-500 text-blue-300 hover:bg-blue-500/10"
                  >
                    Return Home
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
