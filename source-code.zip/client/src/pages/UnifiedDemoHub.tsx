import { useState, useEffect } from 'react';
import StandardNav from '@/components/layout/StandardNav';
import { updatePageMetadata } from '@/lib/seo';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Footer from '@/components/layout/Footer';
import { 
  Rocket, 
  PlayCircle, 
  Zap, 
  Users, 
  TrendingUp,
  ArrowRight,
  Shield,
  Target,
  Clock,
  Presentation,
  Monitor,
  Play,
  Building2,
  Factory,
  HeartPulse,
  Plane,
  DollarSign,
  ShoppingCart,
  Cpu,
  Leaf,
  User,
  Briefcase,
  PieChart,
  BarChart3,
  Globe,
  Sparkles,
  ChevronRight,
  Video,
  Eye
} from 'lucide-react';
import { Link } from 'wouter';

const industries = [
  { id: 'all', label: 'All Industries', icon: Globe },
  { id: 'financial', label: 'Financial Services', icon: DollarSign },
  { id: 'healthcare', label: 'Healthcare', icon: HeartPulse },
  { id: 'manufacturing', label: 'Manufacturing', icon: Factory },
  { id: 'retail', label: 'Retail', icon: ShoppingCart },
  { id: 'technology', label: 'Technology', icon: Cpu },
  { id: 'energy', label: 'Energy', icon: Leaf },
  { id: 'aerospace', label: 'Aerospace & Defense', icon: Plane },
];

const personas = [
  { id: 'all', label: 'All Roles', icon: Users },
  { id: 'ceo', label: 'CEO', icon: User },
  { id: 'cfo', label: 'CFO', icon: PieChart },
  { id: 'coo', label: 'COO', icon: BarChart3 },
  { id: 'cto', label: 'CTO/CIO', icon: Cpu },
  { id: 'cmo', label: 'CMO', icon: Target },
];

const demoExperiences = [
  {
    id: 'live-activation',
    title: 'Live Activation Demo',
    description: 'Experience M in real-time with a live crisis scenario',
    path: '/demo/live-activation',
    duration: '12 min',
    type: 'interactive',
    featured: true,
    industries: ['all'],
    personas: ['ceo', 'coo', 'cto'],
    icon: Zap,
    color: 'blue',
    badge: 'LIVE'
  },
  {
    id: 'product-tour',
    title: 'Product Tour',
    description: 'Cinematic walkthrough of M\'s key capabilities',
    path: '/product-tour',
    duration: '8 min',
    type: 'video',
    featured: true,
    industries: ['all'],
    personas: ['all'],
    icon: Video,
    color: 'purple',
    badge: '14 SCENES'
  },
  {
    id: 'executive-simulation',
    title: 'Executive Simulation',
    description: 'Immersive role-play as a Fortune 500 executive',
    path: '/executive-simulation',
    duration: '15 min',
    type: 'simulation',
    featured: true,
    industries: ['all'],
    personas: ['ceo', 'cfo', 'coo'],
    icon: Briefcase,
    color: 'amber',
    badge: 'IMMERSIVE'
  },
  {
    id: 'intelligence-demo',
    title: 'Intelligence Signals Demo',
    description: 'See how AI monitors 92+ data points in real-time',
    path: '/intelligence-demo',
    duration: '10 min',
    type: 'guided',
    industries: ['all'],
    personas: ['cto', 'coo'],
    icon: Eye,
    color: 'cyan'
  },
  {
    id: 'how-it-works',
    title: 'How It Works',
    description: 'Step-by-step explanation of the M methodology',
    path: '/how-it-works',
    duration: '5 min',
    type: 'overview',
    industries: ['all'],
    personas: ['all'],
    icon: Target,
    color: 'green'
  },
  {
    id: 'ransomware',
    title: 'Financial Ransomware Response',
    description: 'See how a $22M crisis is contained in 12 minutes',
    path: '/demos/financial-ransomware',
    duration: '12 min',
    type: 'industry',
    industries: ['financial'],
    personas: ['cto', 'coo'],
    icon: Shield,
    color: 'red'
  },
  {
    id: 'luxury-crisis',
    title: 'Luxury Brand Crisis',
    description: 'Heritage brand navigates social media controversy',
    path: '/demos/luxury-crisis',
    duration: '10 min',
    type: 'industry',
    industries: ['retail'],
    personas: ['cmo', 'ceo'],
    icon: Sparkles,
    color: 'violet'
  },
  {
    id: 'supply-chain',
    title: 'Manufacturing Supply Crisis',
    description: 'Global manufacturer responds to supplier disruption',
    path: '/demos/manufacturing-supplier',
    duration: '11 min',
    type: 'industry',
    industries: ['manufacturing'],
    personas: ['coo'],
    icon: Factory,
    color: 'orange'
  },
  {
    id: 'market-entry',
    title: 'LVMH Market Entry',
    description: 'Strategic market expansion in Southeast Asia',
    path: '/demos/lvmh-market-entry',
    duration: '14 min',
    type: 'industry',
    industries: ['retail'],
    personas: ['ceo', 'cfo'],
    icon: Globe,
    color: 'indigo'
  },
  {
    id: 'pharma-recall',
    title: 'Pharmaceutical Recall',
    description: 'Managing a product recall across 50 markets',
    path: '/demos/pharma-recall',
    duration: '13 min',
    type: 'industry',
    industries: ['healthcare'],
    personas: ['ceo', 'coo'],
    icon: HeartPulse,
    color: 'pink'
  },
];

export default function UnifiedDemoHub() {
  const [selectedIndustry, setSelectedIndustry] = useState('all');
  const [selectedPersona, setSelectedPersona] = useState('all');

  useEffect(() => {
    updatePageMetadata({
      title: "Demo Hub - Experience M in Action | Strategic Execution OS",
      description: "See how Fortune 1000 executives achieve 12-minute coordinated response with M. Choose from live demos, industry scenarios, product tours, and executive simulations.",
      ogTitle: "M Demo Hub - See Strategic Execution in Action",
      ogDescription: "Experience the future of strategic execution. Watch live demos, explore industry scenarios, and see how M delivers 12-minute response times.",
    });
  }, []);

  const filteredDemos = demoExperiences.filter(demo => {
    const industryMatch = selectedIndustry === 'all' || demo.industries.includes('all') || demo.industries.includes(selectedIndustry);
    const personaMatch = selectedPersona === 'all' || demo.personas.includes('all') || demo.personas.includes(selectedPersona);
    return industryMatch && personaMatch;
  });

  const featuredDemos = filteredDemos.filter(demo => demo.featured);
  const otherDemos = filteredDemos.filter(demo => !demo.featured);

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; border: string; text: string; badge: string }> = {
      blue: { bg: 'from-blue-950/40 to-slate-950/40', border: 'border-blue-500/30 hover:border-blue-500/50', text: 'text-blue-400', badge: 'bg-blue-500/10 text-blue-300 border-blue-500/30' },
      purple: { bg: 'from-purple-950/40 to-slate-950/40', border: 'border-purple-500/30 hover:border-purple-500/50', text: 'text-purple-400', badge: 'bg-purple-500/10 text-purple-300 border-purple-500/30' },
      amber: { bg: 'from-amber-950/40 to-slate-950/40', border: 'border-amber-500/30 hover:border-amber-500/50', text: 'text-amber-400', badge: 'bg-amber-500/10 text-amber-300 border-amber-500/30' },
      green: { bg: 'from-green-950/40 to-slate-950/40', border: 'border-green-500/30 hover:border-green-500/50', text: 'text-green-400', badge: 'bg-green-500/10 text-green-300 border-green-500/30' },
      cyan: { bg: 'from-cyan-950/40 to-slate-950/40', border: 'border-cyan-500/30 hover:border-cyan-500/50', text: 'text-cyan-400', badge: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30' },
      red: { bg: 'from-red-950/40 to-slate-950/40', border: 'border-red-500/30 hover:border-red-500/50', text: 'text-red-400', badge: 'bg-red-500/10 text-red-300 border-red-500/30' },
      violet: { bg: 'from-violet-950/40 to-slate-950/40', border: 'border-violet-500/30 hover:border-violet-500/50', text: 'text-violet-400', badge: 'bg-violet-500/10 text-violet-300 border-violet-500/30' },
      orange: { bg: 'from-orange-950/40 to-slate-950/40', border: 'border-orange-500/30 hover:border-orange-500/50', text: 'text-orange-400', badge: 'bg-orange-500/10 text-orange-300 border-orange-500/30' },
      indigo: { bg: 'from-indigo-950/40 to-slate-950/40', border: 'border-indigo-500/30 hover:border-indigo-500/50', text: 'text-indigo-400', badge: 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30' },
      pink: { bg: 'from-pink-950/40 to-slate-950/40', border: 'border-pink-500/30 hover:border-pink-500/50', text: 'text-pink-400', badge: 'bg-pink-500/10 text-pink-300 border-pink-500/30' },
    };
    return colors[color] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <StandardNav />
      
      <div className="max-w-7xl mx-auto px-6 py-12 space-y-12">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/10 border border-blue-500/30 rounded-full">
            <Rocket className="h-4 w-4 text-blue-400" />
            <span className="text-sm font-semibold text-blue-300">Demo Hub</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            Experience M in Action
          </h1>
          
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Success favors the prepared. See how Fortune 1000 executives replace reactive scrambles with 
            coordinated precision—achieving 12-minute execution vs the 72-hour industry standard.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-400">Industry:</span>
            <div className="flex flex-wrap gap-1">
              {industries.slice(0, 5).map(ind => (
                <Button
                  key={ind.id}
                  variant={selectedIndustry === ind.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedIndustry(ind.id)}
                  className={selectedIndustry === ind.id ? "bg-blue-600" : "border-slate-600 text-slate-300"}
                  data-testid={`filter-industry-${ind.id}`}
                >
                  {ind.label}
                </Button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-400">Role:</span>
            <div className="flex flex-wrap gap-1">
              {personas.map(persona => (
                <Button
                  key={persona.id}
                  variant={selectedPersona === persona.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedPersona(persona.id)}
                  className={selectedPersona === persona.id ? "bg-blue-600" : "border-slate-600 text-slate-300"}
                  data-testid={`filter-persona-${persona.id}`}
                >
                  {persona.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Featured Demos */}
        {featuredDemos.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-amber-400" />
              Featured Experiences
            </h2>
            <div className="grid md:grid-cols-3 gap-6" data-testid="grid-featured-demos">
              {featuredDemos.map(demo => {
                const colors = getColorClasses(demo.color);
                const Icon = demo.icon;
                return (
                  <Link key={demo.id} href={demo.path} data-testid={`demo-link-${demo.id}`}>
                    <Card className={`${colors.border} bg-gradient-to-br ${colors.bg} transition-all cursor-pointer h-full`} data-testid={`demo-card-${demo.id}`}>
                      <CardHeader>
                        <div className="flex items-start justify-between mb-4">
                          <div className={`p-3 ${colors.text.replace('text-', 'bg-')}/10 rounded-lg`}>
                            <Icon className={`h-8 w-8 ${colors.text}`} />
                          </div>
                          {demo.badge && (
                            <Badge variant="outline" className={colors.badge}>
                              {demo.badge}
                            </Badge>
                          )}
                        </div>
                        <CardTitle className="text-xl text-white mb-2">
                          {demo.title}
                        </CardTitle>
                        <CardDescription className="text-slate-300">
                          {demo.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2 text-slate-400">
                            <Clock className="h-4 w-4" />
                            {demo.duration}
                          </div>
                          <div className="flex items-center gap-1 text-blue-400">
                            Start Demo
                            <ChevronRight className="h-4 w-4" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* All Demos Grid */}
        {otherDemos.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Play className="h-5 w-5 text-green-400" />
              Industry Scenarios
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="grid-industry-demos">
              {otherDemos.map(demo => {
                const colors = getColorClasses(demo.color);
                const Icon = demo.icon;
                return (
                  <Link key={demo.id} href={demo.path} data-testid={`demo-link-${demo.id}`}>
                    <Card className={`${colors.border} bg-gradient-to-br ${colors.bg} transition-all cursor-pointer h-full`} data-testid={`demo-card-${demo.id}`}>
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          <div className={`p-2 ${colors.text.replace('text-', 'bg-')}/10 rounded-lg flex-shrink-0`}>
                            <Icon className={`h-6 w-6 ${colors.text}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-white mb-1">{demo.title}</h3>
                            <p className="text-sm text-slate-400 mb-2">{demo.description}</p>
                            <div className="flex items-center gap-4 text-xs text-slate-500">
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {demo.duration}
                              </div>
                            </div>
                          </div>
                          <ChevronRight className="h-5 w-5 text-slate-500 flex-shrink-0" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* No Results */}
        {filteredDemos.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-400 text-lg">No demos match your current filters.</p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => { setSelectedIndustry('all'); setSelectedPersona('all'); }}
            >
              Clear Filters
            </Button>
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8 border-t border-slate-800">
          <div className="text-center p-4">
            <div className="text-3xl font-bold text-blue-400">12 min</div>
            <div className="text-sm text-slate-400">Average Response Time</div>
          </div>
          <div className="text-center p-4">
            <div className="text-3xl font-bold text-green-400">148</div>
            <div className="text-sm text-slate-400">Strategic Playbooks</div>
          </div>
          <div className="text-center p-4">
            <div className="text-3xl font-bold text-purple-400">92+</div>
            <div className="text-sm text-slate-400">Data Points Monitored</div>
          </div>
          <div className="text-center p-4">
            <div className="text-3xl font-bold text-amber-400">9</div>
            <div className="text-sm text-slate-400">Industry Scenarios</div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center pt-8">
          <p className="text-slate-400 mb-4">Ready to see M in your organization?</p>
          <div className="flex justify-center gap-4">
            <Link href="/contact">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                Schedule a Demo
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link href="/start">
              <Button size="lg" variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-800">
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
