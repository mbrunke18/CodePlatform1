import { useState, useRef, useEffect } from 'react';
import StandardNav from '@/components/layout/StandardNav';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useDemoController } from '@/contexts/DemoController';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  AlertTriangle,
  TrendingUp,
  Target,
  Users,
  Brain,
  Activity,
  Layers,
  Zap,
  DollarSign,
  Shield,
  Clock,
  CheckCircle,
  ArrowRight,
  BarChart3,
  Settings,
  Globe,
  TrendingDown,
  Minus
} from 'lucide-react';

interface DecisionOption {
  id: string;
  label: string;
  description: string;
  isM: boolean;
  impact: string;
}

interface DemoStep {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  phase: 'detection' | 'planning' | 'response' | 'execution' | 'measurement';
  capabilities: string[];
  metrics: Array<{
    label: string;
    value: string;
    trend: 'up' | 'down' | 'stable';
    critical?: boolean;
  }>;
  actions: string[];
  timeline: string;
  decisionPrompt?: {
    question: string;
    context: string;
    options: DecisionOption[];
  };
}

const demoSteps: DemoStep[] = [
  {
    id: 'signal-detection',
    title: 'Strategic Signal Detection',
    subtitle: 'AI competitor breakthrough detected',
    description: 'Pulse Intelligence module identifies convergence of competitive threats and market disruption signals across multiple data streams.',
    phase: 'detection',
    capabilities: ['Pulse Intelligence', 'Pattern Recognition', 'Threat Assessment', 'Real-time Monitoring'],
    metrics: [
      { label: 'Competitor AI Patents', value: '847%', trend: 'up', critical: true },
      { label: 'Customer AI Inquiries', value: '312%', trend: 'up', critical: true },
      { label: 'Industry Cost Advantage', value: '40%', trend: 'up', critical: true },
      { label: 'Media Sentiment Shift', value: '-23%', trend: 'down', critical: true }
    ],
    actions: [
      'Automated competitive intelligence gathering',
      'Cross-reference customer inquiry patterns',
      'Industry benchmark analysis activation',
      'Executive alert notification sent'
    ],
    timeline: '0-2 hours',
    decisionPrompt: {
      question: 'Competitive AI threat detected. How do you respond?',
      context: 'Your AI monitoring just flagged a major competitor breakthrough. Customer inquiries about AI are up 312%. Traditional response: Schedule meetings to assess. M: Activate pre-built playbook.',
      options: [
        {
          id: 'traditional',
          label: 'Schedule Assessment Meetings',
          description: 'Call leadership team, schedule analysis sessions over next 48-72 hours',
          isM: false,
          impact: '72 hours to first action. Competitor advantage grows. Customer concerns multiply.'
        },
        {
          id: 'm',
          label: 'Activate AI Disruption Playbook',
          description: 'Immediately trigger pre-configured response protocol with 47 stakeholders',
          isM: true,
          impact: '8 minutes to coordinated response. War room assembled. Crisis contained.'
        }
      ]
    }
  },
  {
    id: 'trigger-activation',
    title: 'Automated Trigger Activation',
    subtitle: 'Threshold breach - Crisis protocol initiated',
    description: 'Pre-configured triggers automatically activate when competitor AI capabilities exceed defined thresholds, launching comprehensive response protocols.',
    phase: 'detection',
    capabilities: ['Triggers Management', 'Automated Escalation', 'Crisis Response Templates', 'Stakeholder Notification'],
    metrics: [
      { label: 'Response Speed', value: '8.3 min', trend: 'down' },
      { label: 'Stakeholders Notified', value: '47', trend: 'up' },
      { label: 'Crisis Template Match', value: '98%', trend: 'stable' },
      { label: 'Escalation Level', value: 'Critical', trend: 'up', critical: true }
    ],
    actions: [
      'Executive war room assembly initiated',
      'Emergency budget authorization triggered',
      'Competitive technology disruption template activated',
      'Multi-department coordination protocols launched'
    ],
    timeline: '8 minutes',
    decisionPrompt: {
      question: 'Crisis threshold breached. Authorize emergency protocols?',
      context: 'Your pre-configured trigger just fired. 47 stakeholders need coordination. Traditional: Manually call each department. M: One-click activation of pre-approved crisis playbook.',
      options: [
        {
          id: 'traditional',
          label: 'Manual Coordination',
          description: 'Personally call department heads, schedule emergency meetings, build response plan',
          isM: false,
          impact: 'Day 1: Still assembling team. $847K daily revenue at risk. Board asking questions.'
        },
        {
          id: 'm',
          label: 'Activate Crisis Playbook',
          description: 'One-click activation: 47 stakeholders notified, war room launched, budget approved',
          isM: true,
          impact: '8 minutes: Team assembled, plan deployed, crisis contained. Board impressed.'
        }
      ]
    }
  },
  {
    id: 'scenario-planning',
    title: 'Strategic Scenario Planning',
    subtitle: 'AI Transformation Initiative mapped',
    description: 'Nova Innovation module generates comprehensive strategic scenarios with resource requirements, stakeholder mapping, and success metrics for competitive response.',
    phase: 'planning',
    capabilities: ['Nova Innovations', 'Scenario Templates', 'Resource Planning', 'Stakeholder Mapping'],
    metrics: [
      { label: 'Investment Required', value: '$50M', trend: 'stable' },
      { label: 'Timeline to Parity', value: '18 months', trend: 'down' },
      { label: 'Success Probability', value: '87%', trend: 'up' },
      { label: 'Market Share Protection', value: '92%', trend: 'up' }
    ],
    actions: [
      'Three AI implementation pathways identified',
      'Resource requirements calculated ($50M, 120-person team)',
      'Critical decision milestones mapped (12 go/no-go points)',
      'Technology partner assessment completed'
    ],
    timeline: '2-6 hours',
    decisionPrompt: {
      question: '$50M AI investment needed. How do you build the strategic plan?',
      context: 'Board demands comprehensive AI transformation strategy. Traditional: Hire consultants, conduct 8-week analysis. M: AI-generated scenarios with 3 pathways pre-mapped.',
      options: [
        {
          id: 'traditional',
          label: 'Hire Strategy Consultants',
          description: 'Engage McKinsey/BCG for 8-week analysis, $2M consulting fees, build from scratch',
          isM: false,
          impact: 'Day 48: Strategy ready. Consultants paid $2M. Competitors 2 months ahead.'
        },
        {
          id: 'm',
          label: 'Deploy AI Scenario Engine',
          description: 'Nova module generates 3 pathways instantly: build, buy, or partner options pre-analyzed',
          isM: true,
          impact: '2 hours: Board-ready strategy with resources, timelines, risks. $2M saved. Lead competitors.'
        }
      ]
    }
  },
  {
    id: 'crisis-response',
    title: 'Crisis Response Execution',
    subtitle: 'Multi-phase competitive response activated',
    description: 'Comprehensive crisis response template executes immediate, short-term, and long-term strategies with role-specific actions across 47 stakeholders.',
    phase: 'response',
    capabilities: ['Crisis Response Center', 'Executive War Room', 'Communication Protocols', 'Resource Mobilization'],
    metrics: [
      { label: 'Response Teams Active', value: '8', trend: 'up' },
      { label: 'Budget Mobilized', value: '$12M', trend: 'up' },
      { label: 'Media Response Time', value: '2.4 hrs', trend: 'down' },
      { label: 'Customer Retention Risk', value: '15%', trend: 'down' }
    ],
    actions: [
      'Immediate: Executive assembly, competitive intelligence, PR strategy',
      'Short-term: AI partner acquisition, capability assessment, market positioning',
      'Long-term: Full transformation, market defense, innovation ecosystem',
      'Continuous: Real-time monitoring and strategy adjustments'
    ],
    timeline: '0-48 hours'
  },
  {
    id: 'intelligence-coordination',
    title: 'AI Intelligence Coordination',
    subtitle: 'Multi-dimensional strategic analysis active',
    description: 'All five AI intelligence modules working in coordination to provide comprehensive strategic guidance and real-time adaptation capabilities.',
    phase: 'execution',
    capabilities: ['Prism Insights', 'Echo Cultural Analytics', 'Flux Adaptations', 'Multi-dimensional Analysis'],
    metrics: [
      { label: 'Strategic Options Analyzed', value: '156', trend: 'up' },
      { label: 'Team Readiness Score', value: '74%', trend: 'up' },
      { label: 'Cultural Adaptation Index', value: '82%', trend: 'up' },
      { label: 'Change Management Risk', value: '28%', trend: 'down' }
    ],
    actions: [
      'Prism: Multi-dimensional competitive analysis and ROI modeling',
      'Echo: Team readiness assessment and change management strategy',
      'Flux: Dynamic strategy adjustments based on competitor moves',
      'Continuous intelligence updates and optimization recommendations'
    ],
    timeline: 'Ongoing'
  },
  {
    id: 'roi-measurement',
    title: 'ROI Measurement & Optimization',
    subtitle: 'Strategic value quantification active',
    description: 'Comprehensive ROI tracking demonstrates platform value: $200M+ market share protection, 6-12 month competitive advantage acceleration.',
    phase: 'measurement',
    capabilities: ['ROI Dashboard', 'Value Measurement', 'Competitive Intelligence', 'Strategic Optimization'],
    metrics: [
      { label: 'Market Share Protected', value: '$247M', trend: 'up' },
      { label: 'Response Acceleration', value: '9 months', trend: 'up' },
      { label: 'Platform ROI', value: '1,847%', trend: 'up' },
      { label: 'Competitive Advantage', value: '+12 months', trend: 'up' }
    ],
    actions: [
      'Proactive positioning saved 6-12 months response time',
      'Early threat detection prevented $200M+ market share loss',
      'Coordinated response achieved 87% success probability',
      'Platform investment ROI: $247M protection on $13.4M platform cost'
    ],
    timeline: 'Measured over 18 months'
  }
];

const phaseColors = {
  detection: 'bg-gradient-to-r from-orange-600 to-red-600',
  planning: 'bg-gradient-to-r from-blue-600 to-purple-600',
  response: 'bg-gradient-to-r from-red-600 to-pink-600',
  execution: 'bg-gradient-to-r from-green-600 to-blue-600',
  measurement: 'bg-gradient-to-r from-purple-600 to-indigo-600'
};

const phaseIcons = {
  detection: Activity,
  planning: Target,
  response: Shield,
  execution: Zap,
  measurement: BarChart3
};

export default function ExecutiveDemo() {
  const demoController = useDemoController();
  const [location] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedTab, setSelectedTab] = useState('overview');
  const [demoMode, setDemoMode] = useState<'passive' | 'interactive'>('interactive');
  const [userDecision, setUserDecision] = useState<string | null>(null);
  const [showDecisionPrompt, setShowDecisionPrompt] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const step = demoSteps[currentStep];
  const PhaseIcon = phaseIcons[step.phase];
  const progressPercent = ((currentStep + 1) / demoSteps.length) * 100;

  // Persona-specific welcome messages
  const personaInfo = {
    ceo: { title: 'Chief Executive Officer', scenario: 'Supplier Disruption Crisis', focus: 'Strategic decision velocity and business continuity' },
    coo: { title: 'Chief Operating Officer', scenario: 'Production Crisis Response', focus: 'Operational resilience and supply chain management' },
    cto: { title: 'Chief Technology Officer', scenario: 'Technology Innovation Threat', focus: 'Technical strategy and competitive positioning' },
    ciso: { title: 'Chief Information Security Officer', scenario: 'Cybersecurity Incident', focus: 'Security breach response and threat mitigation' },
    cfo: { title: 'Chief Financial Officer', scenario: 'Financial Risk Management', focus: 'Financial impact and budget allocation decisions' },
    chro: { title: 'Chief Human Resources Officer', scenario: 'Workforce Crisis', focus: 'Talent retention and organizational stability' },
    cio: { title: 'Chief Information Officer', scenario: 'System Outage Response', focus: 'IT infrastructure and service restoration' },
    cdo: { title: 'Chief Data Officer', scenario: 'Data Governance Crisis', focus: 'Data integrity and compliance management' }
  };

  const currentPersona = demoController.state.selectedPersona || 'ceo';
  const personaDetails = personaInfo[currentPersona as keyof typeof personaInfo];

  // Read persona from URL query parameter and set it in demo controller
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const personaParam = urlParams.get('persona');
    if (personaParam && ['ceo', 'coo', 'chro', 'cto', 'cio', 'cdo', 'ciso', 'cfo'].includes(personaParam)) {
      demoController.setPersona(personaParam as any);
    }
  }, []);

  useEffect(() => {
    demoController.setExecutiveStep(currentStep);
  }, [currentStep]);

  const nextStep = () => {
    if (currentStep < demoSteps.length - 1) {
      const currentStepData = demoSteps[currentStep];
      
      // In interactive mode, show decision prompt before advancing
      if (demoMode === 'interactive' && currentStepData.decisionPrompt && !userDecision) {
        setShowDecisionPrompt(true);
      } else {
        setCurrentStep(currentStep + 1);
        setUserDecision(null); // Reset decision for next step
        setShowDecisionPrompt(false);
      }
    }
  };
  
  const handleDecision = (optionId: string) => {
    setUserDecision(optionId);
    setShowDecisionPrompt(false);
    setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const playDemo = () => {
    if (isPlaying) {
      // Pause - clear interval
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      setIsPlaying(false);
    } else {
      // Play - start interval
      setIsPlaying(true);
      intervalRef.current = setInterval(() => {
        setCurrentStep(prev => {
          if (prev >= demoSteps.length - 1) {
            setIsPlaying(false);
            if (intervalRef.current) {
              clearInterval(intervalRef.current);
              intervalRef.current = null;
            }
            return prev;
          }
          return prev + 1;
        });
      }, 8000); // 8 seconds for better pacing
    }
  };

  // Cleanup interval on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  // Add keyboard shortcuts for presentations
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        prevStep();
      } else if (e.key === 'ArrowRight') {
        nextStep();
      } else if (e.key === ' ') {
        e.preventDefault();
        playDemo();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentStep, isPlaying]);

  return (
    <div className="page-background min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      <StandardNav />
      <div className="space-y-6 p-6">
        {/* Page Header - Personalized */}
        <div className="text-center space-y-3 mb-8">
          <Badge className="mb-2 bg-blue-600 text-white border-0 text-base px-6 py-2">
            {personaDetails.title} Demo Experience
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            Your Crisis Scenario: {personaDetails.scenario}
          </h1>
          <p className="text-xl text-blue-200 max-w-3xl mx-auto">
            Experience how M transforms {personaDetails.focus} from 72-hour coordination to 12-minute execution
          </p>
          <div className="flex items-center justify-center gap-4 text-sm text-blue-300 mt-4">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>5-minute demo</span>
            </div>
            <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
            <span>Interactive decision points</span>
            <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
            <span>Real-world simulation</span>
          </div>
        </div>
        {/* Demo Controls */}
        <Card className="border-blue-500/30 bg-blue-950/30">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <Play className="h-6 w-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-white">Live Enterprise Demo</CardTitle>
                  <p className="text-blue-200">Fortune 500 Strategic Intelligence Platform Walkthrough</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {/* Mode Toggle */}
                <div className="flex items-center gap-2 px-3 py-1 bg-blue-900/50 rounded-lg border border-blue-500/30">
                  <button
                    onClick={() => setDemoMode('interactive')}
                    className={`px-3 py-1 rounded text-sm transition-all ${
                      demoMode === 'interactive' 
                        ? 'bg-blue-600 text-white' 
                        : 'text-blue-300 hover:text-white'
                    }`}
                    data-testid="mode-interactive"
                  >
                    Interactive
                  </button>
                  <button
                    onClick={() => setDemoMode('passive')}
                    className={`px-3 py-1 rounded text-sm transition-all ${
                      demoMode === 'passive' 
                        ? 'bg-blue-600 text-white' 
                        : 'text-blue-300 hover:text-white'
                    }`}
                    data-testid="mode-passive"
                  >
                    Passive
                  </button>
                </div>
                
                {/* Playback Controls */}
                <Button variant="outline" onClick={prevStep} disabled={currentStep === 0} data-testid="demo-prev-step">
                  <SkipBack className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  onClick={playDemo} 
                  disabled={(currentStep === demoSteps.length - 1 && !isPlaying) || demoMode === 'interactive'}
                  data-testid="demo-play-pause"
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  {isPlaying ? 'Pause' : 'Play'}
                </Button>
                <Button variant="outline" onClick={nextStep} disabled={currentStep === demoSteps.length - 1} data-testid="demo-next-step">
                  <SkipForward className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-blue-200">Demo Progress</span>
                <span className="text-sm text-blue-200">Step {currentStep + 1} of {demoSteps.length}</span>
              </div>
              <Progress value={progressPercent} className="w-full" />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-blue-200">
                  <Clock className="h-4 w-4" />
                  Timeline: {step.timeline}
                </div>
                <div className="text-xs text-blue-300">
                  Use ← → arrow keys or spacebar to control demo
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Step */}
        <Card className={`border-2 ${phaseColors[step.phase]} text-white`}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-white/20 rounded-lg">
                  <PhaseIcon className="h-8 w-8" />
                </div>
                <div>
                  <CardTitle className="text-2xl">{step.title}</CardTitle>
                  <p className="text-lg opacity-90">{step.subtitle}</p>
                </div>
              </div>
              <Badge variant="secondary" className="bg-white/20 text-white text-lg px-4 py-2">
                {step.phase.toUpperCase()}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-lg opacity-90 mb-6">{step.description}</p>
            
            <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4 bg-white/10">
                <TabsTrigger value="overview" className="text-white data-[state=active]:bg-white/20" data-testid="tab-overview">Overview</TabsTrigger>
                <TabsTrigger value="capabilities" className="text-white data-[state=active]:bg-white/20" data-testid="tab-capabilities">Capabilities</TabsTrigger>
                <TabsTrigger value="metrics" className="text-white data-[state=active]:bg-white/20" data-testid="tab-metrics">Metrics</TabsTrigger>
                <TabsTrigger value="actions" className="text-white data-[state=active]:bg-white/20" data-testid="tab-actions">Actions</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-6">
                <Alert className="bg-white/10 border-white/20 text-white">
                  <AlertTriangle className="h-4 w-4 text-white" />
                  <AlertDescription className="text-white">
                    <strong>Executive Scenario:</strong> Major competitor announces breakthrough AI manufacturing technology 
                    that could disrupt 40% of market share. Platform automatically detects threat convergence and 
                    activates coordinated strategic response across entire organization.
                  </AlertDescription>
                </Alert>
              </TabsContent>

              <TabsContent value="capabilities" className="mt-6">
                <div className="grid grid-cols-2 gap-4">
                  {step.capabilities.map((capability, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-white/10 rounded-lg">
                      <CheckCircle className="h-5 w-5 text-green-400" />
                      <span className="font-medium">{capability}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="metrics" className="mt-6">
                <div className="grid grid-cols-2 gap-4">
                  {step.metrics.map((metric, index) => (
                    <Card key={index} className={`bg-white/10 border-white/20 ${metric.critical ? 'border-red-400 bg-red-950/30' : ''}`}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-white/80">{metric.label}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-2xl font-bold text-white">{metric.value}</span>
                            {metric.trend === 'up' ? (
                              <TrendingUp className="h-4 w-4 text-green-400" />
                            ) : metric.trend === 'down' ? (
                              <TrendingDown className="h-4 w-4 text-red-400" />
                            ) : (
                              <Minus className="h-4 w-4 text-gray-400" />
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="actions" className="mt-6">
                <div className="space-y-3">
                  {step.actions.map((action, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-white/10 rounded-lg">
                      <ArrowRight className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                      <span className="text-white">{action}</span>
                    </div>
                  ))}
                  
                  {/* Try It Now Buttons */}
                  <div className="mt-6 pt-6 border-t border-white/20">
                    <p className="text-sm text-blue-200 mb-3 font-semibold">⚡ Explore Live Features:</p>
                    <div className="grid grid-cols-2 gap-3">
                      {currentStep === 0 && (
                        <>
                          <Button 
                            variant="outline" 
                            className="text-blue-300 border-blue-500/50 hover:bg-blue-950/50"
                            onClick={() => window.open('/triggers-management', '_blank')}
                            data-testid="explore-triggers"
                          >
                            <Settings className="h-4 w-4 mr-2" />
                            Try Trigger Setup
                          </Button>
                          <Button 
                            variant="outline" 
                            className="text-blue-300 border-blue-500/50 hover:bg-blue-950/50"
                            onClick={() => window.open('/pulse', '_blank')}
                            data-testid="explore-pulse"
                          >
                            <Activity className="h-4 w-4 mr-2" />
                            Explore Pulse AI
                          </Button>
                        </>
                      )}
                      {currentStep === 2 && (
                        <>
                          <Button 
                            variant="outline" 
                            className="text-blue-300 border-blue-500/50 hover:bg-blue-950/50"
                            onClick={() => window.open('/what-if-analyzer', '_blank')}
                            data-testid="explore-whatif"
                          >
                            <Target className="h-4 w-4 mr-2" />
                            Try Scenario Planning
                          </Button>
                          <Button 
                            variant="outline" 
                            className="text-blue-300 border-blue-500/50 hover:bg-blue-950/50"
                            onClick={() => window.open('/nova', '_blank')}
                            data-testid="explore-nova"
                          >
                            <Brain className="h-4 w-4 mr-2" />
                            Explore Nova AI
                          </Button>
                        </>
                      )}
                      {currentStep === 5 && (
                        <>
                          <Button 
                            variant="outline" 
                            className="text-green-300 border-green-500/50 hover:bg-green-950/50"
                            onClick={() => window.open('/preparedness-report', '_blank')}
                            data-testid="explore-preparedness"
                          >
                            <Shield className="h-4 w-4 mr-2" />
                            See Your Score
                          </Button>
                          <Button 
                            variant="outline" 
                            className="text-green-300 border-green-500/50 hover:bg-green-950/50"
                            onClick={() => window.open('/dashboard', '_blank')}
                            data-testid="explore-dashboard"
                          >
                            <Layers className="h-4 w-4 mr-2" />
                            Full Platform
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Demo Steps Overview */}
        <Card className="border-gray-600 bg-gray-950/50">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Globe className="h-5 w-5" />
              Complete Demo Walkthrough
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {demoSteps.map((demoStep, index) => {
                const StepIcon = phaseIcons[demoStep.phase];
                return (
                  <Card 
                    key={demoStep.id} 
                    className={`cursor-pointer transition-all duration-200 ${
                      index === currentStep 
                        ? 'border-blue-500 bg-blue-950/30' 
                        : 'border-gray-600 bg-gray-900/30 hover:bg-gray-800/50'
                    }`}
                    onClick={() => setCurrentStep(index)}
                    data-testid={`demo-step-${index}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-2">
                        <div className={`p-2 rounded-lg ${phaseColors[demoStep.phase]}`}>
                          <StepIcon className="h-4 w-4 text-white" />
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {index + 1}
                        </Badge>
                      </div>
                      <h3 className="font-semibold text-white text-sm mb-1">{demoStep.title}</h3>
                      <p className="text-xs text-gray-400 mb-2">{demoStep.subtitle}</p>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Clock className="h-3 w-3" />
                        {demoStep.timeline}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Platform Value Summary */}
        <Card className="border-green-500/30 bg-green-950/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Executive Value Proposition
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">$247M</div>
                <div className="text-sm text-green-200">Market Share Protected</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">9 Months</div>
                <div className="text-sm text-green-200">Faster Response Time</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">1,847%</div>
                <div className="text-sm text-green-200">Platform ROI</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">87%</div>
                <div className="text-sm text-green-200">Success Probability</div>
              </div>
            </div>
            <Separator className="my-4" />
            <p className="text-green-200 text-center">
              <strong>Bottom Line:</strong> M enables proactive strategic positioning, 
              preventing massive market share losses while accelerating competitive response capabilities 
              by 6-12 months. Platform investment of $13.4M delivers $247M in protected market value.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Interactive Decision Dialog */}
      <Dialog open={showDecisionPrompt} onOpenChange={setShowDecisionPrompt}>
        <DialogContent className="max-w-4xl bg-gray-950 border-blue-500/50">
          <DialogHeader>
            <DialogTitle className="text-2xl text-white flex items-center gap-2">
              <AlertTriangle className="h-6 w-6 text-yellow-500" />
              {step.decisionPrompt?.question}
            </DialogTitle>
            <DialogDescription className="text-gray-300 text-base">
              {step.decisionPrompt?.context}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-2 gap-4 mt-6">
            {step.decisionPrompt?.options.map((option) => (
              <button
                key={option.id}
                onClick={() => handleDecision(option.id)}
                className={`p-6 rounded-lg border-2 text-left transition-all hover:scale-105 ${
                  option.isM
                    ? 'border-blue-500 bg-blue-950/50 hover:bg-blue-950/70'
                    : 'border-red-500 bg-red-950/50 hover:bg-red-950/70'
                }`}
                data-testid={`decision-${option.id}`}
              >
                <div className="flex items-start gap-3 mb-3">
                  {option.isM ? (
                    <Zap className="h-6 w-6 text-blue-400 flex-shrink-0" />
                  ) : (
                    <Clock className="h-6 w-6 text-red-400 flex-shrink-0" />
                  )}
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">{option.label}</h3>
                    <p className="text-sm text-gray-300 mb-3">{option.description}</p>
                    <div className={`text-xs px-3 py-2 rounded ${
                      option.isM ? 'bg-blue-900/50 text-blue-200' : 'bg-red-900/50 text-red-200'
                    }`}>
                      <strong>Impact:</strong> {option.impact}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
          
          <div className="mt-6 p-4 bg-yellow-900/20 border border-yellow-500/30 rounded-lg">
            <p className="text-yellow-200 text-sm text-center">
              ⚡ <strong>Interactive Mode:</strong> Your choice will impact the outcome shown in the comparison panel below
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}