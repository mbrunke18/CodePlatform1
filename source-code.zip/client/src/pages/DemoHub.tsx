import { useState } from 'react';
import PageLayout from '@/components/layout/PageLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Rocket, 
  PlayCircle, 
  Zap, 
  Users, 
  TrendingUp,
  ArrowRight,
  Shield,
  Target,
  Clock,
  Presentation,
  Monitor,
  Play
} from 'lucide-react';
import { Link } from 'wouter';

export default function DemoHub() {
  return (
    <PageLayout>
      <div className="max-w-7xl mx-auto space-y-8 p-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/10 border border-blue-500/30 rounded-full">
            <Rocket className="h-4 w-4 text-blue-400" />
            <span className="text-sm font-semibold text-blue-300">Demo Center</span>
          </div>
          
          <h1 className="text-4xl font-bold text-white">
            Experience M in Action
          </h1>
          
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            See how Fortune 1000 executives achieve 12-minute crisis execution vs the 72-hour industry standard. 
            Choose your demo experience below.
          </p>
        </div>

        {/* Demo Options */}
        <div className="grid md:grid-cols-2 gap-6 mt-12">
          
          {/* Executive Demo */}
          <Card className="border-blue-500/30 bg-gradient-to-br from-blue-950/40 to-gray-950/40 hover:border-blue-500/50 transition-all">
            <CardHeader>
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-blue-500/10 rounded-lg">
                  <Zap className="h-8 w-8 text-blue-400" />
                </div>
                <Badge variant="outline" className="bg-blue-500/10 text-blue-300 border-blue-500/30">
                  Interactive
                </Badge>
              </div>
              
              <CardTitle className="text-2xl text-white mb-2">
                Executive Demo
              </CardTitle>
              
              <CardDescription className="text-gray-300 text-base">
                Hands-on decision-making experience with dual-mode presentation
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Features */}
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Target className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">Interactive Mode</p>
                    <p className="text-sm text-gray-400">Make decisions at critical checkpoints, see outcomes in real-time</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <PlayCircle className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">Passive Mode</p>
                    <p className="text-sm text-gray-400">Auto-advancing presentation for quick overviews (60 seconds)</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <TrendingUp className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">Live Comparison</p>
                    <p className="text-sm text-gray-400">See traditional vs M response side-by-side</p>
                  </div>
                </div>
              </div>
              
              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-blue-500/20">
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-400">6</p>
                  <p className="text-xs text-gray-400">Steps</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-400">5-10</p>
                  <p className="text-xs text-gray-400">Minutes</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-400">2</p>
                  <p className="text-xs text-gray-400">Modes</p>
                </div>
              </div>
              
              {/* CTA */}
              <Link href="/executive-demo">
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  data-testid="launch-executive-demo"
                >
                  Launch Executive Demo
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Trade Show Demo */}
          <Card className="border-emerald-500/30 bg-gradient-to-br from-emerald-950/40 to-gray-950/40 hover:border-emerald-500/50 transition-all">
            <CardHeader>
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-emerald-500/10 rounded-lg">
                  <Presentation className="h-8 w-8 text-emerald-400" />
                </div>
                <Badge variant="outline" className="bg-emerald-500/10 text-emerald-300 border-emerald-500/30">
                  Live Event
                </Badge>
              </div>
              
              <CardTitle className="text-2xl text-white mb-2">
                Trade Show Demo
              </CardTitle>
              
              <CardDescription className="text-gray-300 text-base">
                Optimized for booth displays and live presentations with lead capture
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Features */}
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Monitor className="h-5 w-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">Booth-Optimized Display</p>
                    <p className="text-sm text-gray-400">Attract mode, auto-play, large visuals</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Users className="h-5 w-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">Lead Capture Form</p>
                    <p className="text-sm text-gray-400">Instant demo request with contact info saved to database</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Play className="h-5 w-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">Quick 3-Minute Loop</p>
                    <p className="text-sm text-gray-400">Perfect for high-traffic booth environments</p>
                  </div>
                </div>
              </div>
              
              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-emerald-500/20">
                <div className="text-center">
                  <p className="text-2xl font-bold text-emerald-400">3</p>
                  <p className="text-xs text-gray-400">Minutes</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-emerald-400">Auto</p>
                  <p className="text-xs text-gray-400">Loop</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-emerald-400">DB</p>
                  <p className="text-xs text-gray-400">Capture</p>
                </div>
              </div>
              
              {/* CTA */}
              <Link href="/trade-show-demo">
                <Button 
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                  data-testid="launch-trade-show-demo"
                >
                  Launch Trade Show Demo
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Hybrid Demo */}
          <Card className="border-purple-500/30 bg-gradient-to-br from-purple-950/40 to-gray-950/40 hover:border-purple-500/50 transition-all">
            <CardHeader>
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-purple-500/10 rounded-lg">
                  <Users className="h-8 w-8 text-purple-400" />
                </div>
                <Badge variant="outline" className="bg-purple-500/10 text-purple-300 border-purple-500/30">
                  Guided
                </Badge>
              </div>
              
              <CardTitle className="text-2xl text-white mb-2">
                Hybrid Demo Navigator
              </CardTitle>
              
              <CardDescription className="text-gray-300 text-base">
                Full guided experience with persona-based scenarios and narration
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Features */}
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Users className="h-5 w-5 text-purple-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">8 Executive Personas</p>
                    <p className="text-sm text-gray-400">CEO, COO, CHRO, CTO, CIO, CDO, CISO, CFO scenarios</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Shield className="h-5 w-5 text-purple-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">Psychological Journey</p>
                    <p className="text-sm text-gray-400">11 overlays showing pain, transformation, and urgency</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-purple-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">Auto-Advance Flow</p>
                    <p className="text-sm text-gray-400">Seamless transitions with text-to-speech narration</p>
                  </div>
                </div>
              </div>
              
              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-purple-500/20">
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-400">8</p>
                  <p className="text-xs text-gray-400">Personas</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-400">10-15</p>
                  <p className="text-xs text-gray-400">Minutes</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-400">11</p>
                  <p className="text-xs text-gray-400">Overlays</p>
                </div>
              </div>
              
              {/* CTA */}
              <Link href="/hybrid-demo">
                <Button 
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                  data-testid="launch-hybrid-demo"
                >
                  Launch Hybrid Demo
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Back to Product */}
        <div className="text-center pt-8">
          <Link href="/dashboard">
            <Button 
              variant="outline" 
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
              data-testid="back-to-product"
            >
              Back to Platform
            </Button>
          </Link>
        </div>
      </div>
    </PageLayout>
  );
}
