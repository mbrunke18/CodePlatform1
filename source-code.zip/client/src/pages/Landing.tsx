import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Radio, Radar, Sparkles, BookMarked, Dumbbell, RefreshCw, Zap, Play, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import StandardNav from "@/components/layout/StandardNav";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <StandardNav />
      
      {/* Hero Section */}
      <div className="flex-1 flex items-center justify-center py-24 px-4">
        <div className="max-w-4xl w-full">
          <div className="text-center mb-16">
            <Badge className="bg-primary text-primary-foreground mb-8 px-4 py-2 text-sm font-semibold inline-flex items-center" data-testid="badge-hero">
              <Radio className="w-4 h-4 mr-2 animate-pulse" />
              STRATEGIC EXECUTION OPERATING SYSTEM
            </Badge>
            
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 leading-tight" data-testid="heading-hero">
              Execute Strategic Decisions in <span className="text-primary">12 Minutes</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-12 leading-relaxed max-w-3xl mx-auto" data-testid="text-hero-subtitle">
              The Operating System for Strategic Velocity. You Decide. AI Executes.
            </p>
            
            <div className="flex gap-4 justify-center flex-wrap">
              <Link href="/demo-selector">
                <Button size="lg" className="px-8 py-6 text-lg" data-testid="button-view-demo">
                  <Play className="mr-2 h-5 w-5" />
                  Watch Live Demo
                </Button>
              </Link>
              
              <Link href="/new-user-journey">
                <Button 
                  size="lg"
                  variant="outline"
                  className="px-8 py-6 text-lg"
                  data-testid="button-get-started"
                >
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Dynamic Strategy Features Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-16">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <Radio className="h-12 w-12 text-primary mx-auto mb-4 animate-pulse" />
                <h3 className="font-bold text-lg text-foreground mb-2">Command Center</h3>
                <p className="text-sm text-muted-foreground">Real-time coordination hub</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <Radar className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-bold text-lg text-foreground mb-2">Foresight Radar</h3>
                <p className="text-sm text-muted-foreground">Weak signal detection</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <BookMarked className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-bold text-lg text-foreground mb-2">148 Playbooks</h3>
                <p className="text-sm text-muted-foreground">Every scenario covered</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <Sparkles className="h-12 w-12 text-primary mx-auto mb-4 animate-pulse" />
                <h3 className="font-bold text-lg text-foreground mb-2">Living Playbooks</h3>
                <p className="text-sm text-muted-foreground">Self-learning AI</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <Dumbbell className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-bold text-lg text-foreground mb-2">Future Gym</h3>
                <p className="text-sm text-muted-foreground">Strategic simulations</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <RefreshCw className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-bold text-lg text-foreground mb-2">Continuous Mode</h3>
                <p className="text-sm text-muted-foreground">Always-on operations</p>
              </CardContent>
            </Card>
          </div>

          {/* Value Proposition */}
          <Card>
            <CardContent className="p-12 space-y-6">
              <div className="grid md:grid-cols-3 gap-8 text-center">
                <div data-testid="stat-0">
                  <div className="text-5xl font-bold text-primary mb-3" data-testid="value-speed">12 min</div>
                  <p className="text-base text-muted-foreground">Strategic coordination</p>
                </div>
                <div data-testid="stat-1">
                  <div className="text-5xl font-bold text-primary mb-3" data-testid="value-playbooks">148</div>
                  <p className="text-base text-muted-foreground">Strategic playbooks</p>
                </div>
                <div data-testid="stat-2">
                  <div className="text-5xl font-bold text-primary mb-3" data-testid="value-ai">24/7</div>
                  <p className="text-base text-muted-foreground">AI intelligence</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="text-center mt-12 pb-8">
            <p className="text-base text-muted-foreground font-medium">
              Activate your playbook. Rally your executives. Resolve the crisis.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
