import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Clock, 
  Users, 
  CheckCircle2, 
  Activity,
  TrendingUp,
  Zap,
  AlertCircle,
  Shield,
  Target
} from 'lucide-react';
import PageLayout from '@/components/layout/PageLayout';
import { useLocation } from 'wouter';

interface TimelineEvent {
  minute: number;
  second: number;
  title: string;
  description: string;
  type: 'trigger' | 'notification' | 'task' | 'decision' | 'completion';
  icon: any;
  color: string;
}

export default function WatchDemo() {
  const [, setLocation] = useLocation();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0); // in seconds
  const [completedEvents, setCompletedEvents] = useState<number[]>([]);

  // Timeline of 12-minute playbook execution
  const timeline: TimelineEvent[] = [
    {
      minute: 0,
      second: 0,
      title: 'AI Trigger Detected',
      description: 'Competitor announced strategic partnership with major cloud provider',
      type: 'trigger',
      icon: AlertCircle,
      color: 'text-red-500'
    },
    {
      minute: 0,
      second: 15,
      title: 'Playbook Auto-Selected',
      description: 'AI matched trigger to "Competitive Response - Product Launch Counter" playbook (94% confidence)',
      type: 'decision',
      icon: Zap,
      color: 'text-purple-500'
    },
    {
      minute: 0,
      second: 45,
      title: 'Executive Notification Sent',
      description: 'CEO, CRO, CMO alerted with AI briefing and recommended action',
      type: 'notification',
      icon: Users,
      color: 'text-blue-500'
    },
    {
      minute: 1,
      second: 30,
      title: 'CEO Activates Playbook',
      description: 'One-click activation initiated 24-stakeholder coordination',
      type: 'decision',
      icon: CheckCircle2,
      color: 'text-green-500'
    },
    {
      minute: 2,
      second: 0,
      title: 'Tasks Distributed',
      description: '15 tasks auto-assigned to 24 stakeholders across 6 departments',
      type: 'task',
      icon: Target,
      color: 'text-orange-500'
    },
    {
      minute: 2,
      second: 30,
      title: 'Sales Team Briefed',
      description: 'Pre-built counter-messaging distributed to 120 sales reps via Slack',
      type: 'notification',
      icon: Users,
      color: 'text-blue-500'
    },
    {
      minute: 3,
      second: 45,
      title: 'Marketing Campaign Launched',
      description: 'Competitive response messaging published across channels',
      type: 'task',
      icon: TrendingUp,
      color: 'text-green-500'
    },
    {
      minute: 5,
      second: 15,
      title: 'Customer Outreach Initiated',
      description: 'High-value accounts contacted with strategic positioning',
      type: 'task',
      icon: Users,
      color: 'text-blue-500'
    },
    {
      minute: 7,
      second: 0,
      title: 'Product Team Aligned',
      description: 'Roadmap adjustments identified, feature comparison updated',
      type: 'task',
      icon: Target,
      color: 'text-purple-500'
    },
    {
      minute: 8,
      second: 30,
      title: 'Board Briefing Generated',
      description: 'AI compiled situation summary, actions taken, and projected impact',
      type: 'notification',
      icon: Shield,
      color: 'text-blue-500'
    },
    {
      minute: 10,
      second: 15,
      title: 'Partner Ecosystem Notified',
      description: 'Strategic partners briefed on competitive landscape shift',
      type: 'notification',
      icon: Users,
      color: 'text-blue-500'
    },
    {
      minute: 11,
      second: 45,
      title: 'Playbook Execution Complete',
      description: 'All 15 tasks completed. Decision velocity: 11m 45s (vs industry standard: 72 hours)',
      type: 'completion',
      icon: CheckCircle2,
      color: 'text-green-500'
    }
  ];

  // Calculate metrics based on current time
  const totalDuration = 720; // 12 minutes in seconds
  const progress = (currentTime / totalDuration) * 100;
  const currentMinute = Math.floor(currentTime / 60);
  const currentSecond = currentTime % 60;
  const tasksCompleted = completedEvents.filter(e => timeline[e].type === 'task').length;
  const totalTasks = timeline.filter(e => e.type === 'task').length;
  const stakeholdersNotified = Math.min(24, Math.floor((currentTime / totalDuration) * 24));

  // Play/pause logic
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    
    if (isPlaying && currentTime < totalDuration) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          const next = prev + 1;
          
          // Check if any events should be completed
          timeline.forEach((event, index) => {
            const eventTime = event.minute * 60 + event.second;
            if (eventTime <= next && !completedEvents.includes(index)) {
              setCompletedEvents(prev => [...prev, index]);
            }
          });
          
          // Auto-pause at end
          if (next >= totalDuration) {
            setIsPlaying(false);
            return totalDuration;
          }
          
          return next;
        });
      }, 1000); // Real-time speed (can adjust to 100ms for 10x speed)
    }
    
    return () => clearInterval(interval);
  }, [isPlaying, currentTime, completedEvents, timeline, totalDuration]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleRestart = () => {
    setCurrentTime(0);
    setCompletedEvents([]);
    setIsPlaying(false);
  };

  const handleSkipToEvent = (eventIndex: number) => {
    const event = timeline[eventIndex];
    const eventTime = event.minute * 60 + event.second;
    setCurrentTime(eventTime);
    // Include the selected event and all events before it as completed
    setCompletedEvents(timeline.slice(0, eventIndex + 1).map((_, i) => i));
  };

  return (
    <PageLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div className="bg-gradient-to-r from-navy-900 to-navy-800 text-white rounded-xl p-8 shadow-2xl">
          <h1 className="text-4xl font-bold text-gold-400 mb-3">
            Watch Demo: 12-Minute Playbook Execution
          </h1>
          <p className="text-xl text-blue-100">
            See how M compresses 72 hours of coordination into 12 minutes
          </p>
        </div>
        {/* Hero Section */}
        <Card className="bg-gradient-to-r from-navy-900 to-navy-800 text-white">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-3xl font-bold text-gold-400 mb-2">
                  Live Playbook Execution Demonstration
                </CardTitle>
                <p className="text-xl text-blue-100">
                  <span className="font-bold text-red-400">Industry Standard: 72 hours</span> → <span className="font-bold text-green-400">M: 12 minutes</span>
                </p>
              </div>
              <Badge className="bg-red-500 text-white px-4 py-2 text-lg animate-pulse">
                LIVE DEMO
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center p-4 bg-navy-950/50 rounded-lg">
                <div className="text-3xl font-bold text-green-400">${(850000 * (progress / 100)).toFixed(0).toLocaleString()}</div>
                <div className="text-sm text-gray-300">Value Protected</div>
              </div>
              <div className="text-center p-4 bg-navy-950/50 rounded-lg">
                <div className="text-3xl font-bold text-purple-400">{stakeholdersNotified}/24</div>
                <div className="text-sm text-gray-300">Stakeholders Notified</div>
              </div>
              <div className="text-center p-4 bg-navy-950/50 rounded-lg">
                <div className="text-3xl font-bold text-blue-400">{tasksCompleted}/{totalTasks}</div>
                <div className="text-sm text-gray-300">Tasks Completed</div>
              </div>
              <div className="text-center p-4 bg-navy-950/50 rounded-lg">
                <div className="text-3xl font-bold text-orange-400">71h {60 - currentMinute}m</div>
                <div className="text-sm text-gray-300">Time Saved</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Playback Controls */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button
                  onClick={handlePlayPause}
                  size="lg"
                  className="bg-gold-500 hover:bg-gold-600 text-navy-900"
                  data-testid="button-play-pause"
                >
                  {isPlaying ? <Pause className="h-5 w-5 mr-2" /> : <Play className="h-5 w-5 mr-2" />}
                  {isPlaying ? 'Pause' : currentTime === 0 ? 'Start Demo' : 'Resume'}
                </Button>
                <Button
                  onClick={handleRestart}
                  variant="outline"
                  size="lg"
                  data-testid="button-restart"
                >
                  <RotateCcw className="h-5 w-5 mr-2" />
                  Restart
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-gold-500" />
                <span className="text-2xl font-mono font-bold text-gold-500" data-testid="text-current-time">
                  {currentMinute.toString().padStart(2, '0')}:{currentSecond.toString().padStart(2, '0')}
                </span>
                <span className="text-gray-500">/ 12:00</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Progress value={progress} className="h-3" />
          </CardContent>
        </Card>

        {/* Timeline Visualization */}
        <div className="grid grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-gold-500" />
                Execution Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-[600px] overflow-y-auto">
                {timeline.map((event, index) => {
                  const eventTime = event.minute * 60 + event.second;
                  const isCompleted = completedEvents.includes(index);
                  const isCurrent = currentTime >= eventTime && currentTime < (timeline[index + 1] ? timeline[index + 1].minute * 60 + timeline[index + 1].second : totalDuration);
                  
                  return (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border-2 transition-all cursor-pointer ${
                        isCompleted 
                          ? 'bg-green-50 border-green-300 dark:bg-green-950/20 dark:border-green-700' 
                          : isCurrent
                          ? 'bg-gold-50 border-gold-400 dark:bg-gold-950/20 dark:border-gold-600 animate-pulse'
                          : 'bg-gray-50 border-gray-200 dark:bg-gray-900 dark:border-gray-700 opacity-50'
                      }`}
                      onClick={() => handleSkipToEvent(index)}
                      data-testid={`timeline-event-${index}`}
                    >
                      <div className="flex items-start gap-3">
                        <event.icon className={`h-5 w-5 mt-0.5 ${event.color}`} />
                        <div className="flex-1 page-background">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold">{event.title}</span>
                            <span className="text-sm text-gray-500 font-mono">
                              {event.minute}:{event.second.toString().padStart(2, '0')}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {event.description}
                          </p>
                          {isCompleted && (
                            <Badge className="mt-2 bg-green-500 text-white">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              Complete
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Real-Time Metrics */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-gold-500" />
                  Real-Time Impact
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">Stakeholder Coordination</span>
                      <span className="text-sm font-bold">{stakeholdersNotified}/24</span>
                    </div>
                    <Progress value={(stakeholdersNotified / 24) * 100} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">Task Completion</span>
                      <span className="text-sm font-bold">{tasksCompleted}/{totalTasks}</span>
                    </div>
                    <Progress value={(tasksCompleted / totalTasks) * 100} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">Overall Progress</span>
                      <span className="text-sm font-bold">{progress.toFixed(0)}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-950/20 dark:to-blue-950/20">
              <CardHeader>
                <CardTitle className="text-green-700 dark:text-green-400">
                  Time Compression in Action
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-red-100 dark:bg-red-950/30 rounded-lg">
                    <div className="text-sm text-red-700 dark:text-red-400 mb-1">Industry Standard</div>
                    <div className="text-3xl font-bold text-red-600 dark:text-red-500">72 hrs</div>
                  </div>
                  <div className="text-center p-4 bg-green-100 dark:bg-green-950/30 rounded-lg">
                    <div className="text-sm text-green-700 dark:text-green-400 mb-1">M</div>
                    <div className="text-3xl font-bold text-green-600 dark:text-green-500">
                      {currentMinute}m {currentSecond}s
                    </div>
                  </div>
                </div>
                <div className="text-center p-4 bg-gradient-to-r from-gold-100 to-gold-200 dark:from-gold-950/30 dark:to-gold-900/30 rounded-lg">
                  <div className="text-sm text-gold-700 dark:text-gold-400 mb-1">Time Saved This Execution</div>
                  <div className="text-4xl font-bold text-gold-600 dark:text-gold-500">
                    {(72 - (currentTime / 3600)).toFixed(1)} hours
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950/20 dark:to-blue-950/20 border-2 border-purple-300 dark:border-purple-700">
              <CardHeader>
                <CardTitle className="text-purple-900 dark:text-purple-300">Ready to Transform Your Execution?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-slate-700 dark:text-slate-300 text-center">
                  Join M's Q1 2025 pilot program. Limited to 10 Fortune 1000 companies for 90-day validation partnership.
                </p>
                <Button
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white text-lg py-6"
                  onClick={() => setLocation('/contact')}
                  data-testid="button-request-early-access"
                >
                  Request Early Access Interview
                </Button>
                
                <div className="border-t border-purple-200 dark:border-purple-800 pt-4 space-y-2">
                  <p className="text-sm text-slate-600 dark:text-slate-400 text-center mb-2">Continue Exploring:</p>
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => setLocation('/business-scenarios')}
                    data-testid="button-explore-scenarios"
                  >
                    View 148 Playbooks
                  </Button>
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => setLocation('/how-it-works')}
                    data-testid="button-how-it-works"
                  >
                    Interactive Demo
                  </Button>
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => setLocation('/')}
                    data-testid="button-return-home"
                  >
                    Return Home
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PageLayout>
  );
}
