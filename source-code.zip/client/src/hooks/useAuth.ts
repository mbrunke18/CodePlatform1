import { useQuery } from '@tanstack/react-query';

export interface AuthUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  profileImageUrl?: string;
  role?: string;
  initials: string;
}

export function useAuth() {
  const { data: user, isLoading, error } = useQuery<AuthUser>({
    queryKey: ['/api/auth/user'],
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Development bypass: provide mock user when authentication fails
  const mockUser: AuthUser = {
    id: 'dev-user-123',
    email: 'demo@vexor.io',
    firstName: 'Demo',
    lastName: 'Executive',
    initials: 'DE',
    role: 'admin'
  };

  // Use real user if available, otherwise use mock user for development
  const effectiveUser = user || mockUser;
  const isAuthenticated = true; // Always authenticated for development

  return {
    user: effectiveUser,
    isLoading,
    isAuthenticated,
  };
}
